[OwlVision GDSII Viewer]
========================

OwlVision is used to display GDSII (GDS, GDS2) Stream Format. It is
implemented in Java programming language. Virtually, it can be run on
all of the platforms. Please note that Java SDK or JRE is required
before running the program.

For Unix/Linux users, Java may have already been installed on your
computer. If your Java's version is from Sun Microsystems (not "gij"),
you can start running the program by typing the commands described in
the section "How to Run the Program" below. Otherwise, you still have
to download and install Java JDK/JRE.


[How to Download Java JDK/JRE]
==============================

Java JDK/JRE can be downloaded from http://java.sun.com. Macintosh
versions of JDK/JRE can be downloaded from
http://developer.apple.com/java/.
�@

[About Downloading OwlVision]
=============================

The downloaded file name should be "OwlVision-<version>.zip" or
"OwlVision-<version>.tar.gz". Please decompress the file before
running the program.


[How to Run the Program]
========================

After you have had Java SDK or JRE installed on your computer, you can
choose from one of the following three options:

(1) For Windows (XP) users, just double-click on the icon
    "gdsview.jar", "gdsview.bat", or "OwlVision.jar" (It depends on
    the version you have downloaded).

(2) For Windows (XP) users, you can also click on "Start --> Run..."
    of your computer. Then type "cmd" followed by clicking "OK" to
    invoke the DOS prompt window. After that, execute the following
    command:

    % java -jar OwlVision.jar

(3) For UNIX/Linux users, type the following command to invoke the
    program:

    % java -jar OwlVision.jar

(4) Launch OwlVision v1.0.1 (old version) through Java Web Start
    (http://vlsilayoutdotcom.tseng.id.au/JavaWebStart/OwlVision.jnlp).


[How to Increase Java Heap Size]
================================

    % java -jar -Xms512M -Xmx512M OwlVision.jar
    % java -jar -Xms1024M -Xmx1024M OwlVision.jar


[Web Sites]
===================

    (1) OwlVision:   http://www.owlvision.com
    (2) Main Site:   http://www.vlsilayout.com
    (3) Source Code: http://www.owlvision.org
