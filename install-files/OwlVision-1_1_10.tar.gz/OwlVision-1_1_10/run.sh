#!/usr/bin/sh
java -Xms1024M -Xmx1024M -jar OwlVision.jar
