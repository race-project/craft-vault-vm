/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Point;
import java.io.*;
//import java.util.Collection;
//import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.JTextField;


public class BooleanMaskOperation {
	
	private static int    layer1;		/* input layer 1 */
	private static int    layer2; 		/* input layer 2 */
	private static String opType;  		/* AND, OR, NOT, XOR */
	
	private static String outputFileName;
	private static int    outputLayer;	/* the output layer */
	
	private static File fileTo = null;
	private static JTextField tfToFile = null;
	
	private static Hashtable layer1_HT;  // all the vertices in layer 1
	private static Hashtable layer2_HT;  // all the vertices in layer 2
	private static Hashtable layer3_HT;	 // all the intersection vertices
	
	
	public static void setOutputFileName( String fileName ){
		outputFileName = fileName; 
	}
	
	public static void setToFile( File f ) {
		fileTo = f;
	}	
	
	public static void setToTextField( JTextField tf ) {
		tfToFile = tf;
	}
	
	
	public static void getToFile() {
		tfToFile.setText( fileTo.getAbsolutePath() );
	}
	
	
	public static void setLayer1( String lay1) {
		layer1 = Integer.parseInt(lay1);
	}
	
	
	public static void setLayer2( String lay2) {
		layer2 = Integer.parseInt(lay2);
	}
	
	public static void setOutputLayer( String outputLay ) {
		outputLayer = Integer.parseInt( outputLay );
	}
	
	public static void setOpType( String op ) {
		opType = op;
	}
	
	
	/* Perform Boolean Mask Operation - AND, OR, NOT, XOR */
	public static void performBoolean() {
		
		//System.out.println( "Layer 1: " + layer1 );
		//System.out.println( "OpType : " + opType );
		//System.out.println( "Layer 2: " + layer2 );
		
		layer1_HT = new Hashtable();
		layer2_HT = new Hashtable();
		layer3_HT = new Hashtable();
		
		LinkedList layer1_polygons = new LinkedList();
		LinkedList layer2_polygons = new LinkedList();
		
		/* ==== Read Polygons ==== */
		
		for (DSstrNode strNode = DSbuild.strList.getHead(); 
        	 strNode != null; 
        	 strNode = strNode.getNext() )
		{
			//System.out.println("perform()");
			
			/* for each polygon in the cell */
			for (DSboundaryNode bdNode = strNode.getBoundaryList().getHead();
			     bdNode != null;
			     bdNode = bdNode.getNext() ) 
			{
				DSxyDList vertexDList;
				DSpolygon polygon;   
				
				if ( bdNode.getLayerNo() == layer1 ) {
					//System.out.println("layer 1");
					
					/* a list of vertices (in clockwise order) */
					vertexDList = convertToDoublyLinkedListInClockwiseOrder( bdNode.getXYlist() );
					polygon    = new DSpolygon( bdNode.getXYlist().getNumber()-1, vertexDList );
					
					insert_vertices_into_HT( layer1_HT, vertexDList, bdNode.getXYlist().getNumber()-1 );
					layer1_polygons.add( polygon );  /* accumulate polygons (a layer can have many polygons) */
				}
				else if ( bdNode.getLayerNo() == layer2 ) {
					//System.out.println("layer 2");
					
					/* a list of vertices (in clockwise order) */
					vertexDList = convertToDoublyLinkedListInClockwiseOrder( bdNode.getXYlist() );
					polygon    = new DSpolygon( bdNode.getXYlist().getNumber()-1, vertexDList );
					
					insert_vertices_into_HT( layer2_HT, vertexDList, bdNode.getXYlist().getNumber()-1 );
					layer2_polygons.add( polygon );  /* accumulate polygons (a layer can have many polygons) */
				}
				
				// for test only
				//DSpolygon p = (DSpolygon) layer1_polygons.removeFirst();
				
				//System.out.println("perform()");
			}	
		}    /* END of "read polygons" */
		
		
		/*
		 *  The intersections-finding algorithm programmed below is related to the following two papers:
		 *  
		 *  (1) Jon L. Bentley and Thomas A. Ottmann
		 *      "Algorithms for Reporting and Counting Geometric Intersections"
		 *      IEEE Transactions on Computers, Vol. C-28, No. 9, September 1979
		 *      pp. 643-647
		 *  
		 *  (2) Ulrich Lauther
		 *      "An O(N log N) Algorithm for Boolean Mask Operations"
		 *      18th Design Automation Conference, 1981
		 *      pp. 555-562
		 *      
		 *      
		 *  The R structure is the same as the one defined in (2).
		 */
		
		
		/* ==== eventQ ==== */		
		/* construct eventQ, which stands for the
		 * position of the scan line.
		 */
		DSxySearchTree eventQ = ConstructEventQueue( layer1_polygons, layer2_polygons);
		
		
		/* R stores the edges which are intersecting the scan line */
		DSsearchTree R = new DSsearchTree();
		
		
		/* ==== Go through the elements in eventQ ==== */
		while( !eventQ.isEmpty() ) {
			
			DSxySearchTreeNode node = eventQ.pop();	// get an (x,y) pair

			/* print the (x,y) value */
			System.out.println("eventQ ==> (" + node.getX() + ", " + node.getY() + ")");
			
			String HTkey = "" + node.getX() + "^" + node.getY();    // use coordinates as keys 
			
			LinkedList ll_1 = (LinkedList) layer1_HT.get( HTkey );  // a linked list which contains polygon vertices
			LinkedList ll_2 = (LinkedList) layer2_HT.get( HTkey );  // a linked list which contains polygon vertices
			LinkedList ll_3 = (LinkedList) layer3_HT.get( HTkey );
			
			/* === DELETE FROM R === */
			
			/* --- layer 1 --- */
			if ( ll_1 != null ) {
				Iterator iterator1 = ll_1.listIterator();
				DSxyDNode n1;
				while ( iterator1.hasNext() ) {
					n1 = (DSxyDNode) iterator1.next();
					//System.out.println("--------------------");					
					processIncidentEdges_Delete( n1, R, eventQ );
				}
			}			
			
			/* --- layer 2 --- */
			if ( ll_2 != null ) {
				Iterator iterator2 = ll_2.listIterator();
				DSxyDNode n2;
				while ( iterator2.hasNext() ) {
					n2 = (DSxyDNode) iterator2.next();
					//System.out.println("--------------------");					
					processIncidentEdges_Delete( n2, R, eventQ );
				}
			}
			
			/* --- ll_3 --- */
			if ( ll_3 != null ) {
				Iterator iterator3 = ll_3.listIterator();
				DSxyDNode n3;
				while ( iterator3.hasNext() ) {
					n3 = (DSxyDNode) iterator3.next();
					//System.out.println("--------------------");					
					processIncidentEdges_Delete( n3, R, eventQ );
				}
			}
			
			/* === INSERT INTO R === */
			
			/* --- layer 1 --- */
			if ( ll_1 != null ) {
				Iterator iterator1 = ll_1.listIterator();
				DSxyDNode n1;
				while ( iterator1.hasNext() ) {
					n1 = (DSxyDNode) iterator1.next();
					//System.out.println("--------------------");					
					processIncidentEdges_Insert( n1, R, eventQ );
				}
			}			
			
			/* --- layer 2 --- */
			if ( ll_2 != null ) {
				Iterator iterator2 = ll_2.listIterator();
				DSxyDNode n2;
				while ( iterator2.hasNext() ) {
					n2 = (DSxyDNode) iterator2.next();
					//System.out.println("--------------------");					
					processIncidentEdges_Insert( n2, R, eventQ );
				}
			}
			
			/* --- ll_3 --- */
			if ( ll_3 != null ) {
				Iterator iterator3 = ll_3.listIterator();
				DSxyDNode n3;
				while ( iterator3.hasNext() ) {
					n3 = (DSxyDNode) iterator3.next();
					//System.out.println("--------------------");					
					processIncidentEdges_Insert( n3, R, eventQ );
				}
			}
			
			System.out.println("------------------------------");
		}
		
		
		updateNumOfVertices( layer1_polygons );
		updateNumOfVertices( layer2_polygons );
		
		/* ==== END of finding intersections ==== */
		
		//System.out.println("\n==== END of finding intersections ====\n");
		
		
		System.out.println("\n==== REGION FINDING ====\n");
		
		/*
		 *   Both "layer1_polygons" and "layer2_polygons" now contain intersection points.
		 */
		
		//DEBUG_get_layer1_and_layer2_polygons( layer1_polygons, layer2_polygons );
		
		/* eventQ_2: for use in region finding */
		DSxySearchTree eventQ_2 = ConstructEventQueue( layer1_polygons, layer2_polygons );
		
		layer1_HT = new Hashtable();  // initialize
		layer2_HT = new Hashtable();  // initialize
		
		insert_vertices_into_HT( layer1_HT, layer1_polygons);
		insert_vertices_into_HT( layer2_HT, layer2_polygons);
		
		/* the R structure */
		DSsearchTree rStr = new DSsearchTree();
		
		while( !eventQ_2.isEmpty() ) {
			
			DSxySearchTreeNode node = eventQ_2.pop();	// get an (x,y) pair
			
			/* print the (x,y) value */ 
			System.out.println("eventQ_2 ==> (" + node.getX() + ", " + node.getY() + ")");
			
			nievergelt_transition( node, layer1_HT, layer2_HT, rStr );
		}
		
		
		/* Former region-finding code */
		/*******************************************************************************************
		
		layer1_HT = new Hashtable();  // initialize
		layer2_HT = new Hashtable();  // initialize
		
		insert_vertices_into_HT( layer1_HT, layer1_polygons);
		insert_vertices_into_HT( layer2_HT, layer2_polygons);
		
		
		// ==== Go through the elements in eventQ ==== 
		Hashtable lineSegmentsForBooleanAND = new Hashtable();
		
		while( !eventQ_2.isEmpty() ) {
			
			DSxySearchTreeNode node = eventQ_2.pop();	// get an (x,y) pair
			// print the (x,y) value 
			//System.out.println("eventQ_2 ==> (" + node.getX() + ", " + node.getY() + ")");
			
			String htKey = "" + node.getX() + "^" + node.getY();    // use coordinates as keys 
			
			LinkedList ll_1 = (LinkedList) layer1_HT.get( htKey );  // a linked list which contains polygon vertices
			LinkedList ll_2 = (LinkedList) layer2_HT.get( htKey );  // a linked list which contains polygon vertices
			
			collect_AND_surface( node, ll_1, ll_2, lineSegmentsForBooleanAND );
			
			// do something here
		}
		
		//System.out.println( lineSegmentsForBooleanAND.keySet() );
		
		LinkedList listOfPolygons = extractPolygonsFormLineSegments( lineSegmentsForBooleanAND );
		
		
		outputLayoutToASCII( layer1_polygons, layer2_polygons, listOfPolygons );
		
		//System.out.println("   " + layer1 + "   " + layer2);
		
		************************************************************************************/
				
	}
	
	
	/*  The region-finding procedure
	 * 
	 *  This procedure is related to the following paper:
	 *  
	 *        J. Nievergelt and F. P. Preparata
	 *        "Plane-Sweep Algorithms for Intersecting Geometric Figures"
	 *        Communications of the ACM, 
	 *        October 1982, vol 25, no. 10
	 *        pp. 739-747
	 */
	private static void nievergelt_transition( 	DSxySearchTreeNode	currNode,
												Hashtable 			layer1_HT,
												Hashtable 			layer2_HT,
												DSsearchTree 		rStr )
	{
		
		String htKey = "" + currNode.getX() + "^" + currNode.getY();    // use coordinates as hash keys
		
		LinkedList ll_1 = (LinkedList) layer1_HT.get( htKey );  // a linked list which contains polygon vertices
		LinkedList ll_2 = (LinkedList) layer2_HT.get( htKey );  // a linked list which contains polygon vertices
		
		/* ==== case "intersection" ==== */
		if ( ll_1!=null && ll_2!=null ) {
			
		}
		
		/* ===== for layer1 edges ===== */
		if ( ll_1!=null ) {
			
			Iterator it1 = ll_1.listIterator();
			
			it1.hasNext();
			DSxyDNode n1 = (DSxyDNode) it1.next();
			
			System.out.println("    prev:" + n1.getPrev().getX() + "," + n1.getPrev().getY() );
			System.out.println("    next:" + n1.getNext().getX() + "," + n1.getNext().getY() );
			
			/* ==== case "START" ==== */
			if ( scanLineOrderCompare( currNode, n1.getPrev() ) > 0 &&
				 scanLineOrderCompare( currNode, n1.getNext() ) > 0 )
			{
				System.out.println("    case: start");				
				Nievergelt.caseStart( n1, rStr, currNode );
			}			
			/* ==== case "END" ==== */
			else if ( scanLineOrderCompare( currNode, n1.getPrev() ) < 0 && 
					  scanLineOrderCompare( currNode, n1.getNext() ) < 0 )
			{
				System.out.println("    case: end");	
				Nievergelt.caseEnd( n1, rStr, currNode );
			}
			/* ==== case "BEND" ==== */
			else if ( ( scanLineOrderCompare( currNode, n1.getPrev() ) < 0 && scanLineOrderCompare( currNode, n1.getNext() ) > 0 ) ||
					  ( scanLineOrderCompare( currNode, n1.getPrev() ) > 0 && scanLineOrderCompare( currNode, n1.getNext() ) < 0 ) ) 
			{
				System.out.println("    case: bend");
				Nievergelt.caseBend( n1, rStr, currNode );
			}
			else {
				/* do nothing */
				/* this case should not happen */
				System.out.println("    WARNING: unhandled edge");
			}
			System.out.println();
		}
		
		/* ===== for layer2 edges ===== */
		if ( ll_2!=null ) {
			
			Iterator it2 = ll_2.listIterator();
			
			it2.hasNext();
			DSxyDNode n2 = (DSxyDNode) it2.next();
			
			System.out.println("    prev:" + n2.getPrev().getX() + "," + n2.getPrev().getY() );
			System.out.println("    next:" + n2.getNext().getX() + "," + n2.getNext().getY() );
			
			/* ==== case "START" ==== */
			if ( scanLineOrderCompare( currNode, n2.getPrev() ) > 0 &&
			     scanLineOrderCompare( currNode, n2.getNext() ) > 0 )
			{
				System.out.println("    case: start");
				Nievergelt.caseStart( n2, rStr, currNode );
			}			
			/* ==== case "END" ==== */
			else if ( scanLineOrderCompare( currNode, n2.getPrev() ) < 0 && 
					  scanLineOrderCompare( currNode, n2.getNext() ) < 0 )
			{
				System.out.println("    case: end");	
				Nievergelt.caseEnd( n2, rStr, currNode );
			}
			/* ==== case "BEND" ==== */
			else if ( ( scanLineOrderCompare( currNode, n2.getPrev() ) < 0 && scanLineOrderCompare( currNode, n2.getNext() ) > 0 ) ||
					  ( scanLineOrderCompare( currNode, n2.getPrev() ) > 0 && scanLineOrderCompare( currNode, n2.getNext() ) < 0 ) ) 
			{
				System.out.println("    case: bend");
				Nievergelt.caseBend( n2, rStr, currNode );
			}
			else {
				/* do nothing */
				/* this case should not happen */
			}
			System.out.println();
			
		}
		
	}
	
	
	/*  Compare which node is swept firt by the scan line
	 *  
	 *    node 1: (x1,y1)
	 *    node 2: (x2,y2)
	 *    
	 *  Return:
	 *    1 : node 1 is swept first
	 *    -1: node 2 is swept first
	 *    0 : the same coordinates
	 *   
	 */
	private static int scanLineOrderCompare( int x1, int y1,
											 int x2, int y2 ) 
	{
		if ( y1 > y2 ) {
			return( 1 );
		}
		if ( y1 < y2 ) {
			return( -1 );
		}
		if ( y1 == y2 ) {
			if ( x1 < x2 ) {
				return( 1 );
			}
			if ( x1 > x2 ) {
				return( -1 );
			}
		}

		/* the same coordinates */
		return( 0 );
	}
	
	
	public static int scanLineOrderCompare( DSxyDNode node1, DSxyDNode node2 )
	{
		return( scanLineOrderCompare( node1.getX(), node1.getY(),
									  node2.getX(), node2.getY() ) );
	}
	
	
	public static int scanLineOrderCompare( DSxySearchTreeNode node1, DSxyDNode node2 )
	{
		return( scanLineOrderCompare( node1.getX(), node1.getY(),
				  					  node2.getX(), node2.getY() ) );
	}
	
	
	/* process edges that are incident to the "node" and are intersecting the scan line */
	/* eventQ has to be modified when a new intersection point is found */
	private static void processIncidentEdges_Delete(  	
												DSxyDNode node,    /* also means the position of the scan line */ 
												DSsearchTree R, 
												DSxySearchTree eventQ ) 
	{
		int scanLinePosX = node.getX();
		int scanLinePosY = node.getY();
		
		/* ==== remove from R ==== */
		
		/* next */
		if ( !( ( node.getNext().getY() < node.getY() ) || ( node.getNext().getY() == node.getY() && node.getNext().getX() > node.getX() ) ) ) {
			R.remove( node, scanLinePosX, scanLinePosY );
			System.out.println( "  remove edge (" + node.getX() + "," + node.getY() + ")-(" + node.getNext().getX() + "," + node.getNext().getY() + ") from R" );
			
			/* check the intersections */
		}
		/* prev */
		if ( !( ( node.getPrev().getY() < node.getY() ) || ( node.getPrev().getY() == node.getY() && node.getPrev().getX() > node.getX() ) ) ) {
			R.remove( node.getPrev(), scanLinePosX, scanLinePosY );
			System.out.println( "  remove edge (" + node.getPrev().getX() + "," + node.getPrev().getY() + ")-(" + node.getX() + "," + node.getY() + ") from R" );
			
			/* check the intersections */
		}

		/* ==== END ==== */	
		
	}  // END of processIncidentEdges_Delete()
	
	
	/* process edges that are incident to the "node" and are intersecting the scan line */
	/* eventQ has to be modified when a new intersection point is found */
	private static void processIncidentEdges_Insert(  	
												DSxyDNode node,    /* also means the position of the scan line */ 
												DSsearchTree R, 
												DSxySearchTree eventQ ) 
	{
		int scanLinePosX = node.getX();
		int scanLinePosY = node.getY();
		
		/* ==== insert into R ==== */
		
		/* next */
		if (   ( node.getNext().getY() < node.getY() ) || ( node.getNext().getY() == node.getY() && node.getNext().getX() > node.getX() )  ) {
			DSsearchTreeNode newEdge;
			
			/* insert the edge into R */
			newEdge = R.insert( node, scanLinePosX, scanLinePosY );  // returns the inserted new edge in R			
			System.out.println( "  insert edge (" + node.getX() + "," + node.getY() + ")-(" + node.getNext().getX() + "," + node.getNext().getY() + ") into R" );
			
			/* check the new intersections due to the new inserted edge */
			checkIntersectionsForNeighborEdges( R, newEdge, scanLinePosX, scanLinePosY, eventQ );
			
			/* check the intersections */			
		}
		/* prev */
		if (  ( node.getPrev().getY() < node.getY() ) || ( node.getPrev().getY() == node.getY() && node.getPrev().getX() > node.getX() )  ) {
			DSsearchTreeNode newEdge;
			
			/* insert the edge into R */
			newEdge = R.insert( node.getPrev(), scanLinePosX, scanLinePosY );  // returns the inserted new edge in R
			System.out.println( "  insert edge (" + node.getPrev().getX() + "," + node.getPrev().getY() + ")-(" + node.getX() + "," + node.getY() + ") into R" );
			
			/* check the new intersections due to the new inserted edge */
			checkIntersectionsForNeighborEdges( R, newEdge, scanLinePosX, scanLinePosY, eventQ );
			
			/* check the intersections */			
		}
		
		/* ==== END ==== */
				
	}  // END of processIncidentEdges_Insert()
	
	
	private static void checkIntersectionsForNeighborEdges( 
															DSsearchTree      R, 
															DSsearchTreeNode  currEdge,
															int               scanLinePosX,
															int               scanLinePosY,
															DSxySearchTree    eventQ ) 
	{
		/* ==== find the LEFT neighbor edge in R ==== */
		
		DSsearchTreeNode leftNeighborEdge = currEdge.getLeftNeighbor( R, scanLinePosX, scanLinePosY );
		
		/* calculate the existance of the new intersection vertex */
		Point newIntersectionPoint = calculateTheIntersectionOfTheTwoEdges( leftNeighborEdge, currEdge, scanLinePosX, scanLinePosY );
		
		if ( newIntersectionPoint!=null && eventQ.isExist( newIntersectionPoint )==false ) {
			/* Note that the "DSpolygon-->xyDList-->ht" is not updated. */
			
			System.out.println("    Intersection Point Processed.");
			
			DSxyDNode vertex1 = addANewVertexForTheEdge( leftNeighborEdge,  newIntersectionPoint );
			DSxyDNode vertex2 = addANewVertexForTheEdge( currEdge, newIntersectionPoint );
			
			/* insert the new vertex into eventQ */
			eventQ.insert( (int)newIntersectionPoint.getX(), (int)newIntersectionPoint.getY());
			
			/* insert into layer3_HT */
			insert_two_vertices_into_HT( layer3_HT, vertex1, vertex2 );
			
			/* update R */
			
			if ( leftNeighborEdge.getData().getNode().getY() < scanLinePosY ) {
				//System.out.println("WARNING - please update R");
				R.remove( leftNeighborEdge.getData().getNode(), scanLinePosX, scanLinePosY );
				R.insert( leftNeighborEdge.getData().getNode().getNext(), scanLinePosX, scanLinePosY );
			}
			if ( currEdge.getData().getNode().getY() < scanLinePosY ) {
				//System.out.println("WARNING - please update R");
				R.remove( currEdge.getData().getNode(), scanLinePosX, scanLinePosY );
				R.insert( currEdge.getData().getNode().getNext(), scanLinePosX, scanLinePosY );
			}
			
			//System.out.println("");
		}
		
		//System.out.println("");
		
		/* ==== find the RIGHT neighbor edge in R ==== */
		
		DSsearchTreeNode rightNeighborEdge = currEdge.getRightNeighbor( R, scanLinePosX, scanLinePosY );
		
		/* calculate the existance of the new intersection vertex */
		newIntersectionPoint = calculateTheIntersectionOfTheTwoEdges( rightNeighborEdge, currEdge, scanLinePosX, scanLinePosY );
		
		if ( newIntersectionPoint != null && eventQ.isExist( newIntersectionPoint )==false /* AND NOT IN eventQ */ ) {
			/* Note that the "DSpolygon-->xyDList-->ht" is not updated. */
			
			System.out.println("  Intersection Point Processed.");
			
			DSxyDNode vertex1 = addANewVertexForTheEdge( rightNeighborEdge,  newIntersectionPoint );
			DSxyDNode vertex2 = addANewVertexForTheEdge( currEdge, newIntersectionPoint );
			
			/* insert the new vertex into eventQ */
			eventQ.insert( (int)newIntersectionPoint.getX(), (int)newIntersectionPoint.getY());
			
			/* insert into layer3_HT */
			insert_two_vertices_into_HT( layer3_HT, vertex1, vertex2 );
			
			/* --- update R --- */			
			if ( rightNeighborEdge.getData().getNode().getY() < scanLinePosY ) {  // used to be "<"
				R.remove( rightNeighborEdge.getData().getNode(), scanLinePosX, scanLinePosY );
				R.insert( rightNeighborEdge.getData().getNode().getNext(), scanLinePosX, scanLinePosY );
			}
			//if ( newlyInsertedEdge.getData().getNode().getY() < scanLinePosY || ( newlyInsertedEdge.getData().getNode().getY()==scanLinePosY && vertex2.getY()==scanLinePosY && vertex2.getX() > scanLinePosX )  ) {  // may cause some problems
			//if ( newlyInsertedEdge.getData().getNode().getY() < scanLinePosY ) {  // may cause some problems
			if ( currEdge.getData().getNode().getY() < scanLinePosY || 
				( currEdge.getData().getNode().getY()==scanLinePosY && vertex2.getY()==scanLinePosY && currEdge.getData().getNode().getX()!=scanLinePosX ) )  // for horizontal newlyInsertedEdge  
			{ 
				R.remove( currEdge.getData().getNode(), scanLinePosX, scanLinePosY );
				R.insert( currEdge.getData().getNode().getNext(), scanLinePosX, scanLinePosY );
			}			
		}		
		//System.out.println("");
	}
	
	
	private static void collect_AND_surface(    DSxySearchTreeNode scanLinePos, 
												LinkedList         ll_1, 
												LinkedList         ll_2,
												Hashtable          lineSegmentsForBooleanAND )
	{	
		int cnt1 = 0;
		int cnt2 = 0;
		DSxyDNode n1=null, n2=null;
		
		/* --- layer 1 --- */
		if ( ll_1 != null ) {
			Iterator iterator1 = ll_1.listIterator();
			
			while ( iterator1.hasNext() ) {
				n1 = (DSxyDNode) iterator1.next();
				cnt1++;
				//System.out.println("  LAYER 1 : (" + n1.getX() + "," + n1.getY() + ")" );
			}
		}	
		
		/* --- layer 2 --- */
		if ( ll_2 != null ) {
			Iterator iterator2 = ll_2.listIterator();
			
			while ( iterator2.hasNext() ) {
				n2 = (DSxyDNode) iterator2.next();
				cnt2++;
				//System.out.println("  LAYER 2 : (" + n2.getX() + "," + n2.getY() + ")" );
			}
		}	
		
		if ( cnt1==0 || cnt2==0 ) {
			/* nothing to do for the Boolean-AND operation */
		}
		else if ( cnt1==1 && cnt2==1 ) {
			/* do something */
			//System.out.println("  LAYER 1 : (" + n1.getX() + "," + n1.getY() + ")" );
			//System.out.println("  LAYER 2 : (" + n2.getX() + "," + n2.getY() + ")" );
			/* n1.getX()==n2.getX(), n1.getY()==n2.getY()*/
			
			/* layer1_in --> layer1_out */
			double angle11 = CalculateAngle.angle( n1.getPrev().getX(), n1.getPrev().getY(), 
                    						  	   n1.getX(), n1.getY(), 
                    						  	   n1.getNext().getX(), n1.getNext().getY() );
			//System.out.println("    " + angle11 );
			
			/* layer1_in --> layer2_out */
			double angle12 = CalculateAngle.angle( n1.getPrev().getX(), n1.getPrev().getY(), 
					  							   n1.getX(), n1.getY(), 
					  							   n2.getNext().getX(), n2.getNext().getY() );				
			//System.out.println("    " + angle12 );
			
			/* layer2_in --> layer1_out */
			double angle21 = CalculateAngle.angle( n2.getPrev().getX(), n2.getPrev().getY(), 
					  							   n1.getX(), n1.getY(), 
					  							   n1.getNext().getX(), n1.getNext().getY() );
			//System.out.println("    " + angle21 );
			
			/* layer2_in --> layer2_out */
			double angle22 = CalculateAngle.angle( n2.getPrev().getX(), n2.getPrev().getY(), 
					  							   n1.getX(), n1.getY(), 
					  							   n2.getNext().getX(), n2.getNext().getY() );
			//System.out.println("    " + angle22 );
			
			/* there are 4 cases in total (angle11, angle12, angle21, angle22) */

			//lineSegmentsForBooleanAND = new Hashtable();
			
			int minimal = getMinimal( angle11, angle12, angle21, angle22);
			
			switch( minimal ) {
			case 1:		/* layer1_in --> layer1_out */
				//insert_an_edge_into_HT( lineSegmentsForBooleanAND, n1.getPrev() );
				insert_an_edge_into_HT( lineSegmentsForBooleanAND, n1 );
				break;
			case 2:		/* layer1_in --> layer2_out */
				//insert_an_edge_into_HT( lineSegmentsForBooleanAND, n1.getPrev() );
				insert_an_edge_into_HT( lineSegmentsForBooleanAND, n2 );
				break;
			case 3:		/* layer2_in --> layer1_out */
				//insert_an_edge_into_HT( lineSegmentsForBooleanAND, n2.getPrev() );
				insert_an_edge_into_HT( lineSegmentsForBooleanAND, n1 );
				break;
			case 4:		/* layer2_in --> layer2_out */
				//insert_an_edge_into_HT( lineSegmentsForBooleanAND, n2.getPrev() );
				insert_an_edge_into_HT( lineSegmentsForBooleanAND, n2 );
				break;
			default:
				/* do nothing */	
			}
												
		}
		else {
			//System.out.println("WARNING: unhandled case!");
		}			
	}
	
	
	/* returns a linked list of polygons */
	private static LinkedList extractPolygonsFormLineSegments( Hashtable lineSegmentsForBooleanAND )
	{
		LinkedList listOfPolygons = new LinkedList();
		
		/* First, get a line segment from "lineSegmentsForBooleanAND".
		 * The line segment can be any one.  
		 */		
		while( lineSegmentsForBooleanAND.size() !=0 )  /* not empty*/
		{
			Iterator it = lineSegmentsForBooleanAND.values().iterator();
			if ( it.hasNext()==false ) {
				return( listOfPolygons );
			}
		
			DSxyDNode node = (DSxyDNode) it.next();  // can be any node

			//System.out.println("===> " + node.getX() + "," + node.getY());
		
			DSxyList xyList = new DSxyList();
		
			DSxyDNode firstNode = node;
			xyList.insert( node.getX(), node.getY() );  // the first node in this xyList
		
			String htKey = node.getX() + "^" + node.getY();
			lineSegmentsForBooleanAND.remove( htKey );
		
			htKey = node.getNext().getX() + "^" + node.getNext().getY();
			node = (DSxyDNode) lineSegmentsForBooleanAND.get( htKey );
		
			while ( node!=null && node != firstNode ) {
				xyList.insert( node.getX(), node.getY() );
				htKey = node.getX() + "^" + node.getY();
				lineSegmentsForBooleanAND.remove( htKey );
			
				/* get next node */
				htKey = node.getNext().getX() + "^" + node.getNext().getY();
				node = (DSxyDNode) lineSegmentsForBooleanAND.get( htKey );
			}
		
			listOfPolygons.add( xyList );  /* add a polygon into the linked list
											* (accumulate polygons)
											*/
			
			//System.out.println( lineSegmentsForBooleanAND.size() );
			
			
		}  // END of while
		
		return( listOfPolygons );		
	}
	
	
	/*
	 * return the N-th value which is the minimal between the four arguments
	 */
	private static int getMinimal( double value1, double value2, double value3, double value4)
	{
		if ( value1 < value2 && 
			 value1 < value3 &&
			 value1 < value4) 
		{
			return(1);
		}
		
		if ( value2 < value1 && 
			 value2 < value3 &&
			 value2 < value4) 
		{
			return(2);
		}
		
		if ( value3 < value1 && 
			 value3 < value2 &&
			 value3 < value4) 
		{
			return(3);
		}
		
		if ( value4 < value1 && 
			 value4 < value2 &&
			 value4 < value3) 
		{
			return(4);
		}
		
		return(0);  // no minimum, maybe two or more minimal value		
	}
	
	
	/* insert a new vertex into the edge  */
	/* also split the edge into two edges */
	private static DSxyDNode addANewVertexForTheEdge( 
													DSsearchTreeNode  edge, 
													Point             newVertex )
	{
		DSxyDNode newNode = new DSxyDNode( (int) newVertex.getX(), (int) newVertex.getY() );
		
		DSxyDNode edgeStartNode = edge.getData().getNode();
		DSxyDNode edgeEndNode   = edge.getData().getNode().getNext(); 
		
		edgeStartNode.setNext( newNode );
		newNode.setNext( edgeEndNode );
		edgeEndNode.setPrev( newNode );
		newNode.setPrev( edgeStartNode );
		
		return( newNode );
	}
	
	
	public static Point calculateTheIntersectionOfTheTwoEdges(
												DSsearchTreeNode 	edge1, 
												DSsearchTreeNode 	edge2,
												int                 scanLinePosX,
												int					scanLinePosY)
	{
		if ( edge1==null || edge2==null ) {
			return( null );  // This should not happen.
		}
			
		int x1a = edge1.getData().getNode().getX();
		int y1a = edge1.getData().getNode().getY();
		int x1b = edge1.getData().getNode().getNext().getX();
		int y1b = edge1.getData().getNode().getNext().getY();
		int x2a = edge2.getData().getNode().getX();
		int y2a = edge2.getData().getNode().getY();
		int x2b = edge2.getData().getNode().getNext().getX();
		int y2b = edge2.getData().getNode().getNext().getY();
		
		Point pnt = calculateTheIntersectionOfTheTwoEdges( 	x1a, y1a, x1b, y1b, 
															x2a, y2a, x2b, y2b );
		
		if ( pnt==null ) {
			return( null );
		}
		if ( pnt.getX()==scanLinePosX && pnt.getY()==scanLinePosY ) {
			return( null);
		}
		
		System.out.println( "    intersection point: ( " + pnt.getX() + " , " + pnt.getY() + " )");
		
		return( pnt );
	}
	
	
	/* return the intersection vertex (p,q) */
	public static Point calculateTheIntersectionOfTheTwoEdges(
												double x1a, double y1a, double x1b, double y1b,
												double x2a, double y2a, double x2b, double y2b  ) 
	{
		/* if the intersection point lies on an end point of line segments */
		if ( (x1a==x2a && y1a==y2a) || (x1a==x2b && y1a==y2b) ) {
			return( new Point( (int)x1a, (int)y1a) );
		}
		if ( (x1b==x2a && y1b==y2a) || (x1b==x2b && y1b==y2b) ) {
			return( new Point( (int)x1b, (int)y1b) );
		}
		
		/* if edge1 is horizontal, but edge2 is not */
		if ( y1a==y1b && y2a!=y2b ) {
			PointInt p = Intersection.findIntersectionWithHorizontalLine( (int)x2a, (int)y2a, (int)x2b, (int)y2b, (int)y1a );
			return( new Point( p.getX(), p.getY() ) );			
		}		
		/* if edge2 is horiozntal, but edge1 is not */
		if ( y1a!=y1b && y2a==y2b ) {
			PointInt p = Intersection.findIntersectionWithHorizontalLine( (int)x1a, (int)y1a, (int)x1b, (int)y1b, (int)y2a );
			return( new Point( p.getX(), p.getY() ) );			
		}
		
		/* normal case: calculate the intersection point */
				
		double z1 = ( (x1b-x1a)/(y1a-y1b) ) - ( (x2b-x2a)/(y2a-y2b) );
		double z2 = (x1a*y1a-x1a*y1b-y1a*x1a+y1a*x1b) / (y1a-y1b);
		double z3 = (x2a*y2a-x2a*y2b-y2a*x2a+y2a*x2b) / (y2a-y2b);
		double q  = (z2-z3)/z1;
		double p = (x1a*y1a-x1a*y1b-y1a*x1a+y1a*x1b-(x1b-x1a)*q) / (y1a-y1b);
		
		/* return null if the intersection point (vertex) is not on edge1 and on edge2 */
		
		/* --- edge 1 --- */
		if ( x1a <= x1b ) {
			if ( p < x1a || x1b < p ) {
				return( null );
			}
		}
		else {  /* x1a > x1b */
			if ( p > x1a || x1b > p ) {
				return( null );
			}
		}
		
		if ( y1a <= y1b ) {
			if ( q < y1a || y1b < q ) {
				return( null );
			}
		}
		else {  /* y1a > y1b */
			if ( q > y1a || y1b > q ) {
				return( null );
			}
		}
		
		/* --- edge 2 --- */
		if ( x2a <= x2b ) {
			if ( p < x2a || x2b < p ) {
				return( null );
			}
		}
		else {  /* x2a > x2b */
			if ( p > x2a || x2b > p ) {
				return( null );
			}
		}
		
		if ( y2a <= y2b ) {
			if ( q < y2a || y2b < q ) {
				return( null );
			}
		}
		else {  /* y2a > y2b */
			if ( q > y2a || y2b > q ) {
				return( null );
			}
		}
		
		//System.out.println( "  intersection point: ( " + p + " , " + q + " )");
		
		return( new Point( (int)p, (int)q) );
	}
	
	
	private static void insert_vertices_into_HT( Hashtable ht,
												 LinkedList layer ) 
	{
		
		DSpolygon polygon;
		int       numOfVertices;
		
		Iterator iterator = layer.listIterator();
		
		/* for each polygon in the layer */
		while( iterator.hasNext() ) {
			polygon = (DSpolygon) iterator.next();
			numOfVertices = polygon.getNumberOfVertices();
			DSxyDNode vertex  = polygon.getNodeList().getHead();
			
			for ( int i=0; i < numOfVertices; i++ ) {
				
				insert_a_vertex_into_HT( ht, vertex );
				
				// next vertex
				vertex = vertex.getNext();
			}
		}
		
	}
	
	
	private static void insert_vertices_into_HT( 
											Hashtable ht,
											DSxyDList vertexDList,
											int numOfVertices ) 
	{
		DSxyDNode node = vertexDList.getHead();
		
		for ( int i=0; i< numOfVertices; i++ ) {
			
			/* print the (x,y) coordinate of the vertex */
			//System.out.println("    --> (" + node.getX() + "," + node.getY() + ")" );
			
			// the key of the Hashtable "ht"
			String HTkey = "" + node.getX() + "^" + node.getY();
			
			LinkedList ll;
			ll = (LinkedList) ht.get( HTkey );
			
			if ( ll == null ) {
				ll = new LinkedList();
				ll.add( node );
				ht.put( HTkey, ll );
			}
			else {
				ll.add( node );
				ht.remove( HTkey );
				ht.put( HTkey, ll );
			}
			
			node = node.getNext();  // get the next node
		}		
	}
	
	
	private static void insert_two_vertices_into_HT(
													Hashtable ht, 
													DSxyDNode vertex1,
													DSxyDNode vertex2 )	
	{
		insert_a_vertex_into_HT( ht, vertex1 );
		insert_a_vertex_into_HT( ht, vertex2 );		
	}
		
	
	private static void insert_a_vertex_into_HT( Hashtable ht, DSxyDNode vertex )
	{
		String htKey = "" + vertex.getX() + "^" + vertex.getY();
		
		LinkedList ll;
		ll = (LinkedList) ht.get( htKey );
		
		if ( ll == null ) {
			ll = new LinkedList();
			ll.add( vertex );
			ht.put( htKey, ll );
		}
		else {
			ll.add( vertex );
			ht.remove( htKey );
			ht.put( htKey, ll );
		}
	}
	
	
	/* the starting vertex can represent an edge */
	private static void insert_an_edge_into_HT( Hashtable ht, DSxyDNode edge )
	{
		//insert_a_vertex_into_HT( ht, edge );
		
		String htKey = edge.getX() + "^" + edge.getY();
		ht.put( htKey, edge );		
	}
	
	
	/* convert the singly linked list into doubly linked list (in clockwise order) */
	private static DSxyDList convertToDoublyLinkedListInClockwiseOrder( DSxyList xyList ) {
		
		DSxyDList vertexList = new DSxyDList();
		
		/* copy the signly linked list to the doubly linked list */
		
		for ( DSxyNode xyNode = xyList.getHead();
		      xyNode.getNext() != null;            /* skip the last vertex */
		      xyNode = xyNode.getNext() ) 
		{
			vertexList.insert( xyNode.getX(), xyNode.getY() );			
		}
		vertexList.connectHeadAndRear();
		
		/* check if the vertexList is in clockwise order */
		
		/* find the most left-bottom vertex */
		
		DSxyDNode tmpVertex = vertexList.getHead();
		
		DSxyDNode xyDNode = vertexList.getHead();
		for ( int i=1; i < xyList.getNumber(); i++, xyDNode=xyDNode.getNext() ) {
			if ( xyDNode.getX() < tmpVertex.getX() ) {
				tmpVertex = xyDNode;
			}
			else if ( (xyDNode.getX() == tmpVertex.getX() ) && (xyDNode.getY() < tmpVertex.getY() ) ) {
				tmpVertex = xyDNode;
			}
		}
		
		double slopeNext = Utilities.calculateSlope( tmpVertex.getX(), tmpVertex.getY(), tmpVertex.getNext().getX(), tmpVertex.getNext().getY() );    //( (double)tmpVertex.getY() - (double)tmpVertex.getNext().getY() ) / ( (double)tmpVertex.getX() - (double)tmpVertex.getNext().getX() );
		double slopePrev = Utilities.calculateSlope( tmpVertex.getX(), tmpVertex.getY(), tmpVertex.getPrev().getX(), tmpVertex.getPrev().getY() );    //( (double)tmpVertex.getY() - (double)tmpVertex.getNext().getY() ) / ( (double)tmpVertex.getX() - (double)tmpVertex.getNext().getX() ); //( (double)tmpVertex.getPrev().getY() - (double)tmpVertex.getY() ) / ( (double)tmpVertex.getPrev().getX() - (double)tmpVertex.getX() );
		
		boolean isClockwise = false;
		if ( slopeNext > slopePrev ) {
			isClockwise = true;
		}
		
		/* reverse the doubly linked list if it is not in clockwise order */
		if ( isClockwise == false ) {
			vertexList.reverse( xyList.getNumber()-1 );
		}
		
		return( vertexList );
	}
	
	
	/* eventQ holds the value (x,y), which stands for the position of the scan line */
	private static DSxySearchTree ConstructEventQueue( 
												LinkedList  layer1_polygons, 
												LinkedList  layer2_polygons) 
	{
		DSxySearchTree eventQ = new DSxySearchTree();
		
		/* layer 1 */
		
		Iterator iterator = layer1_polygons.listIterator();
		
		while( iterator.hasNext() ) {
			DSpolygon polygon = (DSpolygon) iterator.next();
			DSxyDNode vertex  = polygon.getNodeList().getHead();
			
			for ( int i=0; i < polygon.getNumberOfVertices(); i++ ) {
				eventQ.insert( vertex.getX(), vertex.getY() );
				vertex = vertex.getNext();
			}
			
			//System.out.println("-----");
		}
		
		/* layer 2 */
		
		iterator = layer2_polygons.listIterator();
		
		while( iterator.hasNext() ) {
			DSpolygon polygon = (DSpolygon) iterator.next();
			DSxyDNode vertex  = polygon.getNodeList().getHead();
			
			for ( int i=0; i < polygon.getNumberOfVertices(); i++ ) {
				eventQ.insert( vertex.getX(), vertex.getY() );
				vertex = vertex.getNext();
			}
			
			//System.out.println("-----");
		}
	
		return( eventQ );
	}
	
	
	private static void outputLayoutToASCII( LinkedList layer1_polygons,
										     LinkedList layer2_polygons,
										     LinkedList listOfPolygons ) 
	{
		//System.out.println("\n==== Boolean results ====");
		
		String tmpFileName = "owlvision.tmp.txt";
		
		File 					tmpFile = new File(tmpFileName);
		String                  tmpOutputFile = tmpFile.getAbsolutePath();
		FileOutputStream 		outputFileStream;
		BufferedOutputStream 	outputFileStream_b;
		PrintStream 			printStream = null;
		
		try {
			outputFileStream   = new FileOutputStream(tmpFile);
			outputFileStream_b = new BufferedOutputStream(outputFileStream);
			printStream = new PrintStream(outputFileStream_b);
		} catch (FileNotFoundException e) {
			// CANNOT WRITE TO THE FILE
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
				
		printStream.println("HEADER 600;  # version");
		printStream.println("BGNLIB;");
		printStream.println(" LASTMOD  {2006-2-10  17:8:41};  # last modification time");
		printStream.println(" LASTACC  {2006-2-10  17:8:41};  # last access time");
		printStream.println("LIBNAME OwlVision.db;");
		printStream.println("UNITS;");
		printStream.println(" USERUNITS 0.0010;");
		printStream.println(" PHYSUNITS 9.999999999999999E-10;");
		printStream.println();
		printStream.println("BGNSTR;  # Begin of structure");
		printStream.println(" CREATION {2006-2-10  4:43:34};  # creation time");
		printStream.println(" LASTMOD  {2006-2-10  4:43:34};  # last modification time");
		printStream.println("STRNAME BOOLEAN;");
		printStream.println(); 
		
		/* ==== layer1_polygons ==== */		
		writePolygonsToASCII( printStream, layer1_polygons, layer1 );		
		
		/* ==== layer2_polygons ==== */
		writePolygonsToASCII( printStream, layer2_polygons, layer2 );
		
		/* ==== listOfPolygons ==== */
				
		Iterator it = listOfPolygons.iterator();
		
		DSxyList polygon;
		while ( it.hasNext() ) {
			polygon = (DSxyList) it.next();
			//System.out.println("--------------------");
			
			//System.out.println("");
			
			DSxyNode node = polygon.getHead();
			DSxyNode nFirst = null;
			int numOfVertices = polygon.getNumber();
			int numOfVerticesAdd1 = numOfVertices + 1;
			
			printStream.println("");
			printStream.println("BOUNDARY;");
			printStream.println("LAYER " + outputLayer + ";");
			printStream.println("DATATYPE 0;");
			printStream.println("XY " + numOfVerticesAdd1 + ";");
						
			for (int i=0; i<numOfVertices; i++) {
				//System.out.println("    " + node.getX() + "," + node.getY() );
				if ( i==0 ) {
					nFirst = node;
				}
				printStream.println("  X: " + node.getX() + ";\t\t\tY: " + node.getY() + ";");
				node = node.getNext();
			}
			printStream.println("  X: " + nFirst.getX() + ";\t\t\tY: " + nFirst.getY() + ";");
			printStream.println("ENDEL;");
		}
		
		printStream.println("");
		printStream.println("ENDSTR;");
		printStream.println("");
		printStream.println("ENDLIB;");
		
		printStream.close();
		
		/* ASCII --> GDSII */
		
		//String outputGDSIIname = fileTo.getAbsolutePath();
		
		ASCII2GDSII.MainMethod( tmpOutputFile, outputFileName );
		OwlVisionFile.deleteFile( tmpOutputFile );
	}
	
	
	private static void writePolygonsToASCII( 	PrintStream printStream,
												LinkedList  polygons_in_the_layer,
												int         layerNo ) 
	{		
		Iterator it = polygons_in_the_layer.iterator();
		
		DSpolygon polygonInLayer1;
		
		while ( it.hasNext() ) {
			
			polygonInLayer1 = (DSpolygon) it.next();
			int numOfVertices = polygonInLayer1.getNumberOfVertices();
			int numOfVerticesAdd1 = numOfVertices + 1;
			DSxyDNode vertex = polygonInLayer1.getNodeList().getHead();
			DSxyDNode vFirst = null; 
			
			printStream.println("");
			printStream.println("BOUNDARY;");
			printStream.println("LAYER " + layerNo + ";");
			printStream.println("DATATYPE 0;");
			printStream.println("XY " + numOfVerticesAdd1 + ";");
			
			for ( int i=0; i<numOfVertices; i++ ) {
				if (i==0) {
					vFirst = vertex;
				}
				printStream.println("  X: " + vertex.getX() + ";\t\t\tY: " + vertex.getY() + ";");
				vertex = vertex.getNext();
			}
			printStream.println("  X: " + vFirst.getX() + ";\t\t\tY: " + vFirst.getY() + ";");  // repeat the first node once
			printStream.println("ENDEL;");
		}		
	}
	
	
	private static void DEBUG_get_layer1_and_layer2_polygons(
												LinkedList  layer1_polygons, 
												LinkedList  layer2_polygons)
	{
		
		DSxySearchTree eventQ = new DSxySearchTree();
		
		/* layer 1 */
		
		Iterator iterator = layer1_polygons.listIterator();
		
		while( iterator.hasNext() ) {
			DSpolygon polygon = (DSpolygon) iterator.next();
			DSxyDNode vertex  = polygon.getNodeList().getHead();
			/*
			for ( int i=0; i < polygon.getNumberOfVertices(); i++ ) {
				vertex = vertex.getNext();
			}
			*/
			System.out.print("");
		}
		
		/* layer 2 */
		
		iterator = layer2_polygons.listIterator();
		
		while( iterator.hasNext() ) {
			DSpolygon polygon = (DSpolygon) iterator.next();
			DSxyDNode vertex  = polygon.getNodeList().getHead();
			/*
			for ( int i=0; i < polygon.getNumberOfVertices(); i++ ) {
			
				vertex = vertex.getNext();
			}
			*/
			System.out.print("");
		}	
	}
	
	
	private static void updateNumOfVertices( LinkedList layerContainsPolygons ) {
	
		Iterator iterator = layerContainsPolygons.listIterator();
		
		while( iterator.hasNext() ) {
			DSpolygon polygon = (DSpolygon) iterator.next();
			DSxyDNode vertex  = polygon.getNodeList().getHead();
			DSxyDNode firstVertex = vertex;
			
			int numOfVertices = 0;
			boolean isFirst = true;
			
			while ( true ) {
				
				if ( isFirst==false ) {
					if ( vertex==firstVertex ) {
						break;
					}
				}				
				else {
					isFirst = false;
				}
				
				numOfVertices++;
				
				/* get the next vertex */
				vertex = vertex.getNext();				
			}
			
			polygon.setNumberOfVertices( numOfVertices );
			
		}  // END of while
		
		
		
	}

}
