/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class BoundingBox {
	
	/* The Bounding Box of a cell */
	
	private int minX;  // Min X
	private int maxX;  // Max X
	private int minY;  // Min Y
	private int maxY;  // Max Y
	
	public BoundingBox( int xMin, int xMax, int yMin, int yMax ) {
		minX = xMin;
		maxX = xMax;
		minY = yMin;
		maxY = yMax;
	}
	
	public void set( int xMin, int xMax, int yMin, int yMax ) {
		minX = xMin;
		maxX = xMax;
		minY = yMin;
		maxY = yMax;
	}
	
	public void setMinX( int value ) {
		minX = value;
	}
	
	public void setMaxX( int value ) {
		maxX = value;
	} 
	
	public void setMinY( int value ) {
		minY = value;
	}
	
	public void setMaxY( int value ) {
		maxY = value;
	}
	
	public int getMinX() {
		return(minX);
	}
	
	public int getMaxX() {
		return(maxX);
	} 
	
	public int getMinY() {
		return(minY);
	}
	
	public int getMaxY() {
		return(maxY);
	}
	
	public int getMidX() {
		return( (minX + maxX) / 2 );
	}
	
	public int getMidY() {
		return( (minY + maxY) / 2 );
	}

}
