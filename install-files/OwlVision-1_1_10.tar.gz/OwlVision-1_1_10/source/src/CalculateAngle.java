/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class CalculateAngle {
	
public static void test(String[] args) {
		
		System.out.println( angle(2,1) );
		System.out.println( angle(-2,-1) );
		System.out.println( angle(-2,-1) - angle(2,1) );
		System.out.println( angle(2,1,-2,-1) );
		System.out.println( angle(3,2,-2,1) );
		System.out.println( angle(3,2,0,0,-2,1) );
		System.out.println( angle(4,3,1,1,-1,2) );
		System.out.println( angle(27,27,27,20,20,20) );  // 90 degrees
		System.out.println( angle(27,20,20,20,27,27) );  // 45 degrees
		System.out.println( angle(27,20,27,27,20,20) );  // (360-45)=315 degrees
		System.out.println("--------------------");
		System.out.println( angle(0,-10) );
		System.out.println( angle(1,1) );
		System.out.println( angle(0,-10,1,1) );
		System.out.println( angle(1,1,-1,-10) );
		System.out.println("--------------------");
		System.out.println( angle(2,5,4,1) );
	}
	
	/** calculate angles in dgree
	 * 
	 *         / (x, y)
	 *        /
	 *       /   return
	 *      /    this angle
	 *     /____________________ X-axis
	 *                     
	 */
	public static double angle(double x, double y) 
	{	
		if (x>=0 && y==0) {
			return(0.0);
		}
		else if (x<0 && y==0) {
			return(180.0);
		}
		else if (x==0 && y>0) {
			return(90.0);
		}
		else if (x==0 && y<0) {
			return(270.0);
		}
		else if (x>0 && y>0) {
			return(Math.toDegrees(Math.atan(y/x)));
		}
		else if (x<0 && y>0) {
			return(180 - Math.toDegrees(Math.atan(y/-x)));
		}
		else if (x<0 && y<0) {
			return(180 + Math.toDegrees(Math.atan(y/x)));
		}
		else {
			//assert x>0 && y<0;
			return(360 - Math.toDegrees(Math.atan(-y/x)));
		}
	}  // angle(x,y)
	
	
	/** calculate angles in dgree
	 * 
	 *         / (x2, y2)
	 *        /
	 *       /  angle   _ (x1, y1)
	 *      /       _ -
	 *     /    _ -
	 *    / _ -              
	 */   
	public static double angle( double x1, double y1, 
								double x2, double y2) 
	{	
		double result = angle(x2,y2) - angle(x1,y1);
		
		if (result<0) {
			result = 360 + result;
		}
		return(result);
	
	}  // angle(x1,y1,x2,y2)
	
	
	/** calculate angles in dgree
	 * 
	 *         / (x3, y3)
	 *        /
	 *       /  angle   _ (x1, y1)
	 *      /       _ -
	 *     /    _ -
	 *    / _ -         
	 *  (x2, y2)    
	 */   
	public static double angle( double x1, double y1, 
								double x2, double y2, 
								double x3, double y3) 
	{	
		double result = angle(x3-x2,y3-y2) - angle(x1-x2,y1-y2);
		
		if (result<0) {
			result = 360 + result;
		}
		return(result);
	}  // angle(x1,y1,x2,y2,x3,y3)

	
}
