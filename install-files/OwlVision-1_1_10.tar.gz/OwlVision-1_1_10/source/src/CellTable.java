/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import javax.swing.table.AbstractTableModel;

public class CellTable extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String[] headings = new String[] {
			"Cell Name", "Display"
			//"Layer No.", "Display?", "Color"
	};
	
	/*
	private Object[][] data = new Object[][] {
			{ "49", Boolean.TRUE },
			{ "50", Boolean.FALSE },
			{ "51", Boolean.TRUE },
			{ "52", Boolean.FALSE }, 
	}; */
	
	
	public static Object[][] data = new Object[][] { 
		{ " ", Boolean.FALSE }
	}; 
	
	public int getRowCount() {
		return( data.length );
	}
	
	public int getColumnCount() {
		return( data[0].length );
	}
	
	public Object getValueAt(int row, int column) {
		return( data[row][column] );
	}
	
	public String getColumnName(int column) {
		return( headings[column] );
	}
	
	public Class getColumnClass(int column) {
		return( data[0][column].getClass() );
	}
	
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if ( columnIndex == 1 )		
			return(true);
		else
			return(false);
	}
	
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		//System.out.println("[ " + rowIndex + ", "+ columnIndex + " ]" );
		
		if ( columnIndex == 1 ) {
			if ( data[rowIndex][1] == Boolean.TRUE ) {
				data[rowIndex][1] = Boolean.FALSE;
				setCellInfo( rowIndex, columnIndex, false );
			}
			else {
				data[rowIndex][1] = Boolean.TRUE;
				setCellInfo( rowIndex, columnIndex, true );
			}
		}
	} 
			
	public void setCellInfo(int rowIndex, int columnIndex, boolean value) {
		if (value == true) {  // set to true
			//System.out.println("Please display layer_no: " + data[rowIndex][0] );
			CellTableInfo.removeDontDisplayCellHT( data[rowIndex][0].toString() );
		}
		else {  // set to false
			//System.out.println("Please do not display layer_no: " + data[rowIndex][0] );
			CellTableInfo.addDontDisplayCellHT( data[rowIndex][0].toString() );
		}
		DrawLayout.isRedrawImage(true);  // new
		PanelCenter.g2D.repaint();	// redraw the layout
	} 


}
