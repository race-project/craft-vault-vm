/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class DSarefList {
	
	private DSarefNode	head;
	private DSarefNode	tail;
	private int			number;
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public DSarefList() {
		head   = null;
		tail   = null;
		number = 0;
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public boolean isEmpty() 
	{
		return(head == null);
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public void insert(DSarefNode bNode) 
	{
		if (isEmpty()) {
			head = tail = bNode;			
		}
		else {
			tail.setNext( bNode );
			tail = bNode;
		}
		number++;
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public DSarefNode getHead() 
	{
		return( head );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public DSarefNode getTail() 
	{
		return( tail );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public int getNumber() 
	{
		return( number );
	}
	
}
