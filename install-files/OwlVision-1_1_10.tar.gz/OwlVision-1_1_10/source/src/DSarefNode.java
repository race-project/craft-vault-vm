/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/* Author:  I-Lun Tseng
 * History: 2006/11/09 - created
 * 			2006/11/10 - initial version completed
 */

public class DSarefNode {
	
	private String		 strName;
	private DSstrans 	 strans;
	private double       angle;
	private DScolrow	 colrow;
	private DSxyList	 xy;
	private DSarefNode	 next;
	
	
	/* constructor */
	public DSarefNode( 	String		str_name,
						DSstrans	stransIn,
						double		ang,
						DScolrow	colrowIn,
						DSxyList	xy_list,
						DSarefNode	n
						)
	{
		strName = str_name;
		strans	= stransIn;
		angle   = ang;
		colrow  = colrowIn;
		xy		= xy_list;
		next	= n;
	}
	
	/* constructor */
	public DSarefNode( DSarefNode arefNode ) 
	{
		strName     = arefNode.getStrName();
		strans      = arefNode.getStrans();
		angle		= arefNode.getAngle();
		colrow      = arefNode.getColrow();
		xy          = arefNode.getXYlist();
		next	    = null;
	}
	
	/* --- strName --- */
	
	public String getStrName() {
		return( strName );
	}
	
	/* --- strans --- */
	
	public DSstrans getStrans() {
		return( strans );
	}
	
	/* --- angle --- */
	
	public double getAngle() {
		return( angle );
	} 
	
	/* --- colrow --- */
	
	public DScolrow getColrow() {
		return( colrow );
	}
	
	/* --- xy --- */
	
	public DSxyList getXYlist() {
		return( xy );
	}
	
	/* --- next --- */
	
	public DSarefNode getNext() 
	{
		return( next );
	}
	
	public void setNext( DSarefNode n ) 
	{
		next = n;
	}
	

}
