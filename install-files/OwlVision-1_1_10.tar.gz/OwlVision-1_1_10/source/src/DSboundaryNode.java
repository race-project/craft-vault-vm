/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 14/04/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author I-Lun Tseng
 *
 * A boundary element means a polygon.
 * 
 */
public class DSboundaryNode {
	
	private short 			layer;	   // value range 0-255
	private short 			datatype;  // value range 0-255	
	private DSxyList		xy;
	private boolean         isPath;    // Is this BOUNDARY element translated from PATH element?
	private BoundingBox     bbox;	   // the bounding box of the polygon
	private DSboundaryNode  next;
	
	/* constructor */	
	public DSboundaryNode(int 			 in_layer,
						  int 			 in_datatype,
						  DSxyList 		 in_xy_list,
						  DSboundaryNode in_next) 
	{
		layer    = (short) in_layer;
		datatype = (short) in_datatype;
		xy       = in_xy_list;
		isPath   = false;
		next	 = in_next;
	}
	
	/* constructor */
	public DSboundaryNode( DSboundaryNode bdNode ) 
	{
		layer    = (short) bdNode.getLayerNo();
		datatype = (short) bdNode.getDatatype();
		xy       = bdNode.getXYlist();
		isPath   = bdNode.isPath();
		bbox     = bdNode.getBbox();
		next	 = null;
	}	
	
	/* layer */
	
	public int getLayerNo() {
		return(layer);
	}
	
	/* datatype */
	
	public int getDatatype() {
		return( datatype );
	}
	
	/* xy */
	
	public DSxyList getXYlist() {
		return( xy );
	}
	
	/* isPath */
	
	public boolean isPath() {
		return( isPath );
	}
	
	public void setIsPath( boolean value ) {
		isPath = value;
	}
	

	/* next */
	
	public DSboundaryNode getNext() {
		return( next );
	}
	
	public void setNext( DSboundaryNode n ) {
		next = n;
	}
	
	/* bounding box */
	
	public BoundingBox getBbox() {
		return( bbox );
	}
	
	public void setBbox(int x1, int x2, int y1, int y2) {
		bbox = new BoundingBox( x1,x2,y1,y2 );
	}
	
	public int getMinX() {
		return( bbox.getMinX() );
	}
	public int getMaxX() {
		return( bbox.getMaxX() );
	}
	public int getMinY() {
		return( bbox.getMinY() );
	}
	public int getMaxY() {
		return( bbox.getMaxY() );
	}
	
}
