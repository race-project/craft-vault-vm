/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/15
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DSboxNode {
	
	private short 		 layer;
	private short 		 datatype;
	private DSxyList	 xy;
	private BoundingBox  bbox;  // the bounding box for the polygon
	private DSboxNode    next;
	
	
	
	public DSboxNode(int 		lay,
					 int 		dat,
					 DSxyList	xy_list,
					 DSboxNode  n) 
	{
		layer    = (short) lay;
		datatype = (short) dat;
		xy       = xy_list;
		next	 = n;
	}
	
	public DSboxNode( DSboxNode boNode ) 
	{
		layer    = (short) boNode.getLayerNo();
		datatype = (short) boNode.getDatatype();
		xy       = boNode.getXYlist();
		bbox     = boNode.getBbox();
		next	 = null;
	}	
	
	/* layer */
	
	public int getLayerNo() {
		return( layer );
	}

	/* datatype */
	
	public int getDatatype() {
		return( datatype );
	}
	
	/* xy */
	
	public DSxyList getXYlist() {
		return( xy );
	}

	/* next */
	
	public DSboxNode getNext() {
		return( next );
	}
	
	public void setNext( DSboxNode n ) {
		next = n;
	}
	
	/* bounding box */
	
	public BoundingBox getBbox() {
		return( bbox );
	}
	
	public void setBbox(int x1, int x2, int y1, int y2) {
		bbox = new BoundingBox( x1,x2,y1,y2 );
	}
	
	public int getMinX() {
		return( bbox.getMinX() );
	}
	public int getMaxX() {
		return( bbox.getMaxX() );
	}
	public int getMinY() {
		return( bbox.getMinY() );
	}
	public int getMaxY() {
		return( bbox.getMaxY() );
	}

}
