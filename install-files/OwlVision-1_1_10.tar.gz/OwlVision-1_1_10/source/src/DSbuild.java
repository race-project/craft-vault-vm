/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


//import java.awt.Graphics2D;
import java.awt.Point;
//import java.awt.Polygon;
import java.util.Hashtable;

//import javax.swing.JOptionPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;

/*
 * Created on 14/04/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DSbuild {
	
	/* structure (cell) */
	public static DSstrList		 	strList;	// the (whole) layout data start here
	public static DSstrNode		 	strNode;			
	/* boundary */
	public static DSboundaryNode 	boundaryNode;
	public static DSboundaryList 	boundaryList;
	/* box */
	public static DSboxNode 		boxNode;	
	public static DSboxList 		boxList;
	/* boundary */
	public static DStextNode 		textNode;
	public static DStextList 		textList;
	/* AREF */
	public static DSsrefNode 		srefNode;
	public static DSsrefList 		srefList;
	/* AREF */
	public static DSarefNode		arefNode;
	public static DSarefList		arefList;
	/* path */
	public static DSpathNode 		pathNode;
	public static DSpathList 		pathList;
	
	public static DSstrNode 		rootStrNode;  // remember the root cell

	public static double 			final_X;	// OBSOLETE
	public static double 			final_Y;	// OBSOLETE
	
	private static int 				minX = 0, maxX = 0, minY = 0, maxY = 0;  // bounding box for the whole layout
	private static boolean 			initial_set = false;
	
	private static String			selectedCell = null;
	
	
	public static void reset() 
	{
		initial_set = false;
		
		minX = 0;
		maxX = 0;
		minY = 0;
		maxY = 0;
		
		strList = null;
		strNode = null;
		
		boundaryNode = null;
		boundaryList = null;
		
		boxNode = null;
		boxList = null;
		
		textNode = null;
		textList = null;
		
		srefNode = null;
		srefList = null;
		
		arefNode = null;
		arefList = null;
		
		pathNode = null;
		pathList = null;
		
		rootStrNode = null;
	}
	
	
	public static void chooseCellReset() {
		initial_set = false;
		minX=0;
		maxX=0;
		minY=0;
		maxY=0;
	} 
	
	/* BOUNDARY */
	public static void insert_boundaryList_to_strNode() {
		strNode.setBoundaryList( boundaryList );
	}
	
	/* BOX */
	public static void insert_boxList_to_strNode() {
		strNode.setBoxList( boxList );
	}
	
	/* SREF */
	public static void insert_srefList_to_strNode() {
		strNode.setSrefList( srefList );
	}
	
	/* AREF */
	public static void insert_arefList_to_strNode() {
		strNode.setArefList( arefList );
	}
	
	/* PATH */
	public static void insert_pathList_to_strNode() {
		strNode.setPathList( pathList );
	}
	
	/* TEXT */
	public static void insert_textList_to_strNode() {
		strNode.setTextList( textList );
	}
	                   
	public static void insert_strNode_to_strList() {
		strList.insert(strNode);
	}
	
	public static void print() {
		
		for (DSstrNode str_node = strList.getHead(); 
		     str_node!=null; 
		     str_node=str_node.getNext() ) 
		{
			System.out.println("STRNAME " + str_node.getName() + ";");
			
			for (DSboundaryNode b_node=str_node.getBoundaryList().getHead();
			     b_node!=null;
			     b_node=b_node.getNext() )
			{
				System.out.println("BOUNDARY;");
				System.out.println("LAYER " + b_node.getLayerNo() + ";");
				System.out.println("DATATYPE " + b_node.getDatatype() + ";");
				
				for (DSxyNode xy_node=b_node.getXYlist().getHead();
				     xy_node!=null;
				     xy_node=xy_node.getNext() )
				{
					System.out.print(" X: " + xy_node.getX() + ";\t\t");
					System.out.println("Y: " + xy_node.getY() + ";");	
				}	
			}	
		}
	}
	
	
	public static boolean isThisPolygonTooSmall(int minX, int maxX, int minY, int maxY) {
		//System.out.println(" SCREEN LOC: " + draw_polygons.trans_X(minX) + ", " + draw_polygons.trans_X(maxX) + ", " + draw_polygons.trans_Y(minY) + ", " + draw_polygons.trans_Y(maxY)  );
		/* too small if less than 3 pixels */
		if ( (SizeSetting.trans_X(maxX) - SizeSetting.trans_X(minX) < 3) && 
			 (SizeSetting.trans_Y(minY) - SizeSetting.trans_Y(maxY) < 3) )
			{
				// too small
				//System.out.println(" SCREEN LOC: " + draw_polygons.trans_X(minX) + ", " + draw_polygons.trans_X(maxX) + ", " + draw_polygons.trans_Y(minY) + ", " + draw_polygons.trans_Y(maxY)  );
				return( true );
			} 
		return( false );		
	}
	
	
	/* check BOUNDARY */
	public static boolean mayIdisplayThisElement( DSboundaryNode ele) {
		
		if ( LayerTableInfo.mayIdisplayLayer( ele.getLayerNo() ) == false ) {
    		return( false );
    	}
    	/* check the size of the bounding box */
    	//System.out.println( "boundary bbox: " + b_node.getMinX() + ", " + b_node.getMaxX() + ", " + b_node.getMinY() + ", " + b_node.getMaxY() );
    	if ( isThisPolygonTooSmall( ele.getMinX(), ele.getMaxX(), ele.getMinY(), ele.getMaxY() )==true  ) {
    		//System.out.println(" TOO SMALL.");
    		// Should draw a dot instead
    		return( false );
    	}		
    	/*
    	if ( isThePolygonOutsideWindow( ele.getMinX(), ele.getMaxX(), ele.getMinY(), ele.getMaxY() ) == true ) {
    		return( false);
    	}
    	*/
		return( true );
	} 	

	
	/* check BOX */
	public static boolean mayIdisplayThisElement( DSboxNode ele ) {
		
		if ( LayerTableInfo.mayIdisplayLayer( ele.getLayerNo() ) == false ) {
    		return( false );
    	}
    	/* check the size of the bounding box */
    	//System.out.println( "boundary bbox: " + b_node.getMinX() + ", " + b_node.getMaxX() + ", " + b_node.getMinY() + ", " + b_node.getMaxY() );
    	if ( isThisPolygonTooSmall( ele.getMinX(), ele.getMaxX(), ele.getMinY(), ele.getMaxY() )==true  ) {
    		//System.out.println(" TOO SMALL.");
    		// Should draw a dot instead
    		return( false );
    	}
    	/*
    	if ( isThePolygonOutsideWindow( ele.getMinX(), ele.getMaxX(), ele.getMinY(), ele.getMaxY() ) == true ) {
    		return( false);
    	}
    	*/
		return( true );
	}
	
	
	/* check TEXT */
	public static boolean mayIdisplayThisElement( DStextNode ele ) {
		
		if ( LayerTableInfo.mayIdisplayLayer( ele.getLayerNo() ) == false ) {
    		return( false );
    	}
    	    	
		return( true );
	}

	
	/* check PATH */
	public static boolean mayIdisplayThisElement( DSpathNode ele ) {
		
		if ( LayerTableInfo.mayIdisplayLayer( ele.getLayerNo() ) == false ) {
    		return( false );
    	}
    	/* check the size of the bounding box */
    	//System.out.println( "boundary bbox: " + b_node.getMinX() + ", " + b_node.getMaxX() + ", " + b_node.getMinY() + ", " + b_node.getMaxY() );
    	if ( isThisPolygonTooSmall( ele.getMinX(), ele.getMaxX(), ele.getMinY(), ele.getMaxY() )==true  ) {
    		//System.out.println(" TOO SMALL.");
    		// Should draw a wire instead
    		return( false );
    	}    	
		return( true );
	}

	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - turns clockwise rotation into counter-clockwise rotation 
	 * 
	 */
	public static Point rotate(int X, int Y, double r_angle) 
	{
		Point point;
		
		r_angle = r_angle % 360;	// angle to be rotated
		
		if (r_angle==0) {
			final_X = X;
			final_Y = Y;
			point = new Point( (int)final_X, (int)final_Y); 
			return( point );
		}
		
		/* turns clockwise rotation into counter-clockwise rotation */
		if ( 0 < r_angle && r_angle < 360 ) {
			r_angle = 360 - r_angle;
		}
		
		// int current_section = coordinate_section(X, Y);
		// double current_angle = coordinate_angle(X, Y);
		
		//System.out.println("occrdinate_angle ==> " + coordinate_angle(-2,1));
		//int final_section = rotated_section(current_section, current_angle, r_angle);
		//double final_angle = rotated_angle(current_section, current_angle, r_angle);
		
		//System.out.println("final_section: " + final_section);
		double xy_angle = angle(X,Y);
		double rotated_angle = xy_angle - r_angle;	// rotated angle to the X-axis
		double xy_length = Math.sqrt( Math.pow(X,2) + Math.pow(Y,2) );
		double r = xy_length;
		double ang;
		
		if (rotated_angle==0) {			
			// positive X-axis
			final_X = xy_length;
			final_Y = 0;
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle == 90 || rotated_angle == -270) {	
			// positive Y-axis
			final_X = 0;
			final_Y = xy_length;
			point = new Point( (int)final_X, (int)final_Y);
			return(point ) ;
		}
		else if (rotated_angle == 180 || rotated_angle == -180) {	
			// negative X-axis
			final_X = (-1)*xy_length;
			final_Y = 0;
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle == 270 || rotated_angle == -90) {	
			// negative Y-axis
			final_X = 0;
			final_Y = (-1)*xy_length;
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > 0 && rotated_angle < 90) {
			ang = Math.toRadians(rotated_angle);
			final_X = r*Math.cos( ang );
			final_Y = r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > -360 && rotated_angle < -270) {
			ang = Math.toRadians(rotated_angle+360);
			final_X = r*Math.cos( ang );
			final_Y = r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > 90 && rotated_angle < 180) {
			ang = Math.toRadians(180-rotated_angle);
			final_X = (-1)*r*Math.cos( ang );
			final_Y =      r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > -270  && rotated_angle < -180 ) {
			ang = Math.toRadians((-1)*(rotated_angle+180));
			final_X = (-1)*r*Math.cos( ang );
			final_Y =      r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > 180   && rotated_angle < 270 ) {
			ang = Math.toRadians(rotated_angle-180);
			final_X = (-1)*r*Math.cos( ang );
			final_Y = (-1)*r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > -180  && rotated_angle < -90 ) {
			ang = Math.toRadians(rotated_angle+180);
			final_X = (-1)*r*Math.cos( ang );
			final_Y = (-1)*r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > 270  && rotated_angle < 360 ) {
			ang = Math.toRadians(360-rotated_angle);
			final_X =      r*Math.cos( ang );
			final_Y = (-1)*r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else if (rotated_angle > -90   && rotated_angle < 0 ) {
			ang = Math.toRadians((-1)*rotated_angle);
			final_X =      r*Math.cos( ang );
			final_Y = (-1)*r*Math.sin( ang );
			point = new Point( (int)final_X, (int)final_Y);
			return( point );
		}
		else {
			return( null );  /* ERROR */
		}
	}
	
	
	/* Done */
	/****************************************************************
	 *  Coordinate Section Number
	 *  
	 *                  6
	 * 					|
	 * 			    2	|   1
	 * 					|
	 * 		   7 -------+-------> 5
	 * 					|
	 * 				3	|   4
	 * 					|
	 *                  8
	 * 
	 **************************************************************** 
	 */
	/*
	public static int rotated_section(int current_section, double current_angle, double r_angle) {
		int add_section = 0;
		int add_axis_section = 0;
		int final_section = current_section;
		
		if (r_angle < current_angle) {
			return(current_section);
		}
		
		if (r_angle == current_angle) {
			add_axis_section = 1;
		}
		else if (r_angle < current_angle+90) {
			add_section = 1;
		}
		else if (r_angle == current_angle+90) {
			add_axis_section = 2;
		} 
		else if (r_angle < current_angle+180) {
			add_section = 2;
		}
		else if (r_angle == current_angle+180) {
			add_axis_section = 3;
		}
		else if (r_angle < current_angle+270) {
			add_section = 3;
		}
		else if (r_angle == current_angle+270) {
			add_axis_section = 4;
		}
		else if (r_angle <= 360) {
			return(current_section);
		}
		
		for (int i=1; i<=add_axis_section; i++) {
			switch (final_section) {
				case 1:
					final_section = 5;
					break;
				case 2:
					final_section = 6;
					break;
				case 3:
					final_section = 7;
					break;
				case 4:
					final_section = 8;
					break;
				case 5:
					final_section = 8;
					break;
				case 6:
					final_section = 5;
					break;
				case 7:
					final_section = 6;
					break;
				case 8:
					final_section = 7;
					break;
			}	
		}
		
		if (add_axis_section != 0) {
			return(final_section);
		}
		
		for (int i=1; i<=add_section; i++) {
			switch (final_section) {
				case 1:
					final_section = 4;
					break;
				case 2:
					final_section = 1;
					break;
				case 3:
					final_section = 2;
					break;
				case 4:
					final_section = 3;
					break;
				case 5:
					final_section = 4;
					break;
				case 6:
					final_section = 1;
					break;
				case 7:
					final_section = 2;
					break;
				case 8:
					final_section = 3;
					break;
			}	
		}
		
		return(final_section);
	} */
	
	/* return the angle with the X-axis */
	/*
	public static double rotated_angle(int current_section, double current_angle, double r_angle) {
		return(0.0);
	}
	*/
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - added "reflection"
	 * 			2006/11/14 - added AREF part
	 */
	public static void getLayoutSize( String strName ) 
	{
		//int minX=0, maxX=0, minY=0, maxY=0;
		//boolean initial_set = false;
		DSstrNode str_node;
		
		if ( strName == null) {
			/* a very simple check: head or tail as the ROOT cell */
			if ( DSbuild.strList.getTail().getSrefList().getHead() == null &&
					DSbuild.strList.getHead().getSrefList().getHead() != null ) 
			{
				str_node = DSbuild.strList.getHead();
			}
			else {
				str_node = DSbuild.strList.getTail();
			}
		}	
		else {
			str_node = DSbuild.strList.getStr( strName );
	    }
		
		
		if ( str_node!=null )  // the root cell
        {
			if ( str_node.getHasCellLevelElements() == false ) 
			{
				initial_set = false;
			}
			else {
				minX = str_node.getCellLevelBbox().getMinX();
				maxX = str_node.getCellLevelBbox().getMaxX();
				minY = str_node.getCellLevelBbox().getMinY();
				maxY = str_node.getCellLevelBbox().getMaxY();
			
				initial_set = true;
			}
            
            /* SREF */
		    for ( DSsrefNode node=str_node.getSrefList().getHead();
	         	  node != null;
	         	  node = node.getNext() )	    
		    {
		    	/* get STRANS-->bit0 (reflection bit) */
	            boolean reflection;
	            if ( node.getStrans() != null ) {
	            	reflection = node.getStrans().getBit0();
	            }
	            else {
	            	reflection = false;
	            }
				
		    	// get shift_x and shift_y
		    	for (DSxyNode xy_node=node.getXYlist().getHead();
		    		 xy_node!=null;
		    		 xy_node=xy_node.getNext() )
		    	{
		    		DSorientationStack oStack = new DSorientationStack();
		    		
		    		oStack.insert( reflection, node.getAngle(), xy_node.getX(), xy_node.getY() );
		    		
		    		getLayoutSize_Element( node.getStrName(), oStack );
		    	}		    	
		    }  // END of SREF
		    
		    
		    /* AREF */
		    for ( DSarefNode aref_node = str_node.getArefList().getHead();
		          aref_node != null;
		    	  aref_node = aref_node.getNext() )
		    {
		    	/* get STRANS-->bit0 (reflection bit) */
	            //boolean reflection;
	            //if ( arefNode.getStrans() != null ) {
	            //	reflection = arefNode.getStrans().getBit0();
	            //}
	            //else {
	            	//reflection = false;
	            //}
	            
	            DSorientationStack oStack = new DSorientationStack();
	            
	            //oStack.insert( reflection, aref_node.getAngle(), 0, 0 );  // no displacement (at the level) (it is processed in the next level of function call)
	            
	            getLayoutSize_AREF( aref_node, oStack );
	            
		    }  // END of AREF
		   		    
        }
		
        SizeSetting.setMinX( minX );
		SizeSetting.setMaxX( maxX );
		SizeSetting.setMinY( minY );
		SizeSetting.setMaxY( maxY );
		
		SizeSetting2.setMinX( minX );
		SizeSetting2.setMaxX( maxX );
		SizeSetting2.setMinY( minY );
		SizeSetting2.setMaxY( maxY );

	}  // getLayoutSize()
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/14 - initial version
	 */
	private static void getLayoutSize_AREF( DSarefNode aref_node, DSorientationStack oStack )
	{
		DSstrNode strNode = DSbuild.strList.getStr( aref_node.getStrName() );
    	
    	if ( strNode==null ) {
    		return;
    	}
    	
    	boolean reflection;
        if ( aref_node.getStrans() != null ) {
        	reflection = aref_node.getStrans().getBit0();
        }
        else {
        	reflection = false;
        }
        
        double angle = aref_node.getAngle();
    	
    	/* An AREF node must have three xy nodes */
    	/* get (X1,Y1), (X2,Y2), and (X3,Y3) */
        
        DSxyNode vertex1 = aref_node.getXYlist().getHead();
        DSxyNode vertex2 = vertex1.getNext();
        DSxyNode vertex3 = vertex2.getNext();
        
        int col = aref_node.getColrow().getCol();
        int row = aref_node.getColrow().getRow();
        
        int interColSpacingX = (vertex2.getX() - vertex1.getX()) / col;
        int interColSpacingY = (vertex2.getY() - vertex1.getY()) / col;
        int interRowSpacingX = (vertex3.getX() - vertex1.getX()) / row;
        int interRowSpacingY = (vertex3.getY() - vertex1.getY()) / row;
        
        int tempX = vertex1.getX();
        int tempY = vertex1.getY(); 
        
        int tempXc = tempX;
        int tempYc = tempY;
        
        
        for ( int c = 1; c <= col; c++ ) 
        {
        	for ( int r = 1; r <= row; r++ ) 
        	{
        		DSorientationStack oStack_2 = oStack.shallowCopy();    	
            	oStack_2.insert( reflection, angle, tempX, tempY );
            	
            	getLayoutSize_Element( strNode.getName(), oStack_2 );
            	
        		/* BOUNDARY */
        		//if ( getIsDrawBoundaryState() == true ) {				
        			//displayBoundaryList( graphics2D, strNode.getBoundaryList(), oStack_2, isOnScreen ); 
        		//}
        		
        		/* BOX */
        		//if ( getIsDrawBoxState() == true ) {
    				//displayBoxList( graphics2D, strNode.getBoxList(), oStack_2, isOnScreen ); 
    			//}
        		
        		/* PATH */
        		//if ( getIsDrawPathState() == true ) {
    				//displayPathList( graphics2D, strNode.getPathList(), oStack_2, isOnScreen ); 
    			//}
        		
        		/* TEXT - ToDo */
        		
            	if ( r == row ) {
        			tempX = tempXc;
        			tempY = tempYc;
        		}
        		else {
        			tempX += interRowSpacingX;
        			tempY += interRowSpacingY;
        		}
        	}
        	
        	tempX += interColSpacingX;
        	tempY += interColSpacingY;
        	
        	tempXc = tempX;
        	tempYc = tempY;
        }        
        
	}  // END of getLayoutSize_AREF()
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - "added reflection"
	 */
	/* only called by getLayoutSize() */
	private static void getLayoutSize_Element( String sname, DSorientationStack oStack ) 
			//double angle, int shiftX, int shiftY) 
	{
		
		DSstrNode str_node = DSbuild.strList.getStr(sname);
		
		if ( str_node == null ) {
			return;
		}
		
        /* BOUNDARY */
        for ( DSboundaryNode b_node=str_node.getBoundaryList().getHead();
	          b_node!=null;
	          b_node=b_node.getNext() )
	    {	
		    for ( DSxyNode xy_node=b_node.getXYlist().getHead();
		          xy_node!=null;
		          xy_node=xy_node.getNext() )
		    {		        	
		    	/* calculate (x,y) baed on orientation */
			    Point oPoint = DSbuild.calculateOrientation( xy_node.getX(), xy_node.getY(), oStack );
		        	
			    int cX = (int) oPoint.getX();
		        int cY = (int) oPoint.getY();
		        	
		        /* for overall layout size */
		        if (initial_set) {
		        	minX = (cX < minX) ? cX : minX; 
		        	maxX = (cX > maxX) ? cX : maxX;  
					minY = (cY < minY) ? cY : minY;			
				    maxY = (cY > maxY) ? cY : maxY;
		        }
		        else {
		        	minX = maxX = cX;
					minY = maxY = cY;
		        	initial_set = true;
		        }
		    }
		        
	    }  /* end BOUNDARY */
            
            
        /* BOX */
        for ( DSboxNode b_node=str_node.getBoxList().getHead();
	          b_node!=null;
	          b_node=b_node.getNext() )
	    {	
		    for ( DSxyNode xy_node=b_node.getXYlist().getHead();
		          xy_node!=null;
		          xy_node=xy_node.getNext() )
		    {
		    	/* calculate (x,y) baed on orientation */
			    Point oPoint = DSbuild.calculateOrientation( xy_node.getX(), xy_node.getY(), oStack );
		        	
		        int cX = (int) oPoint.getX();
		        int cY = (int) oPoint.getY();
		        	
		        /* for overall layout size */
		        if (initial_set) {
		        	minX = (cX < minX) ? cX : minX; 
		        	maxX = (cX > maxX) ? cX : maxX;  
					minY = (cY < minY) ? cY : minY;			
				    maxY = (cY > maxY) ? cY : maxY;
		        }
		        else {
		        	minX = maxX = cX;
					minY = maxY = cY;
		        	initial_set = true;
		        }
		    }
		        
	    }  /* end BOX */
        
        
        /* PATH */
        for ( DSpathNode node=str_node.getPathList().getHead();
	          node!=null;
	          node=node.getNext() )
	    {	
		    for ( DSxyNode xy_node=node.getXYlist().getHead();
		          xy_node!=null;
		          xy_node=xy_node.getNext() )
		    {
		    	/* calculate (x,y) baed on orientation */
			    Point oPoint = DSbuild.calculateOrientation( xy_node.getX(), xy_node.getY(), oStack );
		        	
		        int cX = (int) oPoint.getX();
		        int cY = (int) oPoint.getY();
		        	
		        /* for overall layout size */
		        if (initial_set) {
		        	minX = (cX < minX) ? cX : minX; 
		        	maxX = (cX > maxX) ? cX : maxX;  
					minY = (cY < minY) ? cY : minY;			
				    maxY = (cY > maxY) ? cY : maxY;
		        }
		        else {
		        	minX = maxX = cX;
					minY = maxY = cY;
		        	initial_set = true;
		        }
		    }
		        
	    }  /* END of PATH */
            
            
        /* TEXT */
            
        /* END of TEXT */
            
            
        /* SREF */
		for ( DSsrefNode node = str_node.getSrefList().getHead();
	          node != null;
	          node = node.getNext() )	    
        {		    	
		    /* get STRANS-->bit0 (reflection bit) */
	        boolean reflection;
	        if ( node.getStrans() != null ) {
	        	reflection = node.getStrans().getBit0();
	        }
	        else {
	        	reflection = false;
	        }
	            
	        // get shift_x and shift_y
		    for ( DSxyNode xy_node = node.getXYlist().getHead();
		    	  xy_node!=null;
		    	  xy_node=xy_node.getNext() )
		    {
		    	DSorientationStack oStack_2 = oStack.shallowCopy();
	            	
	            oStack_2.insert( reflection, node.getAngle(), xy_node.getX(), xy_node.getY() );
		    		
		    	getLayoutSize_Element( node.getStrName(), oStack_2 );
		    }		    	
		} /* END of SREF */		
		    
	}  // END of getLayoutSize2()
	
	
	/* NOT USED */
	public static void buildOverallBoundingBoxInfo() {
		
		/* go through all the cells, 
		 * not necessary from the root 
		 */
		
		/* for each cell */
        for (DSstrNode strNode = strList.getHead(); 
             strNode != null; 
             strNode = strNode.getNext() ) 
        {
        	//System.out.println(" HELLO ");
        	
        	BoundingBox overallBbox = buildOverallBbox( strNode );
        	
        	//System.out.println(" HELLO ");        	
        }		
	}
	
	
	/* get the Overall Bounding Box of a cell */
	/* the Overall Bounding Box is build on-the-fly */
	/* is built bottom-up */
	public static BoundingBox getOverallBbox( String strName ) {
		
		DSstrNode strNode = DSbuild.strList.getStr(strName);
		
		
		if ( strNode == null ) {			
			//OwlVisionMessages.showConsoleMsg( JOptionPane.WARNING_MESSAGE, 10010, strName );
			/* WARNING: empty cell */
			return( new BoundingBox(0,0,0,0) );
		}
		else if ( strNode.getOverallBbox() != null ) {
			return( strNode.getOverallBbox() );
		}
		else {
			return( buildOverallBbox( strNode ) );
		}
	}
	
	
	public static BoundingBox buildOverallBbox( DSstrNode strNode ) {
		
		boolean hasSref = false;
		
		BoundingBox srefBbox = new BoundingBox(0,0,0,0);
		boolean     srefBbox_initial_set = false;
		
		/* all of the SREF's in the cell */
    	for ( DSsrefNode srefNode = strNode.getSrefList().getHead();
    	      srefNode != null;
    	      srefNode = srefNode.getNext() ) 
    	{
    		hasSref = true;
    		BoundingBox bbox = getOverallBbox( srefNode.getStrName() );  // recursive call
    		/* srefNode.getAngle(); */
    		/* srefNode.getXYlist().getHead() */
    		double angle = srefNode.getAngle();
    		int shift_x  = srefNode.getXYlist().getHead().getX();
    		int shift_y  = srefNode.getXYlist().getHead().getY();
    		
    		/* angle = 0 degree */
    		if ( angle == 0) {
    			if ( srefBbox_initial_set == false ) {
    				srefBbox_initial_set = true;
    				srefBbox.set( bbox.getMinX()+shift_x, bbox.getMaxX()+shift_x, bbox.getMinY()+shift_y, bbox.getMaxY()+shift_y );
    			}
    			else {
    				if (srefBbox.getMinX() > bbox.getMinX()+shift_x ) {
    					srefBbox.setMinX( bbox.getMinX()+shift_x );
    				}
    				if (srefBbox.getMaxX() < bbox.getMaxX()+shift_x ) {
    					srefBbox.setMaxX( bbox.getMaxX()+shift_x );
    				}
    				if (srefBbox.getMinY() > bbox.getMinY()+shift_y ) {
    					srefBbox.setMinY( bbox.getMinY()+shift_y );
    				}
    				if (srefBbox.getMaxY() < bbox.getMaxY()+shift_y ) {
    					srefBbox.setMaxY( bbox.getMaxY()+shift_y );
    				}
    			}
    			srefNode.setOverallBbox( bbox.getMinX()+shift_x, bbox.getMaxX()+shift_x, bbox.getMinY()+shift_y, bbox.getMaxY()+shift_y );
    		}
    		/* angle != 0 degree */
    		else {    			
    			int xMin, xMax, yMin, yMax;  // the resulting bbox for the "srefNode"
    			Point point;  // the point after rotation
    			
    			/* min-X, min-Y */
    			point = DSbuild.rotate(bbox.getMinX(), bbox.getMinY(), angle);
    			//System.out.println( point );
    			xMin = xMax = (int)(point.getX() + shift_x);
    			yMin = yMax = (int)(point.getY() + shift_y);
    			/* min-X, max-Y */
    			point = DSbuild.rotate(bbox.getMinX(), bbox.getMaxY(), angle);
    			//System.out.println( point );
    			if ( xMin > (point.getX() + shift_x) ) {
    				xMin = (int)(point.getX() + shift_x);
    			}
    			if ( xMax < (point.getX() + shift_x) ) {
    				xMax = (int)(point.getX() + shift_x);
    			}
    			if ( yMin > (point.getY() + shift_y) ) {
    				yMin = (int)(point.getY() + shift_y);
    			}
    			if ( yMax < (point.getY() + shift_y) ) {
    				yMax = (int)(point.getY() + shift_y);
    			}
    			/* max-X, min-Y */
    			point = DSbuild.rotate(bbox.getMaxX(), bbox.getMinY(), angle);
    			//System.out.println( point );
    			if ( xMin > (point.getX() + shift_x) ) {
    				xMin = (int)(point.getX() + shift_x);
    			}
    			if ( xMax < (point.getX() + shift_x) ) {
    				xMax = (int)(point.getX() + shift_x);
    			}
    			if ( yMin > (point.getY() + shift_y) ) {
    				yMin = (int)(point.getY() + shift_y);
    			}
    			if ( yMax < (point.getY() + shift_y) ) {
    				yMax = (int)(point.getY() + shift_y);
    			}
    			/* max-X, max-Y */
    			point = DSbuild.rotate(bbox.getMaxX(), bbox.getMaxY(), angle);
    			//System.out.println( point );
    			if ( xMin > (point.getX() + shift_x) ) {
    				xMin = (int)(point.getX() + shift_x);
    			}
    			if ( xMax < (point.getX() + shift_x) ) {
    				xMax = (int)(point.getX() + shift_x);
    			}
    			if ( yMin > (point.getY() + shift_y) ) {
    				yMin = (int)(point.getY() + shift_y);
    			}
    			if ( yMax < (point.getY() + shift_y) ) {
    				yMax = (int)(point.getY() + shift_y);
    			}
    			
    			if ( srefBbox_initial_set == false ) {
    				srefBbox_initial_set = true;
    				srefBbox.set( xMin, xMax, yMin, yMax );
    			}
    			else {
    				if (srefBbox.getMinX() > xMin ) {
    					srefBbox.setMinX( xMin );
    				}
    				if (srefBbox.getMaxX() < xMax ) {
    					srefBbox.setMaxX( xMax );
    				}
    				if (srefBbox.getMinY() > yMin ) {
    					srefBbox.setMinY( yMin );
    				}
    				if (srefBbox.getMaxY() < yMax ) {
    					srefBbox.setMaxY( yMax );
    				}    				
    			}
    			srefNode.setOverallBbox( xMin, xMax, yMin, yMax );
    		}
    	}  /* END: all of the SREF's in the cell */
    	
    	if ( strNode.getOverallBbox() == null ) { 
    		if ( hasSref == false ) {  // no SREF in this cell
    			/* return the cell-level bbox */
    			strNode.setOverallBbox( strNode.getCellLevelBbox() );
    			return( strNode.getCellLevelBbox() );
    		}
    		else {
    			/* compare to the cell-level bbox */
    			if (srefBbox.getMinX() > strNode.getCellLevelBbox().getMinX() ) {
					srefBbox.setMinX( strNode.getCellLevelBbox().getMinX() );
				}
				if (srefBbox.getMaxX() < strNode.getCellLevelBbox().getMaxX() ) {
					srefBbox.setMaxX( strNode.getCellLevelBbox().getMaxX() );
				}
				if (srefBbox.getMinY() > strNode.getCellLevelBbox().getMinY() ) {
					srefBbox.setMinY( strNode.getCellLevelBbox().getMinY() );
				}
				if (srefBbox.getMaxY() < strNode.getCellLevelBbox().getMaxY() ) {
					srefBbox.setMaxY( strNode.getCellLevelBbox().getMaxY() );
				}
    			strNode.setOverallBbox( srefBbox );
    			return( srefBbox );
    		}
    	}
    	else {
    		return( strNode.getOverallBbox() );
    	}    			
	}
	
	
	public static void buildBoundingBoxInfo() 
	{		
		/* go through all the cells, 
		 * not necessary from the root 
		 */
		
		/* for each cell */
        for (DSstrNode str_node=strList.getHead(); 
             str_node!=null; 
             str_node=str_node.getNext() ) 
        {
        	/* cell bounding box - used for Quad Trees */
        	int strBboxMinX=0, strBboxMaxX=0, strBboxMinY=0, strBboxMaxY=0;
        	boolean str_bbox_initial_set = false;
        	
        	/* BOUNDARY (polygon) */
            for (DSboundaryNode bd_node=str_node.getBoundaryList().getHead();
	             bd_node!=null;
	             bd_node=bd_node.getNext() )
	        {	
            	int bboxMinX=0, bboxMaxX=0, bboxMinY=0, bboxMaxY=0;
            	boolean bbox_initial_set = false;
            	
		        for (DSxyNode xy_node=bd_node.getXYlist().getHead();
		             xy_node!=null;
		             xy_node=xy_node.getNext() )
		        {
		        	/* for BOUNDARY bounding box */
		        	if (bbox_initial_set) {
		        		bboxMinX = (xy_node.getX() < bboxMinX) ? xy_node.getX() : bboxMinX; 
		        		bboxMaxX = (xy_node.getX() > bboxMaxX) ? xy_node.getX() : bboxMaxX;  
						bboxMinY = (xy_node.getY() < bboxMinY) ? xy_node.getY() : bboxMinY;			
				        bboxMaxY = (xy_node.getY() > bboxMaxY) ? xy_node.getY() : bboxMaxY;
		        	}
		        	else {
		        		bboxMinX = bboxMaxX = xy_node.getX();
						bboxMinY = bboxMaxY = xy_node.getY();
		        	    bbox_initial_set = true;
		        	}
		        	
		        	/* for cell bbox */
		        	if (str_bbox_initial_set) {
		        		strBboxMinX = (xy_node.getX() < strBboxMinX) ? xy_node.getX() : strBboxMinX; 
		        		strBboxMaxX = (xy_node.getX() > strBboxMaxX) ? xy_node.getX() : strBboxMaxX;  
						strBboxMinY = (xy_node.getY() < strBboxMinY) ? xy_node.getY() : strBboxMinY;			
				        strBboxMaxY = (xy_node.getY() > strBboxMaxY) ? xy_node.getY() : strBboxMaxY;		        		
		        	}
		        	else {
		        		strBboxMinX = strBboxMaxX = xy_node.getX(); 
		        		strBboxMinY = strBboxMaxY = xy_node.getY();
		        		str_bbox_initial_set = true;
		        	}
		        }
		        
		        /* set up BONUDARY bbox */
		        bd_node.setBbox( bboxMinX, bboxMaxX, bboxMinY, bboxMaxY );
		        
	        }  /* end BOUNDARY (polygon) */
            
            
            /* BOX */
            for (DSboxNode bo_node=str_node.getBoxList().getHead();
	             bo_node!=null;
	             bo_node=bo_node.getNext() )
	        {	
            	int bboxMinX=0, bboxMaxX=0, bboxMinY=0, bboxMaxY=0;
            	boolean bbox_initial_set = false;
            	
		        for (DSxyNode xy_node=bo_node.getXYlist().getHead();
		             xy_node!=null;
		             xy_node=xy_node.getNext() )
		        {
		        	/* for BOX bounding box */
		        	if (bbox_initial_set) {
		        		bboxMinX = (xy_node.getX() < bboxMinX) ? xy_node.getX() : bboxMinX; 
		        		bboxMaxX = (xy_node.getX() > bboxMaxX) ? xy_node.getX() : bboxMaxX;  
						bboxMinY = (xy_node.getY() < bboxMinY) ? xy_node.getY() : bboxMinY;			
				        bboxMaxY = (xy_node.getY() > bboxMaxY) ? xy_node.getY() : bboxMaxY;
		        	}
		        	else {
		        		bboxMinX = bboxMaxX = xy_node.getX();
						bboxMinY = bboxMaxY = xy_node.getY();
		        	    bbox_initial_set = true;
		        	}
		        	
		        	/* for cell bbox */
		        	if (str_bbox_initial_set) {
		        		strBboxMinX = (xy_node.getX() < strBboxMinX) ? xy_node.getX() : strBboxMinX; 
		        		strBboxMaxX = (xy_node.getX() > strBboxMaxX) ? xy_node.getX() : strBboxMaxX;  
						strBboxMinY = (xy_node.getY() < strBboxMinY) ? xy_node.getY() : strBboxMinY;			
				        strBboxMaxY = (xy_node.getY() > strBboxMaxY) ? xy_node.getY() : strBboxMaxY;		        		
		        	}
		        	else {
		        		strBboxMinX = strBboxMaxX = xy_node.getX(); 
		        		strBboxMinY = strBboxMaxY = xy_node.getY();
		        		str_bbox_initial_set = true;
		        	}
		        }
		        
		        /* set up BOX bbox */
		        bo_node.setBbox( bboxMinX, bboxMaxX, bboxMinY, bboxMaxY );
		        
	        }  /* end BOX */
            
            
            /* TEXT */
            for (DStextNode tx_node=str_node.getTextList().getHead();
	             tx_node != null;
	             tx_node = tx_node.getNext() )
	        {	
            	int bboxMinX=0, bboxMaxX=0, bboxMinY=0, bboxMaxY=0;
            	boolean bbox_initial_set = false;
            	
            	/* should have only one xy_node */
		        for (DSxyNode xy_node = tx_node.getXYlist().getHead();
		             xy_node != null;
		             xy_node = xy_node.getNext() )
		        {
		        	/* for TEXT bounding box */
		        	if (bbox_initial_set) {
		        		bboxMinX = (xy_node.getX() < bboxMinX) ? xy_node.getX() : bboxMinX; 
		        		bboxMaxX = (xy_node.getX() > bboxMaxX) ? xy_node.getX() : bboxMaxX;  
						bboxMinY = (xy_node.getY() < bboxMinY) ? xy_node.getY() : bboxMinY;			
				        bboxMaxY = (xy_node.getY() > bboxMaxY) ? xy_node.getY() : bboxMaxY;
		        	}
		        	else {
		        		bboxMinX = bboxMaxX = xy_node.getX();
						bboxMinY = bboxMaxY = xy_node.getY();
		        	    bbox_initial_set = true;
		        	}
		        	
		        	/* for cell bbox */
		        	if (str_bbox_initial_set) {
		        		strBboxMinX = (xy_node.getX() < strBboxMinX) ? xy_node.getX() : strBboxMinX; 
		        		strBboxMaxX = (xy_node.getX() > strBboxMaxX) ? xy_node.getX() : strBboxMaxX;  
						strBboxMinY = (xy_node.getY() < strBboxMinY) ? xy_node.getY() : strBboxMinY;			
				        strBboxMaxY = (xy_node.getY() > strBboxMaxY) ? xy_node.getY() : strBboxMaxY;		        		
		        	}
		        	else {
		        		strBboxMinX = strBboxMaxX = xy_node.getX(); 
		        		strBboxMinY = strBboxMaxY = xy_node.getY();
		        		str_bbox_initial_set = true;
		        	}
		        }
		        
		        /* set up TEXT bbox */
		        tx_node.setBbox( bboxMinX, bboxMaxX, bboxMinY, bboxMaxY );
		        
	        }  /* end TEXT (polygon) */            
            
            
            /* PATH */
            for (DSpathNode pa_node=str_node.getPathList().getHead();
	             pa_node!=null;
	             pa_node=pa_node.getNext() )
	        {	
            	int bboxMinX=0, bboxMaxX=0, bboxMinY=0, bboxMaxY=0;
            	boolean bbox_initial_set = false;
            	
		        for (DSxyNode xy_node=pa_node.getXYlist().getHead();
		             xy_node!=null;
		             xy_node=xy_node.getNext() )
		        {
		        	/* for PATH bounding box */
		        	if (bbox_initial_set) {
		        		bboxMinX = (xy_node.getX() < bboxMinX) ? xy_node.getX() : bboxMinX; 
		        		bboxMaxX = (xy_node.getX() > bboxMaxX) ? xy_node.getX() : bboxMaxX;  
						bboxMinY = (xy_node.getY() < bboxMinY) ? xy_node.getY() : bboxMinY;			
				        bboxMaxY = (xy_node.getY() > bboxMaxY) ? xy_node.getY() : bboxMaxY;
		        	}
		        	else {
		        		bboxMinX = bboxMaxX = xy_node.getX();
						bboxMinY = bboxMaxY = xy_node.getY();
		        	    bbox_initial_set = true;
		        	}
		        	
		        	/* for cell bbox */
		        	if (str_bbox_initial_set) {
		        		strBboxMinX = (xy_node.getX() < strBboxMinX) ? xy_node.getX() : strBboxMinX; 
		        		strBboxMaxX = (xy_node.getX() > strBboxMaxX) ? xy_node.getX() : strBboxMaxX;  
						strBboxMinY = (xy_node.getY() < strBboxMinY) ? xy_node.getY() : strBboxMinY;			
				        strBboxMaxY = (xy_node.getY() > strBboxMaxY) ? xy_node.getY() : strBboxMaxY;		        		
		        	}
		        	else {
		        		strBboxMinX = strBboxMaxX = xy_node.getX(); 
		        		strBboxMinY = strBboxMaxY = xy_node.getY();
		        		str_bbox_initial_set = true;
		        	}
		        }
		        
		        /* set up PATH bbox - not accurate, should consider path width */
		        pa_node.setBbox( bboxMinX, bboxMaxX, bboxMinY, bboxMaxY );
		        
	        }  /* end PATH */
            
            if ( str_bbox_initial_set == true ) {
            	str_node.setCellLevelBbox( strBboxMinX, strBboxMaxX, strBboxMinY, strBboxMaxY );
            	str_node.setHasCellLevelElements( true );
            }
            else {
            	/* level-0 elements do not exist in this cell */
            	/* (the cell does not contain any polygons) */
            	/* ToDo: need to be modified */
            	str_node.setCellLevelBbox( strBboxMinX, strBboxMaxX, strBboxMinY, strBboxMaxY );
            	str_node.setHasCellLevelElements( false );
            }
            
        }  /* END: for each cell */
        
	}  // getBoundingBoxInfo
	
	
		
	
	/** calculate angles in dgree
	 * 
	 *  	    (x, y)
	 *          /
	 *         / 
	 *        /
	 *       /   return
	 *      /    this angle
	 *     /___________________ X-axis
	 *                     
	 */
	public static double angle(double x, double y) 
	{	
		if (x>=0 && y==0) {
			return(0.0);
		}
		else if (x<0 && y==0) {
			return(180.0);
		}
		else if (x==0 && y>0) {
			return(90.0);
		}
		else if (x==0 && y<0) {
			return(270.0);
		}
		else if (x>0 && y>0) {
			return(Math.toDegrees(Math.atan(y/x)));
		}
		else if (x<0 && y>0) {
			return(180 - Math.toDegrees(Math.atan(y/-x)));
		}
		else if (x<0 && y<0) {
			return(180 + Math.toDegrees(Math.atan(y/x)));
		}
		else {
			//assert(x>0 && y<0);
			return(360 - Math.toDegrees(Math.atan(-y/x)));
		}
	}  // angle(x,y)
	
	
	/* Used by intFrame03 */
	public static DefaultTreeModel createTreeModel() {
		
		MutableTreeNode treeRoot   = null;
		Hashtable       treeHT     = new Hashtable();
		int             sref_count = 0;
		DSstrNode 		str_node;
		
		//visitedTreeNodeHT = new Hashtable();  // initialize
			
		if (strList == null)
			return( null );		
		
    	/* a very simple check: head or tail as the ROOT cell */
		if ( DSbuild.strList.getTail().getSrefList().getHead() == null &&
			 DSbuild.strList.getHead().getSrefList().getHead() != null ) 
		{
			str_node = strList.getHead();
		}
		else {
			str_node = strList.getTail();
		}
		
		
		if (str_node!=null)
	    {
			treeRoot = new DefaultMutableTreeNode( str_node.getName() );

		    /* SREF */
		    for (DSsrefNode node = str_node.getSrefList().getHead();
		         node != null;
		         node = node.getNext() )
		    {
		    	if ( treeHT.containsKey(node.getStrName()) == false ) {
		    		MutableTreeNode newNode = new DefaultMutableTreeNode( node.getStrName() );
		    		treeRoot.insert( newNode, sref_count );
		    		treeHT.put( node.getStrName(), node.getStrName() );
		    		sref_count++;
		    		//visitedTreeNodeHT.put( node.sname, node.sname );
		    		createTreeModel2( newNode, node.getStrName() );
		    	}
		    			    
		    }  /* SREF */
	    }
		
		return( new DefaultTreeModel(treeRoot) );
		
	}  // createTreeModel()
	
	/* Used by intFrame03 - called by createTreeModel() only */
	public static void createTreeModel2( MutableTreeNode pNode, String pName ) {
				
		//MutableTreeNode treeRoot   = null;
		Hashtable       treeHT     = new Hashtable();
		int             sref_count = 0;
			
		/*
		if ( visitedTreeNodeHT.containsKey( pName ) ) {
			return;
		} 
		visitedTreeNodeHT.put( pName, pName );
		*/
		
		/* the ROOT cell */
		DSstrNode str_node = strList.getStr( pName );
		if (str_node!=null)
	    {
			//treeRoot = new DefaultMutableTreeNode( str_node.strname + "  (Root Cell)" );

		    /* SREF */
		    for (DSsrefNode node = str_node.getSrefList().getHead();
		         node != null;
		         node = node.getNext() )
		    {
		    	if ( treeHT.containsKey(node.getStrName()) == false ) {
		    		MutableTreeNode newNode = new DefaultMutableTreeNode( node.getStrName() );
		    		pNode.insert( newNode, sref_count );
		    		treeHT.put( node.getStrName(), node.getStrName() );
		    		sref_count++;
		    		createTreeModel2( newNode, node.getStrName() );
		    	}
		    }  /* SREF */
	    }
		
	}  // createTreeModel2()
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/10 - AREF supported
	 */
	public static void buildQuadTreeStructure() {
		/* go through all the cells, 
		 * not necessary from the root 
		 */
		
		/* for each cell */
        for (DSstrNode strNode=strList.getHead(); 
             strNode != null; 
             strNode = strNode.getNext() ) 
        {
        	int divX;
        	int divY;
        	divX = strNode.getCellLevelBbox().getMidX();
            divY = strNode.getCellLevelBbox().getMidY();
        
        	/* === BOUNDARY === */
        	
        	/*: divide into quad trees with depth 0 and 1 */
        	for (DSboundaryNode bd_node = strNode.getBoundaryList().getHead();
            	 bd_node != null;
            	 bd_node = bd_node.getNext() )
        	{
        		int bd_minX = bd_node.getMinX();  // element's minX
        		int bd_maxX = bd_node.getMaxX();  // element's maxX
        		int bd_minY = bd_node.getMinY();  // element's minY
        		int bd_maxY = bd_node.getMaxY();  // element's maxY
        		
        		/* ULeft */
        		if ( (divX >= bd_maxX) && (divY <= bd_minY) ) {   // WAS if ( (divX >= bd_minX) && (divY <= bd_maxY) ) {
        			DSboundaryNode bd_new = new DSboundaryNode(bd_node);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeNode(0, bd_new, 0);
        		}
        		/* URight */
        		else if ( (divX <= bd_minX) && (divY <= bd_minY)  ) {   // WAS if ( (divX <= bd_maxX) && (divY <= bd_maxY)  ) {
        			DSboundaryNode bd_new = new DSboundaryNode(bd_node);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeNode(1, bd_new, 0);
        		}        		
        		/* LLeft */
        		else if ( (divX >= bd_maxX) && (divY >= bd_maxY) ) {   // WAS if ( (divX >= bd_minX) && (divY >= bd_minY) ) {
        			DSboundaryNode bd_new = new DSboundaryNode(bd_node);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeNode(2, bd_new, 0);
        		}
        		/* LRight */
        		else if ( (divX <= bd_minX) && (divY >= bd_maxY) ) {   // WAS if ( (divX <= bd_maxX) && (divY >= bd_minY) ) {
					DSboundaryNode bd_new = new DSboundaryNode(bd_node);  /* create a new DSboundaryNode ("next" fields need to be different) */
					strNode.addQuadTreeNode(3, bd_new, 0);
				}
        		else {
        			/* put elements in quadTree-->elements */
        			DSboundaryNode bd_new = new DSboundaryNode(bd_node);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeElement( bd_new, 0 );
        		}
        	}
        	
        	/* BOUNDARY: divide into sub quad trees recursively */
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getULeft()!=null ) {
        		BoundingBox bboxUL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getULeft().divideBoundaryElementsIntoQuadTrees( bboxUL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getURight()!=null ) {
        		BoundingBox bboxUR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getURight().divideBoundaryElementsIntoQuadTrees( bboxUR );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLLeft()!=null ) {
        		BoundingBox bboxLL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLLeft().divideBoundaryElementsIntoQuadTrees( bboxLL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLRight()!=null ) {
        		BoundingBox bboxLR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLRight().divideBoundaryElementsIntoQuadTrees( bboxLR );
        	}
        	
        	
        	/* === BOX === */
        	
        	for (DSboxNode bo_node = strNode.getBoxList().getHead();
            	 bo_node != null;
            	 bo_node = bo_node.getNext() )
        	{
        		int bo_minX = bo_node.getMinX();  // element's minX
        		int bo_maxX = bo_node.getMaxX();  // element's maxX
        		int bo_minY = bo_node.getMinY();  // element's minY
        		int bo_maxY = bo_node.getMaxY();  // element's maxY
        		
        		/* ULeft */
        		if ( (divX >= bo_maxX) && (divY <= bo_minY) ) {   // WAS if ( (divX >= bo_minX) && (divY <= bo_maxY) ) {
        			DSboxNode bo_new = new DSboxNode(bo_node);
        			strNode.addQuadTreeNode(0, bo_new, 0);
        		}
        		/* URight */
        		else if ( (divX <= bo_minX) && (divY <= bo_minY) ) {   // WAS if ( (divX <= bo_maxX) && (divY <= bo_maxY) ) {
        			DSboxNode bo_new = new DSboxNode(bo_node);
        			strNode.addQuadTreeNode(1, bo_new, 0);
        		}        		
        		/* LLeft */
        		else if ( (divX >= bo_maxX) && (divY >= bo_maxY) ) {   // WAS if ( (divX >= bo_minX) && (divY >= bo_minY) ) {
        			DSboxNode bo_new = new DSboxNode(bo_node);
        			strNode.addQuadTreeNode(2, bo_new, 0);
        		}
        		/* LRight */
        		else if ( (divX <= bo_minX) && (divY >= bo_maxY) ) {   // WAS if ( (divX <= bo_maxX) && (divY >= bo_minY) ) {
					DSboxNode bo_new = new DSboxNode(bo_node);
					strNode.addQuadTreeNode(3, bo_new, 0);
				}
        		else {
        			/* put elements in quadTree-->elements */
        			DSboxNode bo_new = new DSboxNode(bo_node);
        			strNode.addQuadTreeElement( bo_new, 0 );
        		}
        	}
        	
        	/* BOX: divide into sub quad trees recursively */
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getULeft()!=null ) {
        		BoundingBox bboxUL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getULeft().divideBoxElementsIntoQuadTrees( bboxUL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getURight()!=null ) {
        		BoundingBox bboxUR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getURight().divideBoxElementsIntoQuadTrees( bboxUR );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLLeft()!=null ) {
        		BoundingBox bboxLL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLLeft().divideBoxElementsIntoQuadTrees( bboxLL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLRight()!=null ) {
        		BoundingBox bboxLR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLRight().divideBoxElementsIntoQuadTrees( bboxLR );
        	}
        	
        	
        	/* === TEXT === */
        	
        	/*: divide into quad trees with depth 0 and 1 */
        	for (DStextNode textNode = strNode.getTextList().getHead();
            	 textNode != null;
            	 textNode = textNode.getNext() )
        	{
        		int tx_minX = textNode.getMinX();  // element's minX
        		int tx_maxX = textNode.getMaxX();  // element's maxX
        		int tx_minY = textNode.getMinY();  // element's minY
        		int tx_maxY = textNode.getMaxY();  // element's maxY
        		
        		/* ULeft */
        		if ( (divX >= tx_maxX) && (divY <= tx_minY) ) {   // WAS if ( (divX >= bd_minX) && (divY <= bd_maxY) ) {
        			DStextNode tx_new = new DStextNode(textNode);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeNode(0, tx_new, 0);
        		}
        		/* URight */
        		else if ( (divX <= tx_minX) && (divY <= tx_minY)  ) {   // WAS if ( (divX <= bd_maxX) && (divY <= bd_maxY)  ) {
        			DStextNode tx_new = new DStextNode(textNode);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeNode(1, tx_new, 0);
        		}        		
        		/* LLeft */
        		else if ( (divX >= tx_maxX) && (divY >= tx_maxY) ) {   // WAS if ( (divX >= bd_minX) && (divY >= bd_minY) ) {
        			DStextNode tx_new = new DStextNode(textNode);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeNode(2, tx_new, 0);
        		}
        		/* LRight */
        		else if ( (divX <= tx_minX) && (divY >= tx_maxY) ) {   // WAS if ( (divX <= bd_maxX) && (divY >= bd_minY) ) {
					DStextNode tx_new = new DStextNode(textNode);  /* create a new DSboundaryNode ("next" fields need to be different) */
					strNode.addQuadTreeNode(3, tx_new, 0);
				}
        		else {
        			/* put elements in quadTree-->elements */
        			DStextNode tx_new = new DStextNode(textNode);  /* create a new DSboundaryNode ("next" fields need to be different) */
        			strNode.addQuadTreeElement( tx_new, 0 );
        		}
        	}
        	
        	/* TEXT: divide into sub quad trees recursively */
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getULeft()!=null ) {
        		BoundingBox bboxUL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getULeft().divideTextElementsIntoQuadTrees( bboxUL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getURight()!=null ) {
        		BoundingBox bboxUR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getURight().divideTextElementsIntoQuadTrees( bboxUR );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLLeft()!=null ) {
        		BoundingBox bboxLL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLLeft().divideTextElementsIntoQuadTrees( bboxLL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLRight()!=null ) {
        		BoundingBox bboxLR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLRight().divideTextElementsIntoQuadTrees( bboxLR );
        	}
        	
        	
        	/* === PATH === */
        	
        	for (DSpathNode pa_node = strNode.getPathList().getHead();
            	 pa_node != null;
            	 pa_node = pa_node.getNext() )
        	{
        		int pa_minX = pa_node.getMinX();  // element's minX
        		int pa_maxX = pa_node.getMaxX();  // element's maxX
        		int pa_minY = pa_node.getMinY();  // element's minY
        		int pa_maxY = pa_node.getMaxY();  // element's maxY
        		
        		/* ULeft */
        		if ( (divX >= pa_maxX) && (divY <= pa_minY) ) {   // WAS if ( (divX >= pa_minX) && (divY <= pa_maxY) ) {
        			DSpathNode pa_new = new DSpathNode(pa_node);
        			strNode.addQuadTreeNode(0, pa_new, 0);
        		}
        		/* URight */
        		else if ( (divX <= pa_minX) && (divY <= pa_minY) ) {   // WAS if ( (divX <= pa_maxX) && (divY <= pa_maxY) ) {
        			DSpathNode pa_new = new DSpathNode(pa_node);
        			strNode.addQuadTreeNode(1, pa_new, 0);
        		}        		
        		/* LLeft */
        		else if ( (divX >= pa_maxX) && (divY >= pa_maxY) ) {   // WAS if ( (divX >= pa_minX) && (divY >= pa_minY) ) {
        			DSpathNode pa_new = new DSpathNode(pa_node);
        			strNode.addQuadTreeNode(2, pa_new, 0);
        		}
        		/* LRight */
        		else if ( (divX <= pa_minX) && (divY >= pa_maxY) ) {   // WAS if ( (divX <= pa_maxX) && (divY >= pa_minY) ) {
					DSpathNode pa_new = new DSpathNode(pa_node);
					strNode.addQuadTreeNode(3, pa_new, 0);
				}    
        		else {
        			/* put elements in quadTree-->elements */
        			DSpathNode pa_new = new DSpathNode(pa_node);
        			strNode.addQuadTreeElement( pa_new, 0 );
        		}
        	}
        	
        	/* PATH: divide into sub quad trees recursively */
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getULeft()!=null ) {
        		BoundingBox bboxUL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getULeft().dividePathElementsIntoQuadTrees( bboxUL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getURight()!=null ) {
        		BoundingBox bboxUR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getURight().dividePathElementsIntoQuadTrees( bboxUR );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLLeft()!=null ) {
        		BoundingBox bboxLL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLLeft().dividePathElementsIntoQuadTrees( bboxLL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLRight()!=null ) {
        		BoundingBox bboxLR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLRight().dividePathElementsIntoQuadTrees( bboxLR );
        	}
        	
        	/* === SREF === */
        	/* ToDo: should consider TRANS-->BIT0 (reflection) */
        	
        	for (DSsrefNode srefNode = strNode.getSrefList().getHead();
            	 srefNode != null;
            	 srefNode = srefNode.getNext() )
        	{        		
        		BoundingBox bbox = srefNode.getOverallBbox();

        		int sref_minX = bbox.getMinX();  
        		int sref_maxX = bbox.getMaxX();  
        		int sref_minY = bbox.getMinY();  
        		int sref_maxY = bbox.getMaxY();  
        		
        		/* ULeft */
        		if ( (divX >= sref_maxX) && (divY <= sref_minY) ) {   
        			DSsrefNode sref_new = new DSsrefNode(srefNode);
        			strNode.addQuadTreeNode(0, sref_new, 0);
        		}
        		/* URight */
        		else if ( (divX <= sref_minX) && (divY <= sref_minY) ) {  
        			DSsrefNode sref_new = new DSsrefNode(srefNode);
        			strNode.addQuadTreeNode(1, sref_new, 0);
        		}        		
        		/* LLeft */
        		else if ( (divX >= sref_maxX) && (divY >= sref_maxY) ) { 
        			DSsrefNode sref_new = new DSsrefNode(srefNode);
        			strNode.addQuadTreeNode(2, sref_new, 0);
        		}
        		/* LRight */
        		else if ( (divX <= sref_minX) && (divY >= sref_maxY) ) { 
					DSsrefNode sref_new = new DSsrefNode(srefNode);
					strNode.addQuadTreeNode(3, sref_new, 0);
				}    
        		else {
        			/* put elements in quadTree-->elements */
        			DSsrefNode sref_new = new DSsrefNode(srefNode);
        			strNode.addQuadTreeElement( sref_new, 0 );
        		}	
        	}  
        	
        	/* SREF: divide into sub quad trees recursively */
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getULeft()!=null ) {
        		BoundingBox bboxUL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getULeft().divideSrefElementsIntoQuadTrees( bboxUL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getURight()!=null ) {
        		BoundingBox bboxUR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), divY, strNode.getCellLevelBbox().getMaxY() );
        		strNode.getQuadTree().getURight().divideSrefElementsIntoQuadTrees( bboxUR );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLLeft()!=null ) {
        		BoundingBox bboxLL = new BoundingBox( strNode.getCellLevelBbox().getMinX(), divX, strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLLeft().divideSrefElementsIntoQuadTrees( bboxLL );
        	}
        	if (strNode!=null && strNode.getQuadTree()!=null && strNode.getQuadTree().getLRight()!=null ) {
        		BoundingBox bboxLR = new BoundingBox( divX, strNode.getCellLevelBbox().getMaxX(), strNode.getCellLevelBbox().getMinY(), divY );
        		strNode.getQuadTree().getLRight().divideSrefElementsIntoQuadTrees( bboxLR );
        	}
        	
        	/* === AREF === */
        	/* ToDo: should consider TRANS-->BIT0 (reflection) ? */
        	
        	for ( DSarefNode arefNode = strNode.getArefList().getHead();
       	 		  arefNode != null;
       	 		  arefNode = arefNode.getNext() )
        	{
        		/* put elements in quadTree-->elements */
    			DSarefNode aref_new = new DSarefNode(arefNode);
    			strNode.addQuadTreeElement( aref_new, 0 );
        		
        		//System.out.println("----------");
        	}
        	
        	
        } // END of "for each cell"
        
        //debug_printQuadTreeElementNumber();
        
        //System.out.println("---------");
        
	}  // END of buildQuadTreeStructure()
	
	
	/* translate PATH elements into BOUNDARY elements */
	public static void translatePath2Boundary() {
		/* Go through all the cells, 
		 * not necessary from the root 
		 */
		
		/* for each cell */
        for (DSstrNode strNode=strList.getHead(); 
             strNode != null; 
             strNode = strNode.getNext() ) 
        {
        	/* === PATH === */ 
        	/* for each PATH element */
        	for (DSpathNode path_node = strNode.getPathList().getHead();
            	 path_node != null;
            	 path_node = path_node.getNext() )
        	{       		
        		/* carry out the translation */
        		DSxyList rXYlist = PathToBoundary.path2boundary( path_node );
        		
        		DSboundaryNode tmpBoundaryNode = new DSboundaryNode(
        												path_node.getLayerNo(), 
        												path_node.getDatatype(),
        												rXYlist,
        												null);
        		tmpBoundaryNode.setIsPath( true );
        		DSboundaryList tmpBoundaryList = strNode.getBoundaryList();
        		tmpBoundaryList.insert( tmpBoundaryNode );
        		strNode.setBoundaryList( tmpBoundaryList );     
        		
        	}
        	strNode.setPathList( new DSpathList() );
        	
        }
        
	}  // END of translatePath2Boundary()
		
	
	/* OBSOLETE */
	private static void debug_printQuadTreeElementNumber() {
		
		for (DSstrNode strNode=strList.getHead(); 
        	 strNode != null; 
             strNode = strNode.getNext() ) 
		{
			System.out.println("cell name: " + strNode.getName());
			
			System.out.print("  ULeft: ");
			if ( strNode.getQuadTree()==null ) {
				System.out.print("0\n");
			}
			else {
				debug_printNumberOfElements( strNode.getQuadTree().getULeft() );
			}
			System.out.print("  URight: ");
			if ( strNode.getQuadTree()==null ) {
				System.out.print("0\n");
			}
			else {
				debug_printNumberOfElements( strNode.getQuadTree().getURight() );
			}
			System.out.print("  LLeft: ");
			if ( strNode.getQuadTree()==null ) {
				System.out.print("0\n");
			}
			else {
				debug_printNumberOfElements( strNode.getQuadTree().getLLeft() );
			}
			System.out.print("  LRight: ");
			if ( strNode.getQuadTree()==null ) {
				System.out.print("0\n");
			}
			else {
				debug_printNumberOfElements( strNode.getQuadTree().getLRight() );
			}
		}
		
	}
		
	/* OBSOLETE */
	private static void debug_printNumberOfElements( QuadTreeNode qTreeNode ) {

		if (qTreeNode==null) {
			System.out.print("0\n");
		}
		else if ( qTreeNode.getElements() == null ) {
			System.out.print("0\n");
		}
		else {
			System.out.print( qTreeNode.getBoundaryList().getNumber() + "\n");
		}
		
		
	}
	
	public static void setSelectedCell( String cellName ) {
		selectedCell = cellName;
	}
	
	public static String getSelectedCell() {
		return( selectedCell );
	}
	
	
	/* Author: I-Lun Tseng
	 * History: 2006/11/11 - started
	 */
	public static Point calculateOrientation( int xCoord, int yCoord, DSorientationStack oStack )
	{
		
		for ( DSorientationNode oNode = oStack.getHead();
		      oNode != null;
		      oNode = oNode.getNext() )
		{
			/* Step 1: Reflection */
			if ( oNode.getReflection() == true ) {
				yCoord = (-1) * yCoord;
			}
			
			/* Step 2: Rotation */
			if ( oNode.getAngle() != 0 ) {
				Point p = DSbuild.rotate( xCoord, yCoord, oNode.getAngle() );  // rotate
		    	xCoord = (int) p.getX();
		    	yCoord = (int) p.getY();
			}
			
			/* Step 3: Displacement */
			xCoord += oNode.getShiftX();
			yCoord += oNode.getShiftY();
			
		}
		
		return( new Point( xCoord, yCoord ) );
	}
	
	
	
}

