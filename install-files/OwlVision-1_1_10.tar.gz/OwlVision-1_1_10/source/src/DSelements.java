/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class DSelements {
	
	private   DSboundaryList	boundaryList;  	/* BOUNDARY elements */
	private   DSboxList			boxList;       	/* BOX elements */	
	private   DSpathList		pathList;	   	/* PATH elements */
	private   DStextList		textList;	   	/* TEXT elements */
	private   DSsrefList		srefList;      	/* SREF elements */
	private   DSarefList		arefList;		/* AREF elements */
	
	
	/* constructor */
	public DSelements() {
		boundaryList = null;
		boxList 	 = null;		
		pathList 	 = null;
		srefList 	 = null;
	}
	
	/* BOUNDARY */
	
	public DSboundaryList getBoundaryList() {
		return( boundaryList );
	}
	
	public void setBoundaryList( DSboundaryList list ) {
		boundaryList = list;
	}
	
	/* BOX */
	
	public DSboxList getBoxList() {
		return( boxList );
	}
	
	public void setBoxList( DSboxList list ) {
		boxList = list;
	}
		
	/* PATH */
	
	public DSpathList getPathList() {
		return( pathList );
	}
	
	public void setPathList( DSpathList list ) {
		pathList = list;
	}
	
	/* TEXT */
	
	public DStextList getTextList() {
		return( textList );
	}
	
	public void setTextList( DStextList list ) {
		textList = list;
	}
	
	/* SREF */
	
	public DSsrefList getSrefList() {
		return( srefList );
	}
	
	public void setSrefList( DSsrefList list ) {
		srefList = list;
	}
	
	/* AREF */
	
	public DSarefList getArefList() {
		return( arefList );
	}
	
	public void setArefList( DSarefList list ) {
		arefList = list;
	}

}
