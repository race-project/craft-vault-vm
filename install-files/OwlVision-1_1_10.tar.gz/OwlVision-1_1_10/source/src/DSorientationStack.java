/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class DSorientationStack {
	
	private DSorientationNode	head;
	private DSorientationNode	rear;
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11
	 */
	/* constructor */
	public DSorientationStack() 
	{
		head = null;
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11
	 */
	public DSorientationNode getHead()
	{
		return( head );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11
	 */
	public void setHead( DSorientationNode h ) 
	{
		head = h;
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11
	 */
	public void insert(	boolean reflection,
						double  angle,
						int		shiftX,
						int		shiftY )
	{
		if ( reflection == false &&
			 angle == 0 &&
			 shiftX == 0 && 
			 shiftY == 0 ) 
		{
			return;
		}
		
		DSorientationNode newNode = new DSorientationNode( reflection, angle, shiftX, shiftY, head );
		
		if ( head == null ) {
			rear = newNode;
		}
		else {	/* head != null */
			head.setPrev( newNode );
		}
		
		head = newNode;
		
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11 - initial version
	 */
	public DSorientationStack shallowCopy() 
	{
		DSorientationStack new_oStack = new DSorientationStack();
		
		new_oStack.setHead( head );
		
		return( new_oStack );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/14 - initial version
	 */
	public DSorientationStack copyAndInsertRear( boolean 	reflection,
												 double  	angle,
												 int		shiftX,
												 int		shiftY )
	{
		DSorientationStack new_oStack = new DSorientationStack();
		
		new_oStack.insert( reflection, angle, shiftX, shiftY );
		
		for ( DSorientationNode t = rear;
		      t != null;
		      t = t.getPrev() )
		{
			new_oStack.insert( t.getReflection(), t.getAngle(), t.getShiftX(), t.getShiftY() );
		}
		
		return( new_oStack );
		
	}
	
	

}
