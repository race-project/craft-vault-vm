/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/15
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DSpathNode {
	private  short 		  	layer;
	private  short 		  	datatype;
	private  short			pathtype;		/* added on 2006/11/25 */
	private  int 		  	width;
	private  int			bgnextnValue;	/* added on 2006/11/25 */
	private  int			endextnValue;	/* added on 2006/11/25 */
	private  DSxyList	  	xy;
	private  BoundingBox  	bbox;   // the bounding box
	private  DSpathNode   	next;
	
	
	/* constructor */	
	public DSpathNode(int 			lay,
					  int 			dat,
					  int			path_type,
					  int           w,
					  int			bgnextn_value,
					  int			endextn_value,
					  DSxyList 		xy_list,
					  DSpathNode 	n) 
	{
		layer    	 = (short) lay;
		datatype 	 = (short) dat;
		pathtype 	 = (short) path_type;
		width    	 = w;
		bgnextnValue = bgnextn_value;
		endextnValue = endextn_value;
		xy       	 = xy_list;
		next	 	 = n;
	}
	
	
	/* constructor */
	public DSpathNode( DSpathNode paNode ) 
	{
		layer    	 = (short) paNode.getLayerNo();
		datatype 	 = (short) paNode.getDatatype();
		pathtype 	 = (short) paNode.getPathtype();
		width    	 = paNode.getWidth();
		bgnextnValue = paNode.getBgnextnValue();
		endextnValue = paNode.getEndextnValue();
		xy       	 = paNode.getXYlist();
		bbox     	 = paNode.getBbox();
		next	 	 = null;
	}
	
	
	/* layer */
	
	public int getLayerNo() {
		return( layer );
	}

	/* datatype */
	
	public int getDatatype() {
		return( datatype );
	}
	
	/* pathtype */
	
	public int getPathtype() {
		return( pathtype );
	}
	
	/* width */
	
	public int getWidth() {
		return( width );
	}
	
	/* bgnextn */
	
	public int getBgnextnValue() {
		return( bgnextnValue );
	}
	
	/* endextn */
	
	public int getEndextnValue() {
		return( endextnValue );
	}
	
	/* xy */
	
	public DSxyList getXYlist() {
		return( xy );
	}

	/* next */
	
	public DSpathNode getNext() {
		return( next );
	}
	
	public void setNext( DSpathNode n ) {
		next = n;
	}
	
	/* bounding box */
	
	public BoundingBox getBbox() {
		return( bbox );
	}
	
	public void setBbox(int x1, int x2, int y1, int y2) {
		bbox = new BoundingBox( x1,x2,y1,y2 );
	}	
	
	public int getMinX() {
		return( bbox.getMinX() );
	}
	public int getMaxX() {
		return( bbox.getMaxX() );
	}
	public int getMinY() {
		return( bbox.getMinY() );
	}
	public int getMaxY() {
		return( bbox.getMaxY() );
	}

}
