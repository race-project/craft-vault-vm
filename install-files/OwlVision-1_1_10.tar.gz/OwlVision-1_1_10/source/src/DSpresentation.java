/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class DSpresentation {
	
	private int	bits_10_11;		/* TEXT font */
	private int bits_12_13;		/* TEXT's vertical justfication */
	private int bits_14_15;		/* TEXT's horizontal justification */
	
	public DSpresentation( int b_10_11, int b_12_13, int b_14_15 ) {
		bits_10_11 = b_10_11;
		bits_12_13 = b_12_13;
		bits_14_15 = b_14_15;
	}
	
	public int getBits_10_11() {
		return( bits_10_11 );
	}
	
	public int getBits_12_13() {
		return( bits_12_13 );
	}
	
	public int getBits_14_15() {
		return( bits_14_15 );
	}

}
