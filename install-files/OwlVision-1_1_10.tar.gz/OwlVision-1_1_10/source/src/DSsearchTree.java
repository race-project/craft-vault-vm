/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/**
 *   A Binary Search Tree
 */

/**
 * @author I-Lun Tseng
 *
 */
public class DSsearchTree {
	
	private DSsearchTreeNode root;  // the root of the search tree
	
	private static DSsearchTreeNode brutalSearchResultNode = null;
	private static DSsearchTreeNode brutalSearchParentNode = null;
	
	
	/* constructor */
	public DSsearchTree() {
		
		root = null;
	}
	
	
	public DSsearchTreeNode getRoot() {
		
		return( root );
	}
	
	
	public boolean isEmpty() {
		
		if (root == null)
			return(true);
		else
			return(false);
	}
	
	
	public DSsearchTreeNode insert( DSxyDNode n, int scanLinePosX, int scanLinePosY ) {
		
		return( insert( new DSsearchTreeData(n), scanLinePosX, scanLinePosY ) );
	}
	
	
	public DSsearchTreeNode insert( DSsearchTreeData data, int scanLinePosX, int scanLinePosY ) {
		
		DSsearchTreeNode newNode = new DSsearchTreeNode( data );
		
		if (root == null) {
			root = newNode;
			return( newNode );
		}
		
		/* root != null */
		
		DSsearchTreeNode t = root;
		DSsearchTreeData d;
		
		while (t != null) {
			
			d = t.getData();
			
			int compare_result = d.compare( data, scanLinePosX, scanLinePosY );
				
			if ( compare_result==0 ) {
				/* already exist: Do not insert */
				break;
			}
			else if ( compare_result < 0 ) {
				if ( t.getRightChild() == null) {
					t.setRightChild( newNode );
					break;
				}
				else {
					t = t.getRightChild();
				}
			}
			else {
				if (t.getLeftChild() == null) {
					t.setLeftChild( newNode );
					break;
				}
				else {
					t = t.getLeftChild();
				}
			}
		}			
		return( newNode );
	}
	
	
	/* remove the node from the binary search tree */
	public void remove( DSxyDNode node, int scanLinePosX, int scanLinePosY ) {
		
		DSsearchTreeData n = new DSsearchTreeData(node);
	
		/* ==== find the node ==== */
		
		DSsearchTreeNode t = root;
		DSsearchTreeData d;
		
		DSsearchTreeNode t_parent = null;  /*  the parent of "t" */
		int              t_p_direction = 0;  /*  0: initial value  
											  * -1: leftChild()
		                                      *  1: rightChild()
		                                      */
		
		while (t != null) {
			d = t.getData();
			
			int compare_result = d.compare( n, scanLinePosX, scanLinePosY );
			
			//if ( d.getNode().getX()==node.getX() && d.getNode().getY()==node.getY() ) {
			if ( compare_result==0 ) {
				// System.out.println("I found it.");
				break;  // exit the while loop
			}
			else {
				//int compare_result = d.compare( n, scanLinePosition );
				
				if ( compare_result < 0 ) {
					t_parent = t;
					t_p_direction = 1;
					t = t.getRightChild();
				}
				else {  /* compare_result > 0 */
					t_parent = t;
					t_p_direction = -1;
					t = t.getLeftChild();
				}				
			}			
		}
		
		if ( t==null ) {
			/* cannot find the node to be removed */
			/* this should not happen as the algorithm using this library might be wrong */
			
			/* --- use brutal search to find the node and then remove it --- */
			/* there are some problems to the sorting in "R" */
			
			brutalSearch( root, node, null );
			t = brutalSearchResultNode;
			t_parent = brutalSearchParentNode;
			
			if (t==null) {
				System.out.println("  WARNING: not removed");
				return;
			}			
		}
		
		/* t is the one to be removed */
		
		/* ==== change the pointers ==== */
		
		if ( t_parent == null ) {
			/* the root is the node we found */
			
			/* (1-1) if t has only one child (easy to deal with) */
			if ( t.getLeftChild()==null ) {
				root = t.getRightChild();
			}
			/* (1-2) if t has only one child (easy to deal with) */
			else if ( t.getRightChild()==null ) {
				root = t.getLeftChild();
			}
			/* (2) If t has two children */
			else {
				/* find the max key in t's left child sub-tree */
				DSsearchTreeNode maxInTheLeftChild = findAndModifyMaxNode( t.getLeftChild() );
				maxInTheLeftChild.setRightChild( t.getRightChild() );				
				root = maxInTheLeftChild;				
			}			
		}
		else {  /* t_parent != null */
			
			/* (1-1) if t has only one child (easy to deal with) */
			if ( t.getLeftChild()==null ) {
				if ( t_p_direction==-1 ) {
					t_parent.setLeftChild( t.getRightChild() );
				}
				else {  /* t_direction==1 */
					t_parent.setRightChild( t.getRightChild() );
				}			
			}
			/* (1-2) if t has only one child (easy to deal with) */
			else if ( t.getRightChild()==null ) {
				if ( t_p_direction==-1 ) {
					t_parent.setLeftChild( t.getLeftChild() );
				}
				else {  /* t_direction==1 */
					t_parent.setRightChild( t.getLeftChild() );
				}
			}
			/* (2) If t has two children */
			else {
				/* find the max key in t's left child sub-tree */
				DSsearchTreeNode maxInTheLeftChild = findAndModifyMaxNode( t.getLeftChild() );
				maxInTheLeftChild.setRightChild( t.getRightChild() );
				if ( t_p_direction==-1 ) {
					t_parent.setLeftChild( maxInTheLeftChild );
				}
				else {  /* t_direction==1 */
					t_parent.setRightChild( maxInTheLeftChild );
				}
			}
		}		
		
		/* ==== free the node ==== */
		
		/*t = null;*/  /* garbage collected */
	} 
	
	
	private static void brutalSearch( DSsearchTreeNode tree, DSxyDNode node, DSsearchTreeNode parent )	
	{
		if ( tree==null ) {
			return;
		}
		
		DSxyDNode tNode = tree.getData().getNode();
		
		if ( tNode==node )   // the same pointer
		{
			//System.out.println("     ++++ FOUND ++++");
			
			brutalSearchParentNode = parent;
			brutalSearchResultNode = tree;
			return;
		}
		else {
			brutalSearch( tree.getLeftChild(), node, tree);
			brutalSearch( tree.getRightChild(), node, tree);
		}		
	}
	
	
	public DSsearchTreeNode find( DSxyDNode node ) {
		
		brutalSearch( root, node, null );
		
		return( brutalSearchResultNode );		
	}
	
	
	/* return the node with maximal key */
	private DSsearchTreeNode findAndModifyMaxNode( DSsearchTreeNode r ) {
			
		DSsearchTreeNode t = r;
		DSsearchTreeNode t_parent = null;
		
		while ( t != null ) {
			if ( t.getRightChild() != null ) {
				t_parent = t;
				t        = t.getRightChild();
			}
			else {
				break;
			}
		}
		
		/* right now, t is the max node */
		
		if ( t == r ) {
			return( t );
		}
		else {
			t_parent.setRightChild( t.getLeftChild() );
			t.setLeftChild( r );
		}
				
		return( t );		
	}
	
	
	/* remove and return the node which has the largest value */
	public DSsearchTreeNode pop() {
		
		DSsearchTreeNode t        = root;
		DSsearchTreeNode t_parent = null;
		
		while (t != null) {
			if ( t.getRightChild() != null) {
				t_parent = t;
				t = t.getRightChild();
			}
			else
				break;
		}
		
		if (t == root) {
			root = root.getLeftChild();
		}
		else {
			t_parent.setRightChild( t.getLeftChild() );
		}
		return(t);
	}
	
	
	public static DSsearchTreeNode findMax( DSsearchTreeNode r ) {
		
		DSsearchTreeNode t = r;
		
		while ( t!=null ) {
			if ( t.getRightChild() != null ) {
				t = t.getRightChild();
			}
			else {
				break;
			}
		}
		
		return( t );
	}
	
	
	public static DSsearchTreeNode findMin( DSsearchTreeNode r ) {
		
		DSsearchTreeNode t = r;
		
		while ( t!=null ) {
			if ( t.getLeftChild() != null ) {
				t = t.getLeftChild();
			}
			else {
				break;
			}
		}
		
		return( t );
	}


}
