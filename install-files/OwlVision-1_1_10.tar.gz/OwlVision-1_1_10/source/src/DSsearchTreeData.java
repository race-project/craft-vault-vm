/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.util.Iterator;
import java.util.LinkedList;


public class DSsearchTreeData {
	
	private DSxyDNode  node;  /* the start vertex of a directed edge */
	
	private LinkedList aboveRegion;    /* Tail of the Above region */
	private LinkedList belowRegion;    /* Head of the Below region */
	
	
	/* constructor */
	public DSsearchTreeData( DSxyDNode n ) {
		
		node = n;
		aboveRegion = new LinkedList();
		belowRegion = new LinkedList();
	}
	
	
	public DSxyDNode getNode() {
		
		return( node );
	}
			
	
	/* insert into the HEAD of the linked list */
	public void insertAboveHead( DSxyDNode node ) {
		
		aboveRegion.addFirst( node );
	}
	
	/* insert into the TAIL of the linked list */
	public void insertAboveTail( DSxyDNode node ) {
		
		aboveRegion.addLast( node );
	}
	
	/* insert a linked-list into the TAIL of the linked list */
	public void insertAboveTail( LinkedList list ) {
		
		DSxyDNode node;
		
		Iterator it = list.listIterator();
		
		while ( it.hasNext() ) {
			
			node = (DSxyDNode) it.next();
			aboveRegion.addLast( node );
		}
	}
	
	public void setAboveRegion( LinkedList r ) {
		
		aboveRegion = r;
	}
	
	public LinkedList getAboveRegion() {
		
		return( aboveRegion );
	}
	
	/* insert into the HEAD of the linked list */
	public void insertBelowHead( DSxyDNode node ) {
		
		belowRegion.addFirst( node );
	}
	
	/* insert an element into the TAIL of the linked list */
	public void insertBelowTail( DSxyDNode node ) {
		
		belowRegion.addLast( node );
	}
	
	/* insert a linked-list into the TAIL of the linked list */
	public void insertBelowTail( LinkedList list ) {
		
		DSxyDNode node;
		
		Iterator it = list.listIterator();
		
		while ( it.hasNext() ) {
			
			node = (DSxyDNode) it.next();
			belowRegion.addLast( node );
		}
	}
	
	
	public void setBelowRegion( LinkedList r ) {
		
		belowRegion = r;
	}
	
	public LinkedList getBelowRegion() {
		
		return( belowRegion );
	}
	
	
	public int compare(  DSsearchTreeData data, int scanLinePosX, int scanLinePosY ) 
	{
		//DSsearchTreeData d = data;		
		
		double xPos1 = findIntersectionWithScanLine( node,           scanLinePosX, scanLinePosY );
		double xPos2 = findIntersectionWithScanLine( data.getNode(), scanLinePosX, scanLinePosY );
		
		if ( (xPos1 == xPos2) || Math.abs(xPos1-xPos2)<10  ) {  /* considered equal if the difference is very small */
			double m1 = Utilities.calculateSlope( node.getX(), node.getY(), node.getNext().getX(), node.getNext().getY() );
			double m2 = Utilities.calculateSlope( data.getNode().getX(), data.getNode().getY(), data.getNode().getNext().getX(), data.getNode().getNext().getY() );
			
			/* test if both edges are above the scan line */
			if ( node.getY()>=scanLinePosY && node.getNext().getY()>=scanLinePosY &&
				 data.getNode().getY()>=scanLinePosY && data.getNode().getNext().getY()>=scanLinePosY && data.getNode().getY()!=data.getNode().getNext().getY() )  // not horizontal 
			{
				/* ABOVE THE SCAN-LINE */
				
				if (m1==m2) {
					return( 0 );
				}
				else if ( m1==0 && m2!=0 ) {
					return( 1 );
				}
				else if ( m1!=0 && m2==0 ) {
					return( -1 );
				}
				else if ( (m1 > 0 && m2 > 0) || (m1 < 0 && m2 < 0) ) {
					if ( m1 > m2 ) {
						return( -1 );
					}
					else {
						return( 1 );
					}
				}
				else if ( m1 > 0 && m2 < 0 ) {
					return( 1 );
				}
				else if ( m1 < 0 && m2 > 0 ) {
					return( -1 );
				}		
			}
			else {
				/* BELOW THE SCAN-LINE */
				
				if (m1==m2) {
					return( 0 );
				}
				else if ( m1==0 && m2!=0 ) {
					return( 1 );
				}
				else if ( m1!=0 && m2==0 ) {
					return( -1 );
				}
				else if ( (m1 > 0 && m2 > 0) || (m1 < 0 && m2 < 0) ) {
					if ( m1 > m2 ) {
						return( 1 );
					}
					else {
						return( -1 );
					}
				}
				else if ( m1 > 0 && m2 < 0 ) {
					return( -1 );
				}
				else if ( m1 < 0 && m2 > 0 ) {
					return( 1 );
				}		
			}
		}
		else if ( xPos1 > xPos2) {
			return( 1 );
		}
		else if ( xPos1 < xPos2 ) {
			return( -1 );
		}
						
		return( -2 );  /* error */
	}
	
	
	/*                   (x1,y1)
	 *                       \
	 *                        \
	 *                         \
	 *                          \ intersection point: (intersectionX,scanLinePos)
	 *   scanLinePos  -----------o----------------------------
	 *                            \
	 *                             \
	 *                              \
	 *                               \
	 *                             (x2,y2)
	 */
	private double findIntersectionWithScanLine( DSxyDNode n, int scanLinePosX, int scanLinePosY ) 
	{					
		int x1 = n.getX();
		int y1 = n.getY();
		int x2 = n.getNext().getX();
		int y2 = n.getNext().getY();
		
		/* horizontal line */
		if ( y1==y2 && y2==scanLinePosY ) {
			/* report the coordinate with smaller x */
			if ( x1 < x2 ) {
				return( x1 );
			}
			return( x2 ); 
		}
			
		/*
		if ( x1==scanLinePosX && y1==scanLinePosY ) {
			return( x1 );
		}
		if ( x2==scanLinePosX && y2==scanLinePosY ) {
			return( x2 );
		}
		*/		
		
		PointInt p = Intersection.findIntersectionWithHorizontalLine( x1, y1, x2, y2, scanLinePosY );
		
		return( p.getX() );		
	}
	
	

}
