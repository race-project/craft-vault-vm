/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/**
 * 
 */

/**
 * @author I-Lun Tseng
 *
 */
public class DSsearchTreeNode {
	
	private DSsearchTreeData  data;
	private DSsearchTreeNode  leftChild;
	private DSsearchTreeNode  rightChild;
	
	
	public DSsearchTreeNode( DSsearchTreeData data_ptr ) {
		data		= data_ptr;		
		leftChild 	= null;
		rightChild 	= null;
	}
	
	public DSsearchTreeData getData() {
		return( data );
	}
			
	public DSsearchTreeNode getLeftChild() {
		return( leftChild );
	}
	
	public DSsearchTreeNode getRightChild() {
		return( rightChild );
	}
	
	public void setLeftChild( DSsearchTreeNode left ) {
		leftChild = left;
	}
	
	public void setRightChild( DSsearchTreeNode right ) {
		rightChild = right;
	}
	
	public DSsearchTreeNode getLeftNeighbor( DSsearchTree R, int scanLinePosX, int scanLinePosY ) {
		
		if ( leftChild != null ) {
			/* we can find the left neighbor in the left sub-tree  */
			return( DSsearchTree.findMax( leftChild ) );			
		}
		else {  /* leftChild == null */
			/* we have to search for it from the root tree R */
			
			DSsearchTreeNode t  = R.getRoot();
			//DSsearchTreeData da = t.getData();
			
			int compare_result;
			//int compare_result = da.compare( data, scanLinePos );
			
			//if ( compare_result == 0 ) {
			//	return( null );
			//}
			//else if ( compare_result > 0 ) {
			//	return( null );
			//}
			//else {
			
				DSsearchTreeNode resultNode = null;
				DSsearchTreeData td;
				
				while ( t!=null ) {
					td = t.getData();					
					
					
					if ( td.getNode().getX()==data.getNode().getX() && td.getNode().getY()==data.getNode().getY() ) {
						// System.out.println("I found it.");
						break;  // exit the while loop
					}
					else {
						compare_result = td.compare( data, scanLinePosX, scanLinePosY );
						
						if ( compare_result < 0 ) {
							
							if (resultNode == null ) {
								resultNode = t;
							}
							else if ( td.compare( resultNode.getData(), scanLinePosX, scanLinePosY ) > 0 && data.compare( resultNode.getData(), scanLinePosX, scanLinePosY) > 0 ) {
								resultNode = t;
							}
							t = t.getRightChild();
						}
						else {  /* compare_result > 0 */
							//if (resultNode == null ) {
							//	resultNode = t;
							//}
							//else if ( td.compare( resultNode.getData(),scanLinePos) > 0 && data.compare( resultNode.getData(),scanLinePos) > 0 ) {
							//	resultNode = t;
							//}
							t = t.getLeftChild();
						}						
					}
				}
				
				return( resultNode );
				
			//}			
		}
		
		//return( null );
		
	}
	
	
	public DSsearchTreeNode getRightNeighbor( DSsearchTree R, int scanLinePosX, int scanLinePosY ) {
		
		//System.out.println(" getRightNeighbor");
		
		if ( rightChild != null ) {
			/* we can find the right neighbor in the right sub-tree  */
			return( DSsearchTree.findMin( rightChild ) );			
		}
		else {  /* rightChild == null */
			/* we have to search for it from the root tree R */
			
			DSsearchTreeNode t  = R.getRoot();
			//DSsearchTreeData da = t.getData();
			
			int compare_result;			
			
			DSsearchTreeNode resultNode = null;
			DSsearchTreeData td;
				
			while ( t!=null ) {
				td = t.getData();					
					
				if ( td.getNode().getX()==data.getNode().getX() && td.getNode().getY()==data.getNode().getY() ) {
					// System.out.println("I found it.");
					break;  // exit the while loop
				}
				else {
					compare_result = td.compare( data, scanLinePosX, scanLinePosY );
						
					if ( compare_result < 0 ) {
						/*	
						if (resultNode == null ) {
							resultNode = t;
						}
						else if ( td.compare( resultNode.getData(),scanLinePos) > 0 && data.compare( resultNode.getData(),scanLinePos) > 0 ) {
							resultNode = t;
						}  */
						t = t.getRightChild();
					}
					else {  /* compare_result > 0 */
						if (resultNode == null ) {
							resultNode = t;
						}
						else if ( td.compare( resultNode.getData(), scanLinePosX, scanLinePosY) < 0 && data.compare( resultNode.getData(), scanLinePosX, scanLinePosY ) < 0 ) {
							resultNode = t;
						}
						t = t.getLeftChild();
					}						
				}
			}
				
			return( resultNode );
			
		}
		
		//return( null );
		
	}
	



}
