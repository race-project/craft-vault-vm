/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Point;

/*
 * Created on 2005/4/15
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DSsrefNode {
	
	private String		 strName;
	private DSstrans 	 strans;
	private double       angle;
	private DSxyList	 xy;			// shift_x and shift_y
	private BoundingBox  overallBbox;	// the instance's bounding box, with "angle" and "xy" calculated, should be calculated top-down (from the root cell)
	private DSsrefNode	 next;
	
	
	/* constructor */
	public DSsrefNode(String 		str_name,
					  DSstrans      stransIn,
					  double        ang,
					  DSxyList 		xy_list,
					  DSsrefNode	n ) 
	{
		strName 	= str_name;
		strans		= stransIn;
		angle   	= ang;
		xy      	= xy_list;
		overallBbox = null;
		next		= n;
	}
	
	
	/* constructor */
	public DSsrefNode( DSsrefNode srefNode ) 
	{
		strName     = srefNode.getStrName();
		strans      = srefNode.getStrans();
		angle       = srefNode.getAngle();
		xy          = srefNode.getXYlist();
		overallBbox = srefNode.getOverallBbox();
		next	    = null;
	}
	
	
	public String getStrName() {
		return( strName );
	}
	
	public DSstrans getStrans() {
		return( strans );
	}
	
	public double getAngle() {
		return( angle );
	}
	
	public DSxyList getXYlist() {
		return( xy );
	}
	
	/* next */
	
	public DSsrefNode getNext() {
		return( next );
	}
	
	public void setNext( DSsrefNode n ) {
		next = n;
	}
	
	public int getMinX() {
		return( overallBbox.getMinX() );
	}
	
	public int getMaxX() {
		return( overallBbox.getMaxX() );
	}
	
	public int getMinY() {
		return( overallBbox.getMinY() );
	}
	
	public int getMaxY() {
		return( overallBbox.getMaxY() );
	}
	
	/* bounding box */
	
	/*
	public BoundingBox getBbox() {
		return( bbox );
	} */
	
	public void setOverallBbox(int x1, int x2, int y1, int y2) {
		overallBbox = new BoundingBox( x1,x2,y1,y2 );
	}
	
	/* the info is built when it is needed (on-the-fly) */
	public BoundingBox getOverallBbox() {
		
		if ( overallBbox != null ) {
			return( overallBbox );
		}
		else {
			return( buildOverallBbox() );
		}
	}
	
	
	/* ToDo: This method may have bugs. Please review the code. */
	public BoundingBox buildOverallBbox() 
	{
		
		BoundingBox strBbox = DSbuild.getOverallBbox( strName );
		
		int shift_x  = getXYlist().getHead().getX();
		int shift_y  = getXYlist().getHead().getY();
		
		boolean reflection = false;
		
		if ( strans == null ) {
			reflection = false;
		}
		else {
			reflection = strans.getBit0();
		}
		
		if ( angle == 0 )
		{
			if ( reflection == true ) {
				overallBbox = new BoundingBox( strBbox.getMinX()+shift_x, strBbox.getMaxX()+shift_x, (-1)*strBbox.getMaxY()+shift_y, (-1)*strBbox.getMinY()+shift_y );
			}
			else {
				overallBbox = new BoundingBox( strBbox.getMinX()+shift_x, strBbox.getMaxX()+shift_x, strBbox.getMinY()+shift_y, strBbox.getMaxY()+shift_y );
			}
			return( overallBbox );
		}
		else {  /* angle != 0 */
			Point point;
			int xMin, xMax, yMin, yMax;  // the resulting bbox
			
			int bboxMinX = strBbox.getMinX();
			int bboxMaxX = strBbox.getMaxX(); 
			int bboxMinY = strBbox.getMinY(); 
			int bboxMaxY = strBbox.getMaxY();
			
			if ( reflection == true ) {
				bboxMinY = (-1)*strBbox.getMaxY();
				bboxMaxY = (-1)*strBbox.getMinY();
			}
			
			point = DSbuild.rotate( bboxMinX, bboxMinY, angle);
			xMin = xMax = (int)(point.getX() + shift_x);
			yMin = yMax = (int)(point.getY() + shift_y);
			
			point = DSbuild.rotate( bboxMinX, bboxMaxY, angle);
			if ( xMin > (point.getX() + shift_x) ) {
				xMin = (int)(point.getX() + shift_x);
			}
			if ( xMax < (point.getX() + shift_x) ) {
				xMax = (int)(point.getX() + shift_x);
			}
			if ( yMin > (point.getY() + shift_y) ) {
				yMin = (int)(point.getY() + shift_y);
			}
			if ( yMax < (point.getY() + shift_y) ) {
				yMax = (int)(point.getY() + shift_y);
			}
			
			point = DSbuild.rotate( bboxMaxX, bboxMinY, angle);
			if ( xMin > (point.getX() + shift_x) ) {
				xMin = (int)(point.getX() + shift_x);
			}
			if ( xMax < (point.getX() + shift_x) ) {
				xMax = (int)(point.getX() + shift_x);
			}
			if ( yMin > (point.getY() + shift_y) ) {
				yMin = (int)(point.getY() + shift_y);
			}
			if ( yMax < (point.getY() + shift_y) ) {
				yMax = (int)(point.getY() + shift_y);
			}
			
			point = DSbuild.rotate( bboxMaxX, bboxMaxY, angle);
			if ( xMin > (point.getX() + shift_x) ) {
				xMin = (int)(point.getX() + shift_x);
			}
			if ( xMax < (point.getX() + shift_x) ) {
				xMax = (int)(point.getX() + shift_x);
			}
			if ( yMin > (point.getY() + shift_y) ) {
				yMin = (int)(point.getY() + shift_y);
			}
			if ( yMax < (point.getY() + shift_y) ) {
				yMax = (int)(point.getY() + shift_y);
			}
			
			overallBbox = new BoundingBox( xMin, xMax, yMin, yMax );
			return( overallBbox );						
		}		
	}
	

}
