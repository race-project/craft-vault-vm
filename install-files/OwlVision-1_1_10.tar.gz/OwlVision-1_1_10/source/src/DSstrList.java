/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.util.Hashtable;

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DSstrList {
	private  DSstrNode head;
	private  DSstrNode tail;
	private  Hashtable strHT;
	private  int	   number;
	
	public DSstrList() {
		head   = null;
		tail   = null;
		strHT  = new Hashtable(100, (float)0.2);
		number = 0;
	}
	
	public DSstrNode getHead() {
		return( head );
	}
	
	public DSstrNode getTail() {
		return( tail );
	}
	
	public boolean isEmpty() {
	    return (head==null);	
	}
	
	//@SuppressWarnings("unchecked")
	public void insert(DSstrNode str_node) {
		if (isEmpty()) {
			head = tail = str_node;
		}
		else {
			tail.setNext( str_node );
			tail = str_node;
		}
		/* insert into the Hashtable */
		strHT.put(str_node.getName(), str_node);
		
		//strHT.put(str_node.getName(), str_node);
		//System.out.println("Cell: " + str_node.getName());
		
		number++;		
	}
	
	/*
	public void insert(String sname) {
		if (isEmpty()) {
			head = tail = new DSstrNode(sname);	
		}
		else {  // add to the tail of the linked list
			DSstrNode tmp = new DSstrNode(sname);
			tail.next = tmp;
			tail = tmp;
		}
	    number++;
		
	}*/
	
	
	public void print() {
	
		for ( DSstrNode i=head; i!=null; i=i.getNext() ) {
			System.out.println("GDSDS-strname: "+ i.getName() );
		}
	
	}
	
	
	/* NEED TO BE IMPROVED */	
	/*
	public DSstrNode getStr(String sname) {
		for (DSstrNode node=head; node!=null; node=node.next) {
			if (sname.equals(node.strname)) {
			    return(node);	
			}
		}
		return(null);
		
	}*/
	/* Improved Version: Use Hashtable */
	public DSstrNode getStr(String sname) {
		
		return( (DSstrNode) strHT.get(sname) );
		
	}	

	
	public int getNumber() {
		return(number);
	}
	
	

}
