/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author I-Lun Tseng
 *
 * A structure means a "Cell" or a "Block".
 * 
 */
public class DSstrNode {
	
	private   String 			strname;   /* cell name */
	
	private   BoundingBox       cellLevelBbox;    /* cell-level Bounding Box */
	private   BoundingBox       overallBbox;      /* overall Bounding Box, including SREF's */
	private	  boolean			hasCellLevelElements;
	
	private   DSelements		elements;  /* all the elements, including
											* BOUNDARY, BOX, PATH, SREF
										    */
	private   QuadTreeNode		quadTree;	
	
	private   DSstrNode 		next;
	
	
	/* constructor */	
	public DSstrNode(String sname) {
		strname  = new String(sname);
		overallBbox = null;
		elements = new DSelements();
		quadTree = null;
		next     = null;
	}
	
	
	/* strname */
	
	public String getName() {
		return(strname);
	}
	
	/* elements --> BOUNDARY */
	
	public DSboundaryList getBoundaryList() {
		return( elements.getBoundaryList() );
	}
	
	public void setBoundaryList( DSboundaryList list ) {
		elements.setBoundaryList( list );
	}

	/* elements --> BOX */
	
	public DSboxList getBoxList() {
		return( elements.getBoxList() );
	}
	
	public void setBoxList( DSboxList list ) {
		elements.setBoxList( list );
	}
	
	/* elements --> SREF */
	
	public DSsrefList getSrefList() {
		return( elements.getSrefList() );
	}
	
	public void setSrefList( DSsrefList list ) {
		elements.setSrefList( list );
	}
	
	/* elements --> AREF */
	
	public DSarefList getArefList() {
		return( elements.getArefList() );
	}
	
	public void setArefList( DSarefList list ) {
		elements.setArefList( list );
	}
	
	/* elements --> PATH */
	
	public DSpathList getPathList() {
		return( elements.getPathList() );
	}
	
	public void setPathList( DSpathList list ) {
		elements.setPathList( list );
	}
	
	/* elements --> TEXT */
	
	public DStextList getTextList() {
		return( elements.getTextList() );
	}
	
	public void setTextList( DStextList list ) {
		elements.setTextList( list );
	}
	
	/* next */
	
	public DSstrNode getNext() {
		return( next );
	}
	
	public void setNext( DSstrNode n ) {
		next = n;
	}
	
	/* bbox */
	
	public BoundingBox getCellLevelBbox() {
		return( cellLevelBbox );
	}
	
	public void setCellLevelBbox( int x1, int x2, int y1, int y2 ) {
		cellLevelBbox = new BoundingBox( x1, x2, y1, y2 );		
	}
	
	public void setCellLevelBbox( BoundingBox bb ) {
		cellLevelBbox = bb;
	}
	
	public BoundingBox getOverallBbox() {
		return( overallBbox );
	}
	
	public void setOverallBbox( int x1, int x2, int y1, int y2 ) {
		overallBbox = new BoundingBox( x1, x2, y1, y2 );
	}
	
	public void setOverallBbox( BoundingBox bbox ) {
		overallBbox = bbox;
	}
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/13
	 */
	public void setHasCellLevelElements( boolean tf ) {
		hasCellLevelElements = tf;
	}
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/13
	 */
	public boolean getHasCellLevelElements() {
		return( hasCellLevelElements );
	}
	
	/*
	public int getCellLevelBboxMinX() {
		return( cellLevelBbox.getMinX() );
	}
	public int getCellLevelBbosMaxX() {
		return( cellLevelBbox.getMaxX() );
	}
	public int getCellLevelBboxMinY() {
		return( cellLevelBbox.getMinY() );
	}
	public int getCellLevelBboxMaxY() {
		return( cellLevelBbox.getMaxY() );
	} */
	
	/* === Quad Tree === */
	
	public QuadTreeNode getQuadTree() {
		return( quadTree );
	}
	
	/* BOUNDARY */
	
	public void addQuadTreeElement(DSboundaryNode bd_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		quadTree.addElement( bd_node );
	}
	
	
	public void addQuadTreeNode(int quadrant, DSboundaryNode bd_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		switch(quadrant) {
			case 0:
				quadTree.addUL(bd_node, dep+1 );
				break;
			case 1:
				quadTree.addUR(bd_node, dep+1 );
				break;
			case 2:
				quadTree.addLL(bd_node, dep+1 );
				break;
			case 3:
				quadTree.addLR(bd_node, dep+1 );
				break;
		}		
	}
	
	/* BOX */
	
	public void addQuadTreeElement(DSboxNode bo_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		quadTree.addElement( bo_node );
	}

	public void addQuadTreeNode(int quadrant, DSboxNode bo_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		switch(quadrant) {
			case 0:
				quadTree.addUL(bo_node, dep+1 );
				break;
			case 1:
				quadTree.addUR(bo_node, dep+1 );
				break;
			case 2:
				quadTree.addLL(bo_node, dep+1 );
				break;
			case 3:
				quadTree.addLR(bo_node, dep+1 );
				break;
		}		
	}
	
	/* TEXT */
	
	public void addQuadTreeElement(DStextNode tx_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		quadTree.addElement( tx_node );
	}
	
	
	public void addQuadTreeNode(int quadrant, DStextNode tx_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		switch(quadrant) {
			case 0:
				quadTree.addUL(tx_node, dep+1 );
				break;
			case 1:
				quadTree.addUR(tx_node, dep+1 );
				break;
			case 2:
				quadTree.addLL(tx_node, dep+1 );
				break;
			case 3:
				quadTree.addLR(tx_node, dep+1 );
				break;
		}		
	}
	
	/* PATH */
	
	public void addQuadTreeElement(DSpathNode pa_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		quadTree.addElement( pa_node );
	}

	public void addQuadTreeNode(int quadrant, DSpathNode pa_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		switch(quadrant) {
			case 0:
				quadTree.addUL(pa_node, dep+1 );
				break;
			case 1:
				quadTree.addUR(pa_node, dep+1 );
				break;
			case 2:
				quadTree.addLL(pa_node, dep+1 );
				break;
			case 3:
				quadTree.addLR(pa_node, dep+1 );
				break;
		}		
	}
	
	/* SREF */
	
	public void addQuadTreeElement(DSsrefNode sref_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		quadTree.addElement( sref_node );
	}
	
	
	public void addQuadTreeNode(int quadrant, DSsrefNode sref_node, int dep) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		switch(quadrant) {
			case 0:
				quadTree.addUL(sref_node, dep+1 );
				break;
			case 1:
				quadTree.addUR(sref_node, dep+1 );
				break;
			case 2:
				quadTree.addLL(sref_node, dep+1 );
				break;
			case 3:
				quadTree.addLR(sref_node, dep+1 );
				break;
		}		
	}
	
	/* AREF */
	
	public void addQuadTreeElement( DSarefNode aref_node, int dep ) {
		
		if (quadTree==null) {
			quadTree = new QuadTreeNode( dep );
		}
		
		quadTree.addElement( aref_node );
	}
	
	
	
	
	/*
	public void buildSubQuadTreeForBoundary() {
		if (quadTree==null) {
			return;
		}
	} */
	
	
	
}
