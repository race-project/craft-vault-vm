/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/* STRANS Record
 * 		usually used with SREF and AREF
 */
public class DSstrans {
	
	private boolean bit0;	/* If true, the polygon is reflected about the X-axis before angular rotation */
	private boolean bit13;
	private boolean bit14;
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version finished
	 */
	public DSstrans( int bit_0, int bit_13, int bit_14 ) 
	{
		if ( bit_0 == 1 ) {
			bit0 = true;
		}
		else {
			bit0 = false;
		}
		
		if ( bit_13 == 1 ) {
			bit13 = true;
		}
		else {
			bit13 = false;
		}
		
		if ( bit_14 == 1 ) {
			bit14 = true;
		}
		else {
			bit14 = false;
		}
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version finished
	 */
	public boolean getBit0() 
	{
		return( bit0 );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version finished
	 */
	public boolean getBit13() 
	{
		return( bit13 );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version finished
	 */
	public boolean getBit14() 
	{
		return( bit14 );
	}
	
	
}
