/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 6/12/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author iltseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DStextNode {
	
	private short 			layer;	   	// value range 0-255
	private short 			texttype;  	// value range 0-255
	private DSpresentation	presentation;
	private DSstrans		strans;
	private double			mag;
	private double			angle;
	private DSxyList		xy;
	private String			string;		// string
	private BoundingBox     bbox;	   	// the bounding box of the polygon
	private DStextNode      next;
	
	/* constructor */	
	public DStextNode(
					int 			in_layer,
					int 			in_texttype,
					DSpresentation	present,
					DSstrans		in_strans,
					double			magnificationFactor,
					double			ang,
					DSxyList 		in_xy_list,
					String          in_string,
					DStextNode      in_next) 
	{
		layer    = (short) in_layer;
		texttype = (short) in_texttype;
		presentation = present;
		strans   = in_strans;
		mag		 = magnificationFactor;
		angle	 = ang;
		xy       = in_xy_list;
		string   = in_string;
		bbox     = null;
		next	 = in_next;
	}
	
	/* constructor */
	public DStextNode( DStextNode textNode ) 
	{
		layer    = (short) textNode.getLayerNo();
		texttype = (short) textNode.getTexttype();
		presentation = textNode.getPresentation();
		strans   = textNode.getStrans();
		mag      = textNode.getMag();
		angle    = textNode.getAngle();
		xy       = textNode.getXYlist();
		string   = textNode.getString();
		bbox     = textNode.getBbox();
		next	 = null;
	}	
	
	
	public String getString() {
		return( string );
	}
	
	/* layer */
	
	public int getLayerNo() {
		return(layer);
	}
	
	/* texttype */
	
	public int getTexttype() {
		return( texttype );
	}
	
	/* presentation */
	
	public DSpresentation getPresentation() {
		return( presentation );
	}
	
	/* strans */
	
	public DSstrans getStrans() {
		return( strans );
	}
	
	/* mag */
	
	public double getMag() {
		return( mag );
	}
	
	/* angle */
	
	public double getAngle() {
		return( angle );
	}
	
	/* xy */
	
	public DSxyList getXYlist() {
		return( xy );
	}

	/* next */
	
	public DStextNode getNext() {
		return( next );
	}
	
	public void setNext( DStextNode n ) {
		next = n;
	}
	
	/* bounding box */
	
	public BoundingBox getBbox() {
		return( bbox );
	}
	
	public void setBbox(int x1, int x2, int y1, int y2) {
		bbox = new BoundingBox( x1,x2,y1,y2 );
	}
	
	public int getMinX() {
		return( bbox.getMinX() );
	}
	
	public int getMaxX() {
		return( bbox.getMaxX() );
	}
	
	public int getMinY() {
		return( bbox.getMinY() );
	}
	
	public int getMaxY() {
		return( bbox.getMaxY() );
	}


}
