/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.util.Hashtable;

public class DSxyDList {
	
	private DSxyDNode  head;
	private DSxyDNode  rear;
	private Hashtable  ht;
	
	
	public DSxyDList() {
		head = null;
		rear = null;
		ht = new Hashtable();
	}
	
	
	/* insert to the rear(tail) of the list */
	public void insert( int x, int y ) {
		DSxyDNode node = new DSxyDNode(x, y);
		
		if (head == null) {
			head = node;
			rear = node;
		}
		else {
			rear.setNext(node);
			node.setPrev(rear);
			rear = node;
		}
		String key = "" + x + "^" + y;
		ht.put(key, node);
	}
	
	
	public DSxyDNode getHead() {
	
		return( head );
	}
	
	
	public DSxyDNode getNode(int x, int y) {
		
		return ( (DSxyDNode) ht.get(""+x+"^"+y) );
	}
	
	
	public void clear() {
		head = null;
		rear = null;
		ht = new Hashtable();
	}
	
	
	public void connectHeadAndRear() {
		rear.setNext(head);
		head.setPrev(rear);
	}
	
	
	/* reverse the node list */
	public void reverse( int numOfVertices ) {
		
		DSxyDNode tmpNode = head;
		DSxyDNode tN, tP;
		
		for ( int i=0; i<numOfVertices; i++ ) {			
			tN = tmpNode.getNext();
			tP = tmpNode.getPrev();
			tmpNode.setNext( tP );
			tmpNode.setPrev( tN );
				
			tmpNode = tN;  // the next one
		}		
	}
	

}
