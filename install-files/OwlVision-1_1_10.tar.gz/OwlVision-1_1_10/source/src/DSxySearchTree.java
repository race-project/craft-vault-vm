/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Point;
import java.util.Hashtable;

/**
 * @author I-Lun Tseng
 *
 * This class is used to store eventQ, which stands for the position
 * of the scan line. The scan line will "sweep" vertices
 * from the top to the bottom of the polygons.
 * 
 * The sorting algorithm uses binary search tree structure. To speed up
 * the execution, "balanced" binary search trees should be used. 
 * 
 */

public class DSxySearchTree {
	
	private DSxySearchTreeNode root;  // the root of the search tree
	private Hashtable          ht;    // for checking the existance of a key
	
	
	/* constructor */
	public DSxySearchTree() {
		root = null;
		ht   = new Hashtable();
	}
	
	public boolean isEmpty() {
		if (root == null)
			return(true);
		else
			return(false);
	}
	
	public void insert(int x, int y) {
		DSxySearchTreeNode n = new DSxySearchTreeNode(x, y);
		
		if (root == null) {
			root = n;
			return;
		}
		
		/* root != null */
		
		DSxySearchTreeNode t = root;
		
		while (t != null) {
			if ( (x==t.getX()) && (y==t.getY())) {
				/* already exist: Do not insert */
				break;
			}
			else if ( (y > t.getY()) || (y==t.getY() && x < t.getX()) ) {
				if ( t.getRightChild() == null) {
					t.setRightChild(n);
					break;
				}
				else {
					t = t.getRightChild();
				}
			}
			else {
				if (t.getLeftChild() == null) {
					t.setLeftChild(n);
					break;
				}
				else {
					t = t.getLeftChild();
				}
			}
		}	
		
		String htKey = "" + x + "^" + y;
		ht.put( htKey, n );
		
	}
	
	
	public boolean isExist( Point point ) {
		
		return( isExist( (int)point.getX() , (int)point.getY() ) );
		
	}
	
	
	public boolean isExist( int x, int y ) {
		
		String htKey = "" + x + "^" + y;
		
		//System.out.println( "  TEST ("+ x + "," + y + "): " + ht.containsKey( htKey ) ) ;
		
		//DSxySearchTreeNode n = (DSxySearchTreeNode) ht.get( htKey );
		
		return( ht.containsKey( htKey ) );
	} 
	
	
	/* remove and return the node which has the largest value */
	public DSxySearchTreeNode pop() {
		
		DSxySearchTreeNode t        = root;
		DSxySearchTreeNode t_parent = null;
		
		while (t != null) {
			if ( t.getRightChild() != null) {
				t_parent = t;
				t = t.getRightChild();
			}
			else
				break;
		}
		
		if (t == root) {
			root = root.getLeftChild();
		}
		else {
			t_parent.setRightChild( t.getLeftChild() );
		}
		return(t);
	}

	
}
