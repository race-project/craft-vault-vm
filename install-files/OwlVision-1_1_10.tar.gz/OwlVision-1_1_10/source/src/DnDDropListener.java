/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.IOException;


public class DnDDropListener implements DropTargetListener {
	
	
	public void dragEnter(DropTargetDragEvent arg0) 
	{	
		//System.out.println("Drag Enter");
	}
	
	
	public void dragExit(DropTargetEvent arg0) {

		//System.out.println("Drag Exit");
	}
	
	
	public void dragOver(DropTargetDragEvent arg0) {

		//System.out.println("Drag Over");
	}
	
	
	public void drop(DropTargetDropEvent dtde) {

		//System.out.println("Drop");
		
		Transferable tr = dtde.getTransferable();
		DataFlavor[] flavors = tr.getTransferDataFlavors();
		
		String fileName = null;
		
		for ( int i=0; i < flavors.length; i++ ) 
		{
			//System.out.println("Possible flavor: " + flavors[i].getMimeType() ); 
					
			if ( flavors[i].isFlavorJavaFileListType() ) 
			{
				dtde.acceptDrop( DnDConstants.ACTION_COPY );
				
				java.util.List list = null;
				
				try {
					list = (java.util.List) tr.getTransferData(flavors[i]);					
				} catch (UnsupportedFlavorException e) {
					/* do nothing */
				} catch (IOException e) {
					/* do nothing */
				}
				
				for ( int j=0; j < list.size(); j++ ) 
				{
					//System.out.println("file name: " + list.get(i) );
					fileName = "" + list.get(i);
				}
			}
		}
		
		
		/* ---- Open thd GDSII file and display it on the screen ---- */
		
		MainClass.gdsii = new GDSII( fileName );
		
		MainMenu.enableFileCloseItem();
		
		final SwingWorker worker = new SwingWorker() {
	        public Object construct() {
	            //...code that might take a while to execute is here...
        		
	        	MainClass.execute();

	            return null;
	        }
	    };
	    worker.start();
	    
	}
	
	
	public void dropActionChanged(DropTargetDragEvent arg0) {
		
		//System.out.println("Drop Action Changed");
	}

}
