/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.Point;

public class Draw {
	
	private static boolean isDrawBoundary;
	private static boolean isDrawBox;
	private static boolean isDrawPath;
	private static boolean isDrawText;
	
	/* private static int debugCounter = 0; */
	
	
	/* draw the layout to the off-screen image */
    /* isOnScreen:
     * 		true:  draw the layout on the screen
     * 		false: draw the layout to a JPG or GIF file
     */
    protected static synchronized void displayLayout( Graphics2D graphics2D, boolean isOnScreen ) 
    {
    	if ( DSbuild.strList == null )
			return;
    	
    	/* related to the control of drawingThread */
    	if ( DrawLayout.isStopDrawingThread() == true ) {
    		debugThread();
    		return;
    	}
    	
    	DSstrNode str_node;
    	
    	/* Root Cell: a very simple check: head or tail as the ROOT cell */
    	if ( DSbuild.getSelectedCell() == null ) {
    		if ( DSbuild.strList.getTail().getSrefList().getHead() == null &&
    			 DSbuild.strList.getHead().getSrefList().getHead() != null ) 
    		{
    			str_node = DSbuild.strList.getHead();
    		}
    		else {
    			str_node = DSbuild.strList.getTail();
    		}
    	}
    	else {
    		str_node = DSbuild.strList.getStr( DSbuild.getSelectedCell() );
    	}
		
		// Check if the cell is visible
		if ( CellTableInfo.mayIdisplayCell( str_node.getName() ) == false ) {
			return;
		}
				
		if ( str_node!=null )
	    {
			/* Draw the layout for the data in the Quad Tree */
			/* including cell-level BOUNDARY, BOX, TEXT, and PATH */
			displayQuadTree( graphics2D, str_node.getQuadTree(), 0, null, isOnScreen );		    
	    }
		
    }  // end of displayLayout()
    
	
    private static void setColor( Graphics2D graphics2D, 
    		                      DSboundaryNode n ) 
    {
    	graphics2D.setPaint( DrawColor.getColor( n.getLayerNo() ).getColor() );
    	graphics2D.setStroke( new BasicStroke((float)1.4) );
    }
    
    private static void setColor( Graphics2D graphics2D,
    							  DSboxNode n ) 
    {
    	graphics2D.setPaint( DrawColor.getColor(n.getLayerNo()).getColor() );
    	graphics2D.setStroke( new BasicStroke((float)1.4) );
    }
    
    private static void setColor( Graphics2D graphics2D, 
            					  DStextNode n ) 
    {
    	graphics2D.setPaint( DrawColor.getColor(n.getLayerNo()).getColor() );
    	graphics2D.setStroke( new BasicStroke((float)1.4) );
    }
    
    private static void setColor( Graphics2D graphics2D,
    							  DSpathNode n ) 
    {
    	graphics2D.setPaint( DrawColor.getColor(n.getLayerNo()).getColor() );
    	graphics2D.setStroke( new BasicStroke((float)1.4) );
    }
    
    
    /* Author:  I-Lun Tseng
     * History: 2006/11/10 - AREF supported
     * 			2006/11/11 - added orientation stack
     */
    /* Display a Quad Tree */
    /* oStack includes (1) reflection (2) rotation (3) displacement
     */
    protected static void displayQuadTree( 
    							Graphics2D 			graphics2D,
    							QuadTreeNode 		qTree,
    							int					depth,
    							DSorientationStack 	oStack,
    							boolean 			isOnScreen ) 
    {
    	if ( qTree == null ) {
    		return;
    	}
    	
    	if ( depth > ToolBar.getDepthValue() ) {
    		return;
    	}
    	
    	if ( oStack == null ) {
    		oStack = new DSorientationStack();
    	}
    	
    	if ( DrawLayout.isStopDrawingThread() == true ) {
    		//debugThread();
    		return;
    	}
    	
    	/* Elements, including BOUNDARY, BOX, and PATH */
    	if ( qTree.getElements() != null ) {
    		
    		DSelements elements = qTree.getElements();
    		
    		/* display BOUNDARY-list */
    		displayBoundaryList( graphics2D, elements.getBoundaryList(), oStack, isOnScreen );
    		
    		/* display BOX-list */
    		displayBoxList( graphics2D, elements.getBoxList(), oStack, isOnScreen );
    		
    		/* display TEXT-list */
    		displayTextList( graphics2D, elements.getTextList(), oStack, isOnScreen );

    		/* display PATH-list */
    		displayPathList( graphics2D, elements.getPathList(), oStack, isOnScreen );
    		
    		/* display SREF-list */
    		displaySrefList( graphics2D, elements.getSrefList(), depth+1, oStack, isOnScreen );
    		
    		/* display AREF-list */
    		displayArefList( graphics2D, elements.getArefList(), depth+1, oStack, isOnScreen );
    	}
    	    	
    	/* ULeft */
    	if ( qTree.getULeft() != null ) {
    		displayQuadTree( graphics2D, qTree.getULeft(), depth, oStack, isOnScreen );
    	}
    	/* URight */
    	if ( qTree.getURight() != null ) {
    		displayQuadTree( graphics2D, qTree.getURight(), depth, oStack, isOnScreen );
    	}
    	/* LLeft */
    	if ( qTree.getLLeft() != null ) {
    		displayQuadTree( graphics2D, qTree.getLLeft(), depth, oStack, isOnScreen );
    	}
    	/* LRight */
    	if ( qTree.getLRight() != null ) {
    		displayQuadTree( graphics2D, qTree.getLRight(), depth, oStack, isOnScreen );
    	}    	
    }
    
    
    /* Author:  I-Lun Tseng
     * History: 2006/11/09 - added a new argument "reflection"
     * 			2006/11/11 - added orientation stack
     */
    /* quadTree --> BOUNDARY-list */
    private static void displayBoundaryList( 
    						Graphics2D      	graphics2D,
    						DSboundaryList  	boundaryList,
    						DSorientationStack 	oStack,
    						boolean 			isOnScreen )
    {
    	if ( (getIsDrawBoundaryState() == false && getIsDrawPathState() == false) || 
    	     boundaryList == null) 
    	{
    		return;
    	}
    	
    	/* BOUNDARY */
	    for (DSboundaryNode b_node = boundaryList.getHead();
	         b_node != null;
	         b_node = b_node.getNext() )
	    {
	    	/* related to the control of drawingThread */
	    	if ( DrawLayout.isStopDrawingThread() == true ) {
	    		// debugThread();
	    		return;
	    	}
	    	
	    	/* a PATH */
	    	if ( b_node.isPath()==true && getIsDrawPathState()==false ) {
	    		continue;
	    	} 
	    	/* a BOUNDARY */
	    	if ( b_node.isPath()==false && getIsDrawBoundaryState()==false ) {
	    		continue;
	    	}
	    	
	    	// Check (1)Layer?  (2)Too small?
	    	if ( DSbuild.mayIdisplayThisElement( b_node ) == false ) {
	    		continue;
	    	}
	    	
	    	Draw.setColor( graphics2D, b_node );
	    	
	    	int [] xList = new int [600];
	    	int [] yList = new int [600];
	    	int numPoints = 0;
	    			    			    	
		    for (DSxyNode xy_node=b_node.getXYlist().getHead();
		         xy_node!=null && xy_node.getNext()!=null;
		         xy_node=xy_node.getNext() )
		    {
		    	/* calculate (x,y) baed on orientation */
		    	Point oPoint = DSbuild.calculateOrientation( xy_node.getX(), xy_node.getY(), oStack );
		    	
			    xList[numPoints] = (int) oPoint.getX();
			    yList[numPoints] = (int) oPoint.getY();
			    numPoints++;				    
		    }
		    
		    DrawPolygon.draw( graphics2D, xList, yList, numPoints, b_node.getLayerNo(), isOnScreen );

	    }  /* BOUNDARY */    	
    }
    
    
    /* quadTree --> BOX-list */
    private static void displayBoxList(
    						Graphics2D  		graphics2D,
							DSboxList   		boxList,
							DSorientationStack	oStack,
							boolean				isOnScreen )
    {
    	if ( getIsDrawBoxState() == false ||
    		 boxList == null ) 
    	{
    		return;
    	}
    	
    	/* BOX */
	    for (DSboxNode b_node = boxList.getHead();
	         b_node!=null;
	         b_node=b_node.getNext() )
	    {
	    	/* related to the control of drawingThread */
	    	if ( DrawLayout.isStopDrawingThread() == true ) {
	    		// debugThread();
	    		return;
	    	}
	    	
	    	// Check (1)Layer?  (2)Too small?
	    	if ( DSbuild.mayIdisplayThisElement( b_node ) == false ) {
	    		continue;
	    	}
	    	Draw.setColor( graphics2D, b_node );
	    	
	    	int [] xList = new int [600];
	    	int [] yList = new int [600];
	    	int numPoints = 0;
	    	
		    for (DSxyNode xy_node=b_node.getXYlist().getHead();
		         xy_node!=null && xy_node.getNext()!=null;
		         xy_node=xy_node.getNext() )
		    {
		    	/* calculate orientation */
		    	Point oPoint = DSbuild.calculateOrientation( xy_node.getX(), xy_node.getY(), oStack );
		    
			    xList[numPoints] = (int) oPoint.getX();
			    yList[numPoints] = (int) oPoint.getY();
			    numPoints++;
		    }
		    
		    DrawPolygon.draw( graphics2D, xList, yList, numPoints, b_node.getLayerNo(), isOnScreen );
		    
	    }  /* BOX */	
    }
    
    
    /* quadTree --> TEXT-list */
    private static void displayTextList( 
    						Graphics2D      	graphics2D,
    						DStextList      	textList,
    						DSorientationStack	oStack,
    						boolean				isOnScreen )
    {
    	if ( getIsDrawTextState() == false ||
    		 textList == null) 
    	{
    		return;
    	}
    	
    	/* TEXT */
	    for (DStextNode tx_node = textList.getHead();
	         tx_node != null;
	         tx_node = tx_node.getNext() )
	    {
	    	/* related to the control of drawingThread */
	    	if ( DrawLayout.isStopDrawingThread() == true ) {
	    		// debugThread();
	    		return;
	    	}
	    	
	    	/* Check (1)Layer */
	    	if ( DSbuild.mayIdisplayThisElement( tx_node ) == false ) {
	    		continue;
	    	}
	    	Draw.setColor(graphics2D, tx_node);
	    	
	    	//int [] xList = new int [600];
	    	//int [] yList = new int [600];
	    	/* int numPoints = 0; */
	    			    			
	    	/* should contain only one xy_node */
		    for (DSxyNode xy_node = tx_node.getXYlist().getHead();
		         xy_node != null;
		         xy_node = xy_node.getNext() )
		    {
		    	/* calculate orientation */
		    	Point oPoint = DSbuild.calculateOrientation( xy_node.getX(), xy_node.getY(), oStack );
		    	
		    	/*
		    	if ( oStack.getHead() != null ) {
		    		double angle = oStack.getHead().getAngle();
		    		graphics2D.rotate( angle );
		    	}
		    	*/
		    	
		    	//graphics2D.rotate( 5 );
			    
			    DrawText.draw( graphics2D, 
			    		       (int) oPoint.getX(), 
							   (int) oPoint.getY(), 
							   tx_node,
							   isOnScreen );
		    }
		    
	    }  /* TEXT */    	
    }
    
    
    /* quadTree --> PATH-list */
    private static void displayPathList( 
    						Graphics2D  		graphics2D,
    						DSpathList  		pathList,
    						DSorientationStack 	oStack,
    						boolean				isOnScreen )
    {
    	if ( getIsDrawPathState() == false ||
    		 pathList == null ) 
    	{
    		return;
    	}
    	
    	/* PATH */
	    for (DSpathNode node = pathList.getHead();
	         node!=null;
	         node=node.getNext() )
	    {
	    	/* related to the control of drawingThread */
	    	if ( DrawLayout.isStopDrawingThread() == true ) {
	    		// debugThread();
	    		return;
	    	}
	    	
	    	// Check (1)Layer?  (2)Too small?
	    	if ( DSbuild.mayIdisplayThisElement( node ) == false ) {
	    		continue;
	    	}
	    	
	    	Draw.setColor(graphics2D, node);
	    	
	    	DrawPath.drawPath( graphics2D, node.getXYlist(), node.getWidth(), oStack, node.getLayerNo(), isOnScreen );

	    }  /* PATH */    	
    }
    
    
    /* quadTree --> SREF-list */
    private static void displaySrefList( 
    						Graphics2D  		graphics2D,
    						DSsrefList  		srefList,
    						int					depth,
    						DSorientationStack 	oStack,
    						boolean				isOnScreen )
    {  
    	if ( srefList == null ) {
       		return;
       	}
    	
    	if ( depth > ToolBar.getDepthValue() ) {
    		return;
    	}
    	
    	/* SREF */
    	for ( DSsrefNode srefNode = srefList.getHead();
    		  srefNode != null;
    		  srefNode = srefNode.getNext() )
	    {
	    	/* related to the control of drawingThread */
	    	if ( DrawLayout.isStopDrawingThread() == true ) {
	    		// debugThread();
	    		return;
	    	}
	    	
	    	/* Check if the cell is visible */
            if ( CellTableInfo.mayIdisplayCell( srefNode.getStrName() ) == false ) {
                continue;
            }
	    	
            /* get STRANS-->bit0 (reflection bit) */
            boolean reflection;
            if ( srefNode.getStrans() != null ) {
            	reflection = srefNode.getStrans().getBit0();
            }
            else {
            	reflection = false;
            }
            
            /* get shift_x and shift_y */
            for ( DSxyNode xyNode = srefNode.getXYlist().getHead();
            	  xyNode != null;
                  xyNode = xyNode.getNext() )
            {
            	DSorientationStack oStack_2 = oStack.shallowCopy();
            	
            	oStack_2.insert( reflection, srefNode.getAngle(), xyNode.getX(), xyNode.getY() );
            	
            	//int shift_x = xyNode.getX();
            	//int shift_y = xyNode.getY();
            	
            	displaySrefNode( graphics2D, srefNode.getStrName(), depth, oStack_2, isOnScreen ); 
            			//reflection, srefNode.getAngle()+angle, shift_x+shiftX, shift_y+shiftY);
            }
            
	    }  /* SREF */    	
    }
    
    
    /* Author:  I-Lun Tseng
     * History: 2006/11/10 - initial version
     */
    /* quadTree --> AREF-list */
    private static void displayArefList( 
    						Graphics2D  		graphics2D,
    						DSarefList  		arefList,
    						int					depth,
    						DSorientationStack 	oStack,
    						boolean				isOnScreen )
    {  
    	if ( arefList == null ) {
       		return;
       	}
    	
    	if ( depth > ToolBar.getDepthValue() ) {
    		return;
    	}
    	
    	/* AREF */
    	for ( DSarefNode arefNode = arefList.getHead();
    		  arefNode != null;
    		  arefNode = arefNode.getNext() )
	    {
	    	/* related to the control of drawingThread */
	    	if ( DrawLayout.isStopDrawingThread() == true ) {
	    		// debugThread();
	    		return;
	    	}
	    	
	    	/* Check if the cell is visible */
            if ( CellTableInfo.mayIdisplayCell( arefNode.getStrName() ) == false ) {
                continue;
            }
	    	
            displayArefNode( graphics2D, arefNode, depth, oStack, isOnScreen ); 
            		//reflection, angle, shiftX, shiftY );
            
	    }  /* AREF */    	
    }
    
    
    
    
    /* Author:  I-Lun Tseng
     * History: 2006/11/09 - added a new argument "reflection"
     * 
     */
    private static synchronized void displaySrefNode(   
    													Graphics2D 			graphics2D,
    													String 				strName, 
    													int					depth,
    													DSorientationStack 	oStack,
    													boolean				isOnScreen )
    {
		DSstrNode strNode = DSbuild.strList.getStr( strName );
		
		if ( strNode!=null )
	    {
			/* BOUNDARY */
			if ( getIsDrawBoundaryState() == true ) {				
				displayBoundaryList( graphics2D, strNode.getBoundaryList(), oStack, isOnScreen ); 
			} 

		    /* BOX */
			if ( getIsDrawBoxState() == true ) {
				displayBoxList( graphics2D, strNode.getBoxList(), oStack, isOnScreen );
			}
				
		    /* PATH */		
			if ( getIsDrawPathState() == true ) {
				displayPathList( graphics2D, strNode.getPathList(), oStack, isOnScreen );
			}
			
			/* TEXT */
			if ( getIsDrawTextState() == true ) {
				displayTextList( graphics2D, strNode.getTextList(), oStack, isOnScreen );
			}
			
		    /* SREF */
			displaySrefList( graphics2D, strNode.getSrefList(), depth+1, oStack, isOnScreen );
			
			/* AREF */
			displayArefList( graphics2D, strNode.getArefList(), depth+1, oStack, isOnScreen );
			
	    }  // END: if ( strNode!=null )	    	
    }  // end of displaySREF()
    
    
    /* Author:  I-Lun Tseng
     * History: 2006/11/10 - initial version
     * 		    2006/11/14 - fixed AREF-rotation and AREF-reflection bugs
     */
    /* In AREF, reflection and rotation are treated differently. */
    private static synchronized void displayArefNode( 	Graphics2D 			graphics2D, 
    													DSarefNode			arefNode,
    													int					depth,
    													DSorientationStack 	oStack,
    													boolean				isOnScreen )
    {
    	DSstrNode strNode = DSbuild.strList.getStr( arefNode.getStrName() );
    	
    	if ( strNode==null ) {
    		return;
    	}
    	
    	boolean reflection;
        if ( arefNode.getStrans() != null ) {
        	reflection = arefNode.getStrans().getBit0();
        }
        else {
        	reflection = false;
        }
        
        double angle = arefNode.getAngle();
        
        //DSorientationStack oStack_2 = oStack.copyAndInsertRear( reflection, angle, 0, 0 );
        //oStack = oStack_2;
    	
    	/* An AREF node must have three xy nodes */
    	/* get (X1,Y1), (X2,Y2), and (X3,Y3) */
        
        DSxyNode vertex1 = arefNode.getXYlist().getHead();
        DSxyNode vertex2 = vertex1.getNext();
        DSxyNode vertex3 = vertex2.getNext();
        
        /*
        int minX = vertex1.getX();
        int maxX = vertex1.getX();
        int minY = vertex1.getY();
        int	maxY = vertex1.getY();
        
        minX = ( minX > vertex2.getX() ) ? vertex2.getX() : minX;
        maxX = ( maxX < vertex2.getX() ) ? vertex2.getX() : maxX;
        minY = ( minY > vertex2.getY() ) ? vertex2.getY() : minY;
        maxY = ( maxY < vertex2.getY() ) ? vertex2.getY() : maxY;
        
        minX = ( minX > vertex3.getX() ) ? vertex3.getX() : minX;
        maxX = ( maxX < vertex3.getX() ) ? vertex3.getX() : maxX;
        minY = ( minY > vertex3.getY() ) ? vertex3.getY() : minY;
        maxY = ( maxY < vertex3.getY() ) ? vertex3.getY() : maxY;
        
        vertex1 = new DSxyNode( minX, minY, null );
        vertex2 = new DSxyNode( maxX, minY, null );
        vertex3 = new DSxyNode( minX, maxY, null );        
        */
        
        //int col;
        //int row;
        //int interColSpacing;
        //int interRowSpacing;
        
        int col = arefNode.getColrow().getCol();
        int row = arefNode.getColrow().getRow();
        
        int interColSpacingX = (vertex2.getX() - vertex1.getX()) / col;
        int interColSpacingY = (vertex2.getY() - vertex1.getY()) / col;
        int interRowSpacingX = (vertex3.getX() - vertex1.getX()) / row;
        int interRowSpacingY = (vertex3.getY() - vertex1.getY()) / row;
        
        /*
        if ( vertex1.getY() == vertex2.getY() ) {
        	col = arefNode.getColrow().getCol();
            row = arefNode.getColrow().getRow();
            interColSpacing = vertex2.getX() - vertex1.getX();
            interRowSpacing = vertex3.getY() - vertex1.getY();
        }
        else {
        	
        	col = arefNode.getColrow().getRow();
        	row = arefNode.getColrow().getCol();
        	DSxyNode vertexTemp = vertex2;
        	vertex2 = vertex3;
        	vertex3 = vertexTemp;
        	interColSpacing = vertex2.getY() - vertex1.getY();
            interRowSpacing = vertex3.getX() - vertex1.getX();
            return ;
        }
        */
        
        /* ToDo: AREF's angle ? */ 
        
        
        //int arrayColLength = (int) Utilities.distance( vertex1.getX(), vertex1.getY(), vertex2.getX(), vertex2.getY() );
        //int arrayRowLength = (int) Utilities.distance( vertex1.getX(), vertex1.getY(), vertex3.getX(), vertex3.getY() );
        
        /*
        int arrayColLength = vertex2.getX() - vertex1.getX();
        int arrayRowLength = vertex3.getY() - vertex1.getY();
        */
                
        //int interColSpacing = arrayColLength / col;
        //int interRowSpacing = arrayRowLength / row;
        
        int tempX = vertex1.getX();
        int tempY = vertex1.getY(); 
        
        int tempXc = tempX;
        int tempYc = tempY;
        
        
        for ( int c = 1; c <= col; c++ ) 
        {
        	for ( int r = 1; r <= row; r++ ) 
        	{
        		DSorientationStack oStack_2 = oStack.shallowCopy();    	
            	oStack_2.insert( reflection, angle, tempX, tempY );
            	
        		/* BOUNDARY */
        		if ( getIsDrawBoundaryState() == true ) {				
        			displayBoundaryList( graphics2D, strNode.getBoundaryList(), oStack_2, isOnScreen ); 
        		}
        		
        		/* BOX */
        		if ( getIsDrawBoxState() == true ) {
    				displayBoxList( graphics2D, strNode.getBoxList(), oStack_2, isOnScreen ); 
    			}
        		
        		/* PATH */
        		if ( getIsDrawPathState() == true ) {
    				displayPathList( graphics2D, strNode.getPathList(), oStack_2, isOnScreen ); 
    			}
        		
        		/* TEXT - ToDo */
        		
        		if ( r == row ) {
        			tempX = tempXc;
        			tempY = tempYc;
        		}
        		else {
        			tempX += interRowSpacingX;
        			tempY += interRowSpacingY;
        		}
        	}
        	
        	tempX += interColSpacingX;
        	tempY += interColSpacingY;
        	
        	tempXc = tempX;
        	tempYc = tempY;
        	
        }        
        
    }  // END of displayArefNode()
    
    
    /* for JPG and GIF */
    public static BufferedImage createLayoutImage( int imageWidth, int imageHeight) 
    {
    	BufferedImage bImage;
    	Graphics2D    g2d;
    	
    	int imageW = imageWidth;    	
    	int imageH = imageHeight;
    	
    	//int imageW = 1200;    	
    	//int imageH = 1200;
    	
    	//int imageW = 100;    	
    	//int imageH = 100;
    	

		SizeSetting2.initialize();
		SizeSetting2.setImageSize( imageW, imageH );
    	
    	bImage = new BufferedImage( imageW, imageH, BufferedImage.TYPE_INT_RGB );
    	g2d = (Graphics2D) bImage.getGraphics();
    	// Antialiasing: can make the lines look thicker
    	g2d.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
    	
    	g2d.setPaint( new Color(0, 0, 0, 255) );
    	g2d.fillRect( 0, 0, imageW, imageH );
    	
    	// put the layout onto the image
    	//Draw.displayLayout2( g2d );
    	Draw.displayLayout( g2d, false );
    	
    	return( bImage );
    }
    
    
    protected static synchronized void clearImage( Graphics2D graphics2D, int imageWidth, int imageHeight) 
    {
    	/* related to the control of drawingThread */
    	if ( DrawLayout.isStopDrawingThread() == true ) 
    	{
    		//debugThread();
    		return;
    	}
    	
    	graphics2D.setPaint( Color.black );
    	//graphics2D.setPaint( new Color(0,0,255,0) );
    	graphics2D.fillRect( 0, 0, imageWidth, imageHeight );    	
    	graphics2D.setPaint( Color.white );    	
    }  // END of clearImage()
    
    
    protected static void debugThread() {
    	//debugCounter++;
    	//System.out.println("" + debugCounter + ": Thread terminated.");
    }
    
    /* === flags === */
    
    public static void setIsDrawBoundaryState( boolean state ) {
    	isDrawBoundary = state;
    }
    
    public static void setIsDrawBoxState( boolean state ) {
    	isDrawBox = state;
    }
    
    public static void setIsDrawPathState( boolean state ) {
    	isDrawPath = state;
    }
    
    public static void setIsDrawTextState( boolean state ) {
    	isDrawText = state;
    }
    
    public static boolean getIsDrawBoundaryState() {
    	return( isDrawBoundary );
    }
    
    public static boolean getIsDrawBoxState() {
    	return( isDrawBox );
    }
    
    public static boolean getIsDrawPathState() {
    	return( isDrawPath );
    }
    
    public static boolean getIsDrawTextState() {
    	return( isDrawText );
    }
    

}
