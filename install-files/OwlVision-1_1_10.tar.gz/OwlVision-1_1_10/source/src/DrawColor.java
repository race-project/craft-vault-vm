/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;


public class DrawColor {
	
	private static LayerColor [] layerColor = new LayerColor[256];
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/10 - added error handling for 'color.txt'
	 */
	/* Return:
	 *   true : 'color.txt' is opened successfully
	 * 	 false: 'color.txt' cannot be found
	 */
	public static boolean read( String file_name ) 
	{

		String defaultFileName = "color.txt";
		String gdsiiFileName = GDSII.getFileName();
		String layerColorSettingsFileName;
		
		if ( gdsiiFileName == null ) {
			layerColorSettingsFileName = defaultFileName;
		}
		else {
			layerColorSettingsFileName = gdsiiFileName + ".owl";
		}
		
		/* Test if the file ".owl" exists  */
		/* Use 'color.txt' is the ".owl" file does not exist */
		File fileTemp = new File( layerColorSettingsFileName );		
		if ( fileTemp.exists() == false ) {
			layerColorSettingsFileName = System.getProperty("user.dir") + "\\" + defaultFileName;
		}
		
		if ( file_name != null ) {
			layerColorSettingsFileName = file_name;
		}
		
		String theLine;
		
		try {
			//FileInputStream fileColor =  new FileInputStream("color.txt");
			FileInputStream fileColor =  new FileInputStream( layerColorSettingsFileName );
			BufferedReader readColor = new BufferedReader( new InputStreamReader(fileColor) );
			
			while ( (theLine = readColor.readLine()) != null) {
				//System.out.println("==> " + theLine);
				
				theLine = theLine.trim();
				
				String [] fields = Pattern.compile("[ \t]+").split(theLine);
				
				/* the line is comment - ignore the line */
				if ( fields[0].substring(0,1).compareTo("#") == 0 ) {
					continue;
				}
				
				//System.out.println("|" + fields[0] + "|" + fields[1] + "|" + fields[2] + "|" + fields[3] + "|" );
				
				layerColor[Integer.parseInt(fields[0])] = 
					new LayerColor( 
						Integer.parseInt(fields[1]),    // Red 
						Integer.parseInt(fields[2]),    // Green
						Integer.parseInt(fields[3]),    // Blue
						Integer.parseInt(fields[4]),    // Alpha
						Integer.parseInt(fields[5]) );  // fill ("0" or "1" means "yes" or "no")
			}
			
			//String currDir = System.getProperty("user.dir");
			
			String msg = "The layer color settings file '" + layerColorSettingsFileName + "' was read.\n";
			
			MainClass.appendConsoleText( msg );
			
			return( true );
		} 
		catch (FileNotFoundException e) 
		{
			if ( file_name != null ) {
				
				/* Show error message */			
				String msg = "The layer color settings file '" + file_name + "' was not found.";
				
				MainClass.appendConsoleText( "ERROR: " + msg );
				
				JOptionPane.showMessageDialog( 	MainClass.frame, 
												msg, 
												"Error", 			// title of the message dialog box
												JOptionPane.ERROR_MESSAGE );
			}
			else {
				/* If 'color.txt' does not exist, read layer color settings from hard coded data. */
				setDefaultLayerColor();
			}
		} 
		catch (IOException e) {
			/* do nothing */
		}
		
		return( false );
		
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/12 - initial version
	 */
	public static void setDefaultLayerColor()
	{	
		MainClass.appendConsoleText("The default layer color settings are used.\n");
		
		int alpha  = 200;
		int isFill = 0;
		
		layerColor[0]   = new LayerColor( 180, 201, 243, alpha, isFill );
		layerColor[1]   = new LayerColor( 255,  30,  30, alpha, isFill );
		layerColor[2]   = new LayerColor( 150, 150, 150, alpha, isFill );
		layerColor[3]   = new LayerColor( 155, 255, 255, alpha, isFill );
		layerColor[4]   = new LayerColor( 255, 255, 195, alpha, isFill );
		layerColor[5]   = new LayerColor(  55,  25, 255, alpha, isFill );
		layerColor[6]   = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[7]   = new LayerColor( 150, 150,  99, alpha, isFill );
		layerColor[8]   = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[9]   = new LayerColor( 230, 230,  50, alpha, isFill );
		layerColor[10]  = new LayerColor( 155, 255, 255, alpha, isFill );
		layerColor[11]  = new LayerColor( 255, 185, 252, alpha, isFill );
		layerColor[12]  = new LayerColor( 255, 155, 255, alpha, isFill );
		layerColor[13]  = new LayerColor( 255, 255, 155, alpha, isFill );
		layerColor[14]  = new LayerColor( 125, 155, 175, alpha, isFill );
		layerColor[15]  = new LayerColor( 255, 215, 255, alpha, isFill );
		layerColor[16]  = new LayerColor( 255, 255, 185, alpha, isFill );
		layerColor[17]  = new LayerColor( 255, 155, 155, alpha, isFill );
		layerColor[18]  = new LayerColor( 155, 255, 250, alpha, isFill );
		layerColor[19]  = new LayerColor( 255,   0, 185, alpha, isFill );
		layerColor[20]  = new LayerColor(   0, 255, 255, alpha, isFill );
		layerColor[21]  = new LayerColor( 255,  55,   0, alpha, isFill );
		layerColor[22]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[23]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[24]  = new LayerColor(  78,  25, 123, alpha, isFill );
		layerColor[25]  = new LayerColor(  54, 255, 255, alpha, isFill );
		layerColor[26]  = new LayerColor( 255, 134, 179, alpha, isFill );
		layerColor[27]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[28]  = new LayerColor(  56, 255, 180, alpha, isFill );
		layerColor[29]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[30]  = new LayerColor( 155, 255, 221, alpha, isFill );
		layerColor[31]  = new LayerColor(  55, 255, 255, alpha, isFill );
		layerColor[32]  = new LayerColor( 255,  55, 205, alpha, isFill );
		layerColor[33]  = new LayerColor( 255, 255, 205, alpha, isFill );
		layerColor[34]  = new LayerColor(  25, 255,  55, alpha, isFill );
		layerColor[35]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[36]  = new LayerColor( 255, 255,  55, alpha, isFill );
		layerColor[37]  = new LayerColor( 255,  55, 253, alpha, isFill );
		layerColor[38]  = new LayerColor(  25, 255, 252, alpha, isFill );
		layerColor[39]  = new LayerColor( 255, 255,  23, alpha, isFill );
		layerColor[40]  = new LayerColor(  25, 155, 251, alpha, isFill );
		layerColor[41]  = new LayerColor(   0, 255, 252, alpha, isFill );
		layerColor[42]  = new LayerColor(   0, 200, 200, alpha, isFill );
		layerColor[43]  = new LayerColor(  90, 255,  90, alpha, isFill );
		layerColor[44]  = new LayerColor( 210, 255, 180, alpha, isFill );
		layerColor[45]  = new LayerColor( 230, 155,  50, alpha, isFill );
		layerColor[46]  = new LayerColor( 255,   0,   0, alpha, isFill );
		layerColor[47]  = new LayerColor( 186,  20,  70, alpha, isFill );
		layerColor[48]  = new LayerColor( 115, 241, 194, alpha, isFill );
		layerColor[49]  = new LayerColor(   0,   0, 255, alpha, isFill );
		layerColor[50]  = new LayerColor( 255, 100,   0, alpha, isFill );
		layerColor[51]  = new LayerColor( 255, 255,   0, alpha, isFill );
		layerColor[52]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[53]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[54]  = new LayerColor( 255, 255,  67, alpha, isFill );
		layerColor[55]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[56]  = new LayerColor( 255,  90, 255, alpha, isFill );
		layerColor[57]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[58]  = new LayerColor( 255, 255,  70, alpha, isFill );
		layerColor[59]  = new LayerColor(  80, 255,  25, alpha, isFill );
		layerColor[60]  = new LayerColor( 255,  78, 255, alpha, isFill );
		layerColor[61]  = new LayerColor( 100, 100, 255, alpha, isFill );
		layerColor[62]  = new LayerColor(  90, 255,  25, alpha, isFill );
		layerColor[63]  = new LayerColor( 255, 255,  25, alpha, isFill );
		layerColor[64]  = new LayerColor( 255,  45,  55, alpha, isFill );
		layerColor[65]  = new LayerColor( 255, 255,  55, alpha, isFill );
		layerColor[66]  = new LayerColor( 255, 255,  34, alpha, isFill );
		layerColor[67]  = new LayerColor( 255,  67, 255, alpha, isFill );
		layerColor[68]  = new LayerColor( 187, 255, 255, alpha, isFill );
		layerColor[69]  = new LayerColor( 255, 134,  55, alpha, isFill );
		layerColor[70]  = new LayerColor( 255, 255, 123, alpha, isFill );
		layerColor[71]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[72]  = new LayerColor( 255, 255, 189, alpha, isFill );
		layerColor[73]  = new LayerColor( 255, 132, 255, alpha, isFill );
		layerColor[74]  = new LayerColor( 123, 255, 255, alpha, isFill );
		layerColor[75]  = new LayerColor( 255, 167,  55, alpha, isFill );
		layerColor[76]  = new LayerColor( 255, 255, 212, alpha, isFill );
		layerColor[77]  = new LayerColor(   5, 252, 255, alpha, isFill );
		layerColor[78]  = new LayerColor( 255, 235,  55, alpha, isFill );
		layerColor[79]  = new LayerColor( 255,   2, 255, alpha, isFill );
		layerColor[80]  = new LayerColor( 255, 253, 255, alpha, isFill );
		layerColor[81]  = new LayerColor( 255, 245,  55, alpha, isFill );
		layerColor[82]  = new LayerColor(  45,  42, 255, alpha, isFill );
		layerColor[83]  = new LayerColor( 255, 255,  55, alpha, isFill );
		layerColor[84]  = new LayerColor( 255, 100,  44, alpha, isFill );
		layerColor[85]  = new LayerColor(  55, 255,  12, alpha, isFill );
		layerColor[86]  = new LayerColor( 255, 255,  14, alpha, isFill );
		layerColor[87]  = new LayerColor( 255,  18, 255, alpha, isFill );
		layerColor[88]  = new LayerColor(  12, 255, 255, alpha, isFill );
		layerColor[89]  = new LayerColor( 255,  12,  45, alpha, isFill );
		layerColor[90]  = new LayerColor( 255, 255,  25, alpha, isFill );
		layerColor[91]  = new LayerColor( 255, 155, 255, alpha, isFill );
		layerColor[92]  = new LayerColor(  51, 255,   2, alpha, isFill );
		layerColor[93]  = new LayerColor(  12,  19, 255, alpha, isFill );
		layerColor[94]  = new LayerColor( 255, 255, 205, alpha, isFill );
		layerColor[95]  = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[96]  = new LayerColor( 255,  25, 215, alpha, isFill );
		layerColor[97]  = new LayerColor(  25, 225, 255, alpha, isFill );
		layerColor[98]  = new LayerColor( 255, 125, 225, alpha, isFill );
		layerColor[99]  = new LayerColor( 155, 255, 255, alpha, isFill );
		layerColor[100] = new LayerColor( 125, 255, 245, alpha, isFill );
		layerColor[101] = new LayerColor(  75, 255, 255, alpha, isFill );
		layerColor[102] = new LayerColor(  95, 255, 111, alpha, isFill );
		layerColor[103] = new LayerColor( 255,  80, 155, alpha, isFill );
		layerColor[104] = new LayerColor( 255,  90, 255, alpha, isFill );
		layerColor[105] = new LayerColor( 255, 111, 255, alpha, isFill );
		layerColor[106] = new LayerColor( 255, 125, 255, alpha, isFill );
		layerColor[107] = new LayerColor(  25, 255, 255, alpha, isFill );
		layerColor[108] = new LayerColor( 155, 255, 255, alpha, isFill );
		layerColor[109] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[110] = new LayerColor( 255,  25, 255, alpha, isFill );
		layerColor[111] = new LayerColor( 255,  25,  25, alpha, isFill );
		layerColor[112] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[113] = new LayerColor(  55, 255, 155, alpha, isFill );
		layerColor[114] = new LayerColor(  55, 255, 255, alpha, isFill );
		layerColor[115] = new LayerColor( 255,  55, 255, alpha, isFill );
		layerColor[116] = new LayerColor( 250, 255, 255, alpha, isFill );
		layerColor[117] = new LayerColor( 255, 215, 225, alpha, isFill );
		layerColor[118] = new LayerColor( 200, 215, 245, alpha, isFill );
		layerColor[119] = new LayerColor( 215, 235, 155, alpha, isFill );
		layerColor[120] = new LayerColor( 155, 155, 225, alpha, isFill );
		layerColor[121] = new LayerColor(  90,  89, 255, alpha, isFill );
		layerColor[122] = new LayerColor( 255, 255,  89, alpha, isFill );
		layerColor[123] = new LayerColor( 255,  67,  78, alpha, isFill );
		layerColor[124] = new LayerColor(  67, 255, 255, alpha, isFill );
		layerColor[125] = new LayerColor( 255,  56, 255, alpha, isFill );
		layerColor[126] = new LayerColor( 255,  34,  45, alpha, isFill );
		layerColor[127] = new LayerColor(  23,  34, 255, alpha, isFill );
		layerColor[128] = new LayerColor( 255,  23, 255, alpha, isFill );
		layerColor[129] = new LayerColor( 255, 255,  12, alpha, isFill );
		layerColor[130] = new LayerColor( 255,  89,  90, alpha, isFill );
		layerColor[131] = new LayerColor(  78,  67, 255, alpha, isFill );
		layerColor[132] = new LayerColor(  60,  56, 255, alpha, isFill );
		layerColor[133] = new LayerColor( 255, 110, 255, alpha, isFill );
		layerColor[134] = new LayerColor( 255, 255, 100, alpha, isFill );
		layerColor[135] = new LayerColor( 255,  90, 255, alpha, isFill );
		layerColor[136] = new LayerColor(  80, 255, 255, alpha, isFill );
		layerColor[137] = new LayerColor( 255,  70, 255, alpha, isFill );
		layerColor[138] = new LayerColor( 255, 255,  60, alpha, isFill );
		layerColor[139] = new LayerColor( 255,  50, 255, alpha, isFill );
		layerColor[140] = new LayerColor(  40, 255, 255, alpha, isFill );
		layerColor[141] = new LayerColor(   0,   0, 155, alpha, isFill );
		layerColor[142] = new LayerColor(  30, 255, 255, alpha, isFill );
		layerColor[143] = new LayerColor( 255,  20, 255, alpha, isFill );
		layerColor[144] = new LayerColor( 223, 255, 155, alpha, isFill );
		layerColor[145] = new LayerColor(   0, 255, 255, alpha, isFill );
		layerColor[146] = new LayerColor( 235, 235, 235, alpha, isFill );
		layerColor[147] = new LayerColor( 225, 225, 225, alpha, isFill );
		layerColor[148] = new LayerColor( 215, 222, 255, alpha, isFill );
		layerColor[149] = new LayerColor(  90,  90,  70, alpha, isFill );
		layerColor[150] = new LayerColor( 255, 222, 133, alpha, isFill );
		layerColor[151] = new LayerColor( 255, 160, 167, alpha, isFill );
		layerColor[152] = new LayerColor( 150, 255, 255, alpha, isFill );
		layerColor[153] = new LayerColor( 255, 140, 255, alpha, isFill );
		layerColor[154] = new LayerColor( 255, 255, 130, alpha, isFill );
		layerColor[155] = new LayerColor( 255, 119, 255, alpha, isFill );
		layerColor[156] = new LayerColor( 117, 255, 255, alpha, isFill );
		layerColor[157] = new LayerColor( 116, 255, 115, alpha, isFill );
		layerColor[158] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[159] = new LayerColor( 255, 255, 114, alpha, isFill );
		layerColor[160] = new LayerColor( 112, 255, 255, alpha, isFill );
		layerColor[161] = new LayerColor( 255, 113, 255, alpha, isFill );
		layerColor[162] = new LayerColor( 100,  90,  50, alpha, isFill );
		layerColor[163] = new LayerColor( 111, 255, 123, alpha, isFill );
		layerColor[164] = new LayerColor( 255, 198, 145, alpha, isFill );
		layerColor[165] = new LayerColor( 189, 255, 255, alpha, isFill );
		layerColor[166] = new LayerColor( 255, 137, 255, alpha, isFill );
		layerColor[167] = new LayerColor( 255, 255, 122, alpha, isFill );
		layerColor[168] = new LayerColor( 255, 130, 255, alpha, isFill );
		layerColor[169] = new LayerColor( 255, 145, 255, alpha, isFill );
		layerColor[170] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[171] = new LayerColor( 255, 184, 255, alpha, isFill );
		layerColor[172] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[173] = new LayerColor( 134, 255, 255, alpha, isFill );
		layerColor[174] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[175] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[176] = new LayerColor( 255, 167, 180, alpha, isFill );
		layerColor[177] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[178] = new LayerColor( 134, 143, 255, alpha, isFill );
		layerColor[179] = new LayerColor( 255, 167, 255, alpha, isFill );
		layerColor[180] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[181] = new LayerColor( 255, 234, 255, alpha, isFill );
		layerColor[182] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[183] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[184] = new LayerColor( 255, 200, 255, alpha, isFill );
		layerColor[185] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[186] = new LayerColor( 255, 255, 252, alpha, isFill );
		layerColor[187] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[188] = new LayerColor( 252, 253, 253, alpha, isFill );
		layerColor[189] = new LayerColor(  21, 255, 255, alpha, isFill );
		layerColor[190] = new LayerColor( 255, 251, 255, alpha, isFill );
		layerColor[191] = new LayerColor( 255, 232, 255, alpha, isFill );
		layerColor[192] = new LayerColor( 255, 232, 232, alpha, isFill );
		layerColor[193] = new LayerColor( 232,  85, 255, alpha, isFill );
		layerColor[194] = new LayerColor( 232, 255, 255, alpha, isFill );
		layerColor[195] = new LayerColor( 255,  67, 255, alpha, isFill );
		layerColor[196] = new LayerColor( 255, 255, 255, alpha, isFill );
		layerColor[197] = new LayerColor( 234, 255, 255, alpha, isFill );
		layerColor[198] = new LayerColor( 100, 255, 255, alpha, isFill );
		layerColor[199] = new LayerColor(  91, 255, 255, alpha, isFill );
		layerColor[200] = new LayerColor( 255,  92, 255, alpha, isFill );
		layerColor[201] = new LayerColor( 255, 255,  93, alpha, isFill );
		layerColor[202] = new LayerColor( 255,  94, 255, alpha, isFill );
		layerColor[203] = new LayerColor(  96, 255, 255, alpha, isFill );
		layerColor[204] = new LayerColor( 200, 255, 255, alpha, isFill );
		layerColor[205] = new LayerColor( 170, 255, 170, alpha, isFill );
		layerColor[206] = new LayerColor( 255, 170, 170, alpha, isFill );
		layerColor[207] = new LayerColor( 170, 170, 255, alpha, isFill );
		layerColor[208] = new LayerColor( 170, 255, 255, alpha, isFill );
		layerColor[209] = new LayerColor( 255, 170, 255, alpha, isFill );
		layerColor[210] = new LayerColor( 255, 255, 170, alpha, isFill );
		layerColor[211] = new LayerColor( 100, 255, 100, alpha, isFill );
		layerColor[212] = new LayerColor( 100, 100, 255, alpha, isFill );
		layerColor[213] = new LayerColor( 255, 100, 100, alpha, isFill );
		layerColor[214] = new LayerColor( 255, 255, 100, alpha, isFill );
		layerColor[215] = new LayerColor( 255, 100, 255, alpha, isFill );
		layerColor[216] = new LayerColor( 100, 255, 255, alpha, isFill );
		layerColor[217] = new LayerColor( 200, 255, 200, alpha, isFill );
		layerColor[218] = new LayerColor( 255, 200, 200, alpha, isFill );
		layerColor[219] = new LayerColor( 200, 200, 255, alpha, isFill );
		layerColor[220] = new LayerColor( 200, 255, 255, alpha, isFill );
		layerColor[221] = new LayerColor( 255, 200, 255, alpha, isFill );
		layerColor[222] = new LayerColor( 255, 255, 200, alpha, isFill );
		layerColor[223] = new LayerColor( 155, 255, 155, alpha, isFill );
		layerColor[224] = new LayerColor( 155, 155, 255, alpha, isFill );
		layerColor[225] = new LayerColor( 255, 155, 155, alpha, isFill );
		layerColor[226] = new LayerColor( 255, 255, 155, alpha, isFill );
		layerColor[227] = new LayerColor( 255, 155, 255, alpha, isFill );
		layerColor[228] = new LayerColor( 155, 255, 255, alpha, isFill );
		layerColor[229] = new LayerColor(  75, 255,  75, alpha, isFill );
		layerColor[230] = new LayerColor( 255,  75,  75, alpha, isFill );
		layerColor[231] = new LayerColor(  75,  75, 255, alpha, isFill );
		layerColor[232] = new LayerColor(  75, 255, 255, alpha, isFill );
		layerColor[233] = new LayerColor( 255,  75, 255, alpha, isFill );
		layerColor[234] = new LayerColor( 255, 255,  75, alpha, isFill );
		layerColor[235] = new LayerColor( 255, 255,  55, alpha, isFill );
		layerColor[236] = new LayerColor( 255,  55, 255, alpha, isFill );
		layerColor[237] = new LayerColor(  55, 255, 255, alpha, isFill );
		layerColor[238] = new LayerColor( 155, 255, 255, alpha, isFill );
		layerColor[239] = new LayerColor( 255, 155, 255, alpha, isFill );
		layerColor[240] = new LayerColor( 255, 255, 155, alpha, isFill );
		layerColor[241] = new LayerColor(   0,   0, 255, alpha, isFill );
		layerColor[242] = new LayerColor(  55, 255,  95, alpha, isFill );
		layerColor[243] = new LayerColor(  25, 200,  55, alpha, isFill );
		layerColor[244] = new LayerColor( 255,  65,   5, alpha, isFill );
		layerColor[245] = new LayerColor(  35,  45, 255, alpha, isFill );
		layerColor[246] = new LayerColor(  15, 255, 255, alpha, isFill );
		layerColor[247] = new LayerColor( 255,  25, 255, alpha, isFill );
		layerColor[248] = new LayerColor( 255, 255,  55, alpha, isFill );
		layerColor[249] = new LayerColor( 255, 155, 155, alpha, isFill );
		layerColor[250] = new LayerColor(  55,  55, 255, alpha, isFill );
		layerColor[251] = new LayerColor(  55, 255, 255, alpha, isFill );
		layerColor[252] = new LayerColor( 255, 105, 255, alpha, isFill );
		layerColor[253] = new LayerColor( 255, 255, 200, alpha, isFill );
		layerColor[254] = new LayerColor( 190, 255, 190, alpha, isFill );
		layerColor[255] = new LayerColor( 200, 200, 255, alpha, isFill );
		
	}  // END of setDefaultLayerColor()
	
	
	public static LayerColor getColor( int layerNo ) 
	{
		return( layerColor[layerNo] );
	} 
	
	
	public static boolean getIsFill( int layerNo )
	{
		return( layerColor[layerNo].isFill() );
	}
	
	public static void setFill( int layerNo, boolean fill )
	{
		layerColor[layerNo].setFill( fill );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/20 - initial version
	 */
	public static void setColor( int layerNo, Color newColor, int isFill )
	{
		layerColor[layerNo] = new LayerColor( newColor.getRed(), newColor.getGreen(), newColor.getBlue(), newColor.getAlpha(), isFill );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/20 - initial version
	 */
	/* R, G, B, and Alpha */
	public static void setColorAndAlpha( int layerNo, Color newColor )
	{
		int isFill = 0;
		
		if ( layerColor[layerNo].isFill() == true ) {
			isFill = 1;
		}
		
		layerColor[layerNo] = new LayerColor( newColor.getRed(), newColor.getGreen(), newColor.getBlue(), newColor.getAlpha(), isFill );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/24 - initial version
	 */
	/* ignore Alpha */
	public static void setColorOnly( int layerNo, Color newColor )
	{
		int isFill = 0;
		
		if ( layerColor[layerNo].isFill() == true ) {
			isFill = 1;
		}
		
		int oldAlpha = layerColor[layerNo].getAlpha();
		
		layerColor[layerNo] = new LayerColor( newColor.getRed(), newColor.getGreen(), newColor.getBlue(), oldAlpha, isFill );
	}
	
	
	
	/* Author:  I-Lun Tseng
	 * Hisyory: 2006/11/21 - initial version
	 */
	public static void saveAsColorSettings( PrintStream printStream )
	{
		for ( int i=0; i<=255; i++ )
		{
			printStream.print("\t" + i );							// layer number
			printStream.print("\t" + layerColor[i].getRed() );		// Red
			printStream.print("\t" + layerColor[i].getGreen() );	// Green
			printStream.print("\t" + layerColor[i].getBlue() );		// Blue
			printStream.print("\t" + layerColor[i].getAlpha() );	// Alpha
			
			if ( layerColor[i].isFill() == true ) {					// isFill
				printStream.print("\t" + "1" );		
			}
			else {
				printStream.print("\t" + "0" );
			}
			
			printStream.println();
		}
	}
	
	
}
