/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.beans.PropertyVetoException;
import javax.swing.*;

  
public class DrawLayout extends JComponent implements MouseListener, MouseMotionListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//private Image image;
	private BufferedImage bImage;
	private static int imageWidth; // 	= 1000;
	private static int imageHeight; // 	= 1000;
    private Graphics2D graphics2D;	// new
    
    private static boolean isRedrawImage = false;  // an expensive, time-consuming operation
    private static boolean isZoomFactorChanged = false;
    //private static boolean isMoveImage   = false;
    
    
    private static int imagePosX = 0;  // image position (relative to window coordinate)
    private static int imagePosY = 0;  // image position (relative to window coordinate)
    
    private static int windowWidth;    // window size  
    private static int windowHeight;   // window size 
    
    private static Thread  drawingThread;
    
    private static boolean isDrawingThreadRunning = false;		// shared by threads
    private static boolean isStopDrawingThread = false;			// shared by threads
    
    private static boolean clearImageFlag = false;
    
    private static boolean isCenterSet = false;
    private static Point   centerGDSIIpoint;
    
  
    public DrawLayout() {
    	
    	/* mouse motion listener */
        addMouseMotionListener(this);
        
        /* mouse listener */
    	addMouseListener(this);
    }
  
    
    //public void paint(Graphics g) {
    public void paintComponent(Graphics g) {   // for Swing
    	
    	if ( clearImageFlag ) {
    		Draw.clearImage(graphics2D, imageWidth, imageHeight);
    		PanelCenter.g2D.repaint();
    		clearImageFlag = false;
    	}
    	
        if (!GDSII.isReady()) {        	
        	return;
        }
                
        // Is window size changed ?
        if ( windowWidth!=getSize().width || windowHeight!=getSize().height) {
        	/* if YES, re-create the image */
        	windowWidth  = getSize().width;
        	windowHeight = getSize().height;
        	imageWidth   = (int) (ToolBar.ZoomFactor * getSize().width);
        	imageHeight  = (int) (ToolBar.ZoomFactor * getSize().height);
        	bImage = null; // re-create image
        }
        		
        // Is zoom factor changed ?
        if ( isZoomFactorChanged == true ) {
        	/* if YES, re-create the image with larger size */
        	imageWidth   =  (int) (ToolBar.ZoomFactor * getSize().width);
        	imageHeight  =  (int) (ToolBar.ZoomFactor * getSize().height);
        	PanelHBar.setPosition();
			PanelVBar.setPosition();
        	bImage = null; // re-create image
        	isZoomFactorChanged = false;
        }
    	
        // set imageSize
        SizeSetting.setImageScale( imageWidth , imageHeight );  
        
        if ( bImage == null ) {
        	
        	bImage = new BufferedImage( imageWidth, imageHeight, BufferedImage.TYPE_INT_ARGB );
        	graphics2D = (Graphics2D) bImage.getGraphics();
        	
        	// Antialiasing: can make the lines look thicker
        	graphics2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
        	
        	// Transparancy (No need, I have "color.txt" for transparancy)
        	// AlphaComposite ac = AlphaComposite.getInstance( AlphaComposite.SRC_OVER, (float).70 );
        	// graphics2D.setComposite( ac );
        	
        	isRedrawImage = true;
        	
        	if ( isCenterSet == false ) {
        		//System.out.println("Window center: " + windowWidth/2 + ", " + windowHeight/2 );
        		
        		centerGDSIIpoint = new Point( SizeSetting.trans_GDSII_X(windowWidth/2) , SizeSetting.trans_GDSII_Y(windowHeight/2) );
        		isCenterSet = true;
        		
        		//System.out.println( "GDSII center: " + centerGDSIIpoint.getX() + ", " + centerGDSIIpoint.getY() );
        	}
        }
                    
        /* Generate the off-screen image of the layout */
        if ( isRedrawImage == true) {
        	
        	if ( DrawLayout.isDrawingThreadRunning() == true ) {
        		/* critical section - start */
				stopAndWaitForTheDrawingThread();
				/* critical section - end */
        	}
        	drawingThread = new Thread() {
        		public void run() {
        			runDrawingThread();		// draw layout on the off-screen image
        		}
        	};
        	drawingThread.setDaemon(true); /* Kill the thread if the application finishes. */
        	drawingThread.start();
        }
                   
        /* Draw the off-screen image (buffered image) on the screen */
        g.drawImage( bImage, imagePosX, imagePosY, null );  
        //System.out.println("imagePos: " + imagePosX + ", " + imagePosY );
        
        /* Draw the origin point */
        DrawOriginPoint.draw( g );
        
        /* Draw the grid points */
        /* ToDo; has bugs (program hangs) */
        DrawGrids.draw( g, windowWidth, windowHeight );
        
        /* Draw the ruler */
        DrawRuler.draw( g );
    }
    

    /* critical section */
    /* The method is used to speed up the return of the old thread */
    private synchronized void stopAndWaitForTheDrawingThread() {
		//drawingThread.stop(); -- deprecated
    	
    	DrawLayout.setIsStopDrawingThread( true );
    	
    	try {		
    		drawingThread.join(10);  // wait for the thread to finish	
    	} catch (InterruptedException e) {		
    		e.printStackTrace();	
    	}
    	DrawLayout.setIsStopDrawingThread( false );
    }
    
    
    /* will cause deadlock if I use "synchronized" */
    private void runDrawingThread() 
    {
    	DrawLayout.setIsDrawingThreadRunning( true );
		PanelStatusBar.progressBarIndeterminate(true, "Drawing");
		Draw.clearImage(graphics2D, imageWidth, imageHeight);
		
		/* draw the layout on the buffered image, an expensive step */
		Draw.displayLayout( graphics2D, true );  
		
    	if ( DrawLayout.isStopDrawingThread() == true ) {
    		/* related to the control of drawingThread */
    		/* should not repaint ! */
    		//Draw.debugThread();
    		return;
    	}
		isRedrawImage = false;
		PanelStatusBar.progressBarIndeterminate(false,"");
		PanelCenter.g2D.repaint();		// Redraw the layout. It's ready.
		
		DrawLayout.setIsDrawingThreadRunning( false );    	
    }
    
    
    public static void isRedrawImage( boolean value) {
    	isRedrawImage = value;
    }    
    
    public static int getImageWidth() {
    	return( imageWidth );
    }
    
    public static int getImageHeight() {
    	return( imageHeight );
    }    
    
    public static void setImagePositionX( int x) {
    	imagePosX = x;
    }
    
    public static void setImagePositionY( int y) {
    	imagePosY = y;
    }
    
    public static int getImagePositionX() {
    	return( imagePosX );
    }
    
    public static int getImagePositionY() {
    	return( imagePosY );
    }
    
    public static void isZoomFactorChanged( boolean value) {
    	isZoomFactorChanged = value;
    } 

    
    // MouseListener
	public void mouseClicked(MouseEvent arg0) {
		//System.out.println("mouseClicked");
		
	}

	// MouseListener
	public void mousePressed(MouseEvent e) {
		//System.out.println( "mousePressed: " + e.getX() + ", " + e.getY() );
		if (Ruler.isExist()) {		
			Ruler.setStartPoint( SizeSetting.trans_GDSII_X(e.getX()), 
				                 SizeSetting.trans_GDSII_Y(e.getY()) );
		}		
	}

	// MouseListener
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	// MouseListener
	public void mouseEntered(MouseEvent arg0) {
	
		//System.out.println("mouseEntered");
		
		try {
			// set the focus to the InternalFrame-01
			MainClass.intFrame01.setSelected(true);
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	// MouseListener
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	// MouseMotionListener
    public void mouseMoved(MouseEvent e) {
    	//System.out.println("mouseMoved");
    	
    	/* show coordinates */
   		PanelStatusBar.showCoord( e.getX(), e.getY() );
    }
    
	// MouseMotionListener
	public void mouseDragged(MouseEvent e) {
    	//System.out.println("mouseDragged");
		
		/* show coordinates */
		PanelStatusBar.showCoord( e.getX(), e.getY() );
		
		/* Ruler */
		if (Ruler.isExist()) {
			Ruler.setEndPoint( SizeSetting.trans_GDSII_X(e.getX()), 
					           SizeSetting.trans_GDSII_Y(e.getY()) );
			PanelCenter.g2D.repaint();
		}		
    }
	
	public static void clearDisplay() {
		clearImageFlag = true;
	}
	
	public static int getCenterGDSIIpointX() {
		return( (int)centerGDSIIpoint.getX() );
	}
	
	public static int getCenterGDSIIpointY() {
		return( (int)centerGDSIIpoint.getY() );
	}
	
	public static int getWindowWidth() {
		return( windowWidth );
	}
	
	public static int getWindowHeight() {
		return( windowHeight );
	}
	
	public static void renewImageSize() {
		imageWidth   =  (int) (ToolBar.ZoomFactor * windowWidth);
    	imageHeight  =  (int) (ToolBar.ZoomFactor * windowHeight);
    	SizeSetting.setImageScale( imageWidth , imageHeight );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11 - initial version
	 */
	public synchronized static boolean isDrawingThreadRunning()
	{
		return( isDrawingThreadRunning );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11 - initial version
	 */
	public synchronized static void setIsDrawingThreadRunning( boolean yesno ) 
	{
		isDrawingThreadRunning = yesno;
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11 - initial version
	 */
	public synchronized static boolean isStopDrawingThread()
	{
		return( isStopDrawingThread );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/11 - initial version
	 */
	public synchronized static void setIsStopDrawingThread( boolean yesno ) 
	{
		isStopDrawingThread = yesno;
	}
	
	
}

