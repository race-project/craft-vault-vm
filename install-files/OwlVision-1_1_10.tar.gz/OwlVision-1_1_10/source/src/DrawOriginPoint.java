/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.Line2D;

public class DrawOriginPoint {
	
	private static boolean isDraw;
	
	public static void draw(Graphics g) {    
		
		if (isDraw==false) {
			return;
		}
		
    	Graphics2D graph2d = (Graphics2D) g;    	
    	graph2d.setPaint( Color.white );
    	graph2d.setStroke(new BasicStroke((float)1));
    	
    	int originX = SizeSetting.transGDS2Window_X_int(0);
    	int originY = SizeSetting.transGDS2Window_Y_int(0);
    	
    	Shape lineV = new Line2D.Double( 
    			originX,
    			originY+7,
    			originX,
    			originY-7  );
    	graph2d.draw(lineV);
    	
    	Shape lineH = new Line2D.Double( 
    			originX-7,
    			originY,
    			originX+7,
    			originY  );
    	graph2d.draw(lineH);
    	
    	Polygon p = new Polygon();
    	p.addPoint( originX-2, originY-2 );
    	p.addPoint( originX-2, originY+2 );
    	p.addPoint( originX+2, originY+2 );
    	p.addPoint( originX+2, originY-2 );
    	graph2d.draw(p);
    }
    
	public static void setState(boolean state) {
		isDraw = state;
	}
	
	public static boolean getState() {
		return( isDraw );
	}
	

}
