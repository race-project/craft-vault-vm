/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;



/*
 * 
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class DrawPath {
	
	/* Draw the contour of a PATH element. */
	/* 2005/12/06 */
	public static void drawPath( Graphics2D 		graphics2D,
							     DSxyList   		xyList,
							     int        		width,
							     DSorientationStack	oStack,
							     int 				layerNo,
							     boolean			isOnScreen )
	{
		Point [] point = new Point [xyList.getNumber()*2];
		
		//System.out.println();
		
		int x0=0, y0=0;  /* previous node */
		int x1=0, y1=0;  /* current node */
		int x2=0, y2=0;  /* next node */
		int numOfPoints = xyList.getNumber();
		
		double w = width/2;
		
		int i;
		DSxyNode xyNode;
		/* all of the nodes in the path */
		for ( i=0, xyNode = xyList.getHead(); 
		      i< xyList.getNumber(); 
		      i++, xyNode = xyNode.getNext() ) 
		{
			//System.out.println("i = " + i );
			
			x1 = xyNode.getX();  /* current node */
			y1 = xyNode.getY();	 /* current node */		 
			if ( xyNode.getNext()!=null) {
				x2 = xyNode.getNext().getX(); /* next node */
				y2 = xyNode.getNext().getY(); /* next node */	
			}
						
			/* THE FIRST POINT */
			if (i==0) {
				/* vertical edge */
				if ( x1==x2 ) {
		            /* up */
		            if (y1<=y2) {
		            	point[i] = new Point( (int)(x1-w), y1);
		            	point[2*numOfPoints-i-1] = new Point( (int)(x1+w), y1 );		            	
		            }
		            /* down */
		            else {
		            	point[i] = new Point( (int)(x1+w), y1);
		            	point[2*numOfPoints-i-1] = new Point( (int)(x1-w), y1 );
		            }					
				}
				/* horizontal edge */
				else if ( y1==y2 ) {
					/* to the right */
					if (x1<=x2) {
						point[i] = new Point( x1, (int)(y1+w) );
						point[2*numOfPoints-i-1] = new Point( x1, (int)(y1-w) );						
					}
					/* to the left */
					else {
						point[i] = new Point( x1, (int)(y1-w) );
						point[2*numOfPoints-i-1] = new Point( x1, (int)(y1+w) );
					}
				}
				/* non-Manhattan edge */
				else {
					double m1 = ((double)y1-(double)y2)/((double)x1-(double)x2);
		        	double m2 = (-1)/m1;
		        	double a1 = (-1)*w/(Math.sqrt(1+Math.pow(m2,2)));
		        	double a2 = m2*a1;
		        	double b1 = (-1)*a1;
		        	double b2 = m2*b1;
		        	/* up */
		        	if (y1<=y2) {
		        		if (a1<=b1) {
		        			point[i] = new Point((int)(a1+x1),(int)(a2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
		        		}
		        		else {
		        			point[i] = new Point((int)(b1+x1),(int)(b2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));		        			
		        		}
		        	}
		        	/* down */
		        	else {
		        		if (a1<=b1) {
		        			point[i] = new Point((int)(b1+x1),(int)(b2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));		        					        			
		        		}
		        		else {
		        			point[i] = new Point((int)(a1+x1),(int)(a2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
		        		}
		        	}
				}
			}
			/* THE LAST POINT */
			else if (i==xyList.getNumber()-1) {
				
				/* vertical edge */
				if ( x0==x1 ) {
		            /* up */
		            if (y0<=y1) {
		            	point[i] = new Point( (int)(x1-w), y1);
		            	point[2*numOfPoints-i-1] = new Point((int)(x1+w),y1);
		            }
		            /* down */
		            else {
		            	point[i] = new Point((int)(x1+w), y1);
		            	point[2*numOfPoints-i-1] = new Point((int)(x1-w),y1);
		            }					
				}
				/* horizontal edge */
				else if ( y0==y1 ) {
					/* to the right */
					if (x0<=x1) {
						point[i] = new Point(x1,(int)(y1+w));
						point[2*numOfPoints-i-1] = new Point(x1,(int)(y1-w));
					}
					/* to the left */
					else {
						point[i] = new Point(x1,(int)(y1-w));
						point[2*numOfPoints-i-1] = new Point(x1,(int)(y1+w));
					}
				}
				/* non-Manhattan edge */
				else {
					double m1 = ((double)y0-(double)y1)/((double)x0-(double)x1);
		        	double m2 = (-1)/m1;
		        	double a1 = (-1)*w/(Math.sqrt(1+Math.pow(m2,2)));
		        	double a2 = m2*a1;
		        	double b1 = (-1)*a1;
		        	double b2 = m2*b1;
		        	/* up */
		        	if (y0<=y1) {
		        		if (a1<=b1) {
		        			point[i] = new Point((int)(a1+x1),(int)(a2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
		        		}
		        		else {		        			
		        			point[i] = new Point((int)(b1+x1),(int)(b2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));
		        		}
		        	}
		        	/* down */
		        	else {
		        		if (a1<=b1) {
		        			point[i] = new Point((int)(b1+x1),(int)(b2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));
		        		}
		        		else {
		        			point[i] = new Point((int)(a1+x1),(int)(a2+y1));
		        			point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
		        			
		        		}
		        	}
				}
				
			}
			/* MIDDLE POINTS */
			else {
				double m01 = ((double)y0-(double)y1)/((double)x0-(double)x1);
				//double m12 = ((double)y1-(double)y2)/((double)x1-(double)x2);
				
				double x00 = x0 - x1;
				double y00 = y0 - y1;
				double x20 = x2 - x1;
				double y20 = y2 - y1;
				double m01p;
				double px;
				double py;
				
				if (m01==0) {  /* special case */
					m01p  = (-1)/m01;  /* Infinity: not used */
					px = 0;
					py = w;
				}
				else {  /* normal case */
					m01p  = (-1)/m01;
					px = w/(Math.sqrt(1+Math.pow(m01p,2)));
					py = px*m01p;	
				}
				
				
				double a = 100000/( Math.sqrt(Math.pow(x00,2)+ Math.pow(y00,2)) );
				double b = 100000/( Math.sqrt(Math.pow(x20,2)+ Math.pow(y20,2)) );
				double m_1 = (a*y00-b*y20)/(a*x00-b*x20);
				
				/* special case: (m_1==Infinity) */
				if (a*x00==b*x20) {
					double s1 = px + py*py/px;
					//double s2 = 0;
					/* up */
					if (y1<y2) {
						if (s1>0) {
							point[i] = new Point((int)(-s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(s1+x1),(int)(0+y1));
						}
						else {
							point[i] = new Point((int)(s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(-s1+x1),(int)(0+y1));
						}
						
					}
					/* down */
					else {  /* y1>y2 */
						if (s1>0) {
							point[i] = new Point((int)(s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(-s1+x1),(int)(0+y1));
						}
						else {
							point[i] = new Point((int)(-s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(s1+x1),(int)(0+y1));							
						}
						
					}
					
				}
				/* special case: (m_1==0) */
				else if (a*y00==b*y20) {
					//System.out.println("Special Case: m_1==0");;
					//double s1 = 0;
					//double s2 = px + py*py/px;
					double s2 = py + px*px/py;
					/* to the right */
					if (x1<x2) {
						if (s2>0) {
							point[i] = new Point((int)(0+x1),(int)(s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(-s2+y1));
						}
						else {
							point[i] = new Point((int)(0+x1),(int)(-s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(s2+y1));						
						}
					}
					/* to the left */
					else {
						if (s2>0) {
							point[i] = new Point((int)(0+x1),(int)(-s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(s2+y1));
						}
						else {
							point[i] = new Point((int)(0+x1),(int)(s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(-s2+y1));						
						}
					}
				}
				/* normal case */
				else {
					double m_2 = (-1)/m_1;
					/*
					 double m01p  = (-1)/m01;
					 double px = w/(Math.sqrt(1+Math.pow(m01p,2)));
					 double py = px*m01p;
					 */
					double s1 = (px*px+py*py)/(px+py*m_2);
					double s2 = s1*m_2;
					double qx;
					double qy;
					
					if (m01==0) {
						qx = 0;
						qy = -w;
					}
					else {
						qx = -px;
						qy = qx*m01p;
					}
					
					double t1 = (qx*qx+qy*qy)/(qx+qy*m_2);
					double t2 = t1*m_2;
					
					if ( Geometry.isTurnLeft( x0,y0,x1,y1,(int)(s1+x1),(int)(s2+y1)) ) {
						point[i] = new Point((int)(s1+x1),(int)(s2+y1));
						point[2*numOfPoints-i-1] = new Point((int)(t1+x1),(int)(t2+y1));
					}
					else {						
						point[i] = new Point((int)(t1+x1),(int)(t2+y1));
						point[2*numOfPoints-i-1] = new Point((int)(s1+x1),(int)(s2+y1));
					}
				
				}  /* END of normal case */
				
			  }  /* END of MIDDLE POINTS */
			
			x0 = x1;  /* set previous node */
			y0 = y1;  /* set previous node */		
		}
		 
		//Point pnt;
		Polygon poly = new Polygon();
		//int rotatedX1, rotatedY1; 
		
		for ( i = 0; i< numOfPoints*2; i++ ) 
		{
			/* calculate orientation */
			Point oPoint = DSbuild.calculateOrientation( (int)point[i].getX(), (int)point[i].getY(), oStack );
			
    		//pnt = DSbuild.rotate( (int)point[i].getX(), (int)point[i].getY(), angle);
    		//rotatedX1 = (int) pnt.getX();
            //rotatedY1 = (int) pnt.getY();
            
			if ( isOnScreen == true ) 
			{	/* draw on screen */
				poly.addPoint( (int) SizeSetting.trans_X( (int) oPoint.getX() ), 
				           	   (int) SizeSetting.trans_Y( (int) oPoint.getY() ) );
			}
			else 
			{
				poly.addPoint( (int) SizeSetting2.trans_X( (int) oPoint.getX() ), 
			           	   	   (int) SizeSetting2.trans_Y( (int) oPoint.getY() ) );
			}
		}
		
		
		if ( DrawColor.getIsFill( layerNo ) == true ) {
    		graphics2D.fill( poly ); // fill the interior of the polygon
    	}
		
		graphics2D.draw( poly );
		
	}
    

}
