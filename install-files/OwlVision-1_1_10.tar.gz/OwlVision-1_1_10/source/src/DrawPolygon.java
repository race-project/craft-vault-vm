/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Graphics2D;
import java.awt.Polygon;

public class DrawPolygon {

	public static void draw( Graphics2D graphics2D, 
			                 int[] xList, int[] yList, 
			                 int numPoints,
			                 int layerNo,
			                 boolean isOnScreen ) 
	{	
    	Polygon p = new Polygon();
    	
    	for ( int i=0; i<numPoints; i++ ) 
    	{
    		if ( isOnScreen == true ) 
    		{	/* draw on the screen */
    			p.addPoint( (int) SizeSetting.trans_X( xList[i] ), 
    				        (int) SizeSetting.trans_Y( yList[i] ) );
    		}
    		else 
    		{	/* JPG or GIF */
    			p.addPoint( (int) SizeSetting2.trans_X( xList[i] ), 
				            (int) SizeSetting2.trans_Y( yList[i] ) );
    		}
    	}
    	
    	if ( DrawColor.getIsFill( layerNo ) == true ) {
    		graphics2D.fill(p); // fill the interior of the polygon
    	}
    	
    	graphics2D.draw(p);  // draw the outline of the polygon
    	
    }

}
