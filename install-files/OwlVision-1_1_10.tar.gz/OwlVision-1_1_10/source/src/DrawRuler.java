/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Line2D;

public class DrawRuler {
	
	private static double slope;
	private static double slopeV;
	

	public static void draw( Graphics g ) {
    	
    	if (Ruler.isExist()==false) {
    		return;    
    	}
    	if ( Ruler.getX1()==Ruler.getX2() && Ruler.getY1()==Ruler.getY2() ) {
    		return;
    	}
    	
    	Graphics2D graph2d = (Graphics2D) g;
    	
    	graph2d.setPaint( Color.white );
    	//graph2d.setPaint( new Color(255,255,255,190) );  
    	graph2d.setStroke(new BasicStroke((float)1));
    	
    	int startX = SizeSetting.transGDS2Window_X_int( Ruler.getX1() );
    	int startY = SizeSetting.transGDS2Window_Y_int( Ruler.getY1() );
    	int endX   = SizeSetting.transGDS2Window_X_int( Ruler.getX2() );
    	int endY   = SizeSetting.transGDS2Window_Y_int( Ruler.getY2() );
    	    	
    	Shape line = new Line2D.Double( startX, startY, endX, endY );
    	graph2d.draw( line );  // draw the line
    	    	
    	//graph2d.drawString("0", startX, startY-4);
    	//double length = Math.sqrt( Math.pow(Ruler.getX1()-Ruler.getX2(), 2) + Math.pow(Ruler.getY1()-Ruler.getY2(), 2) ); 
    	//graph2d.drawString( ""+(int)length, endX, endY-4);
    	
    	calculateSlope(startX, startY, endX, endY);
    	displayScales(graph2d, startX, startY, endX, endY);
    	
    }
	
	private static void calculateSlope(int startX, int startY, 
			                           int endX,   int endY) {
		double x1 = startX;
		double y1 = startY;
		double x2 = endX;
		double y2 = endY;
		
		slope  = (y2-y1)/(x2-x1);
		slopeV = ((double)-1)/slope; 
		
		//System.out.println( slope + " -- " + slopeV );
	}
	
	/* parameters of the method are all in window coordinates */
	private static void displayScales( Graphics2D graphics2D,
			double startX, double startY, double endX, double endY) 
	{		
		/* ruler's start point */
		drawScale(graphics2D, startX, startY, startX, startY, endX, endY, slopeV, true);
		
		/* ruler's middle points */
		if (startX < endX) {
			double theta = Math.atan(slope);
			
			//System.out.println("theta: " + theta*180/Math.PI);
			
			/* windowGridSize is not accurate enough */
			double stepSize = DrawGrids.getWindowGridSizeDouble() * Math.cos(theta) ; 
			for ( double x = stepSize ;
			   	  (x+startX) < endX && stepSize!=0;
			   	  x += stepSize ) 
			{
				double y = slope*x;
				drawScale(graphics2D, (x+startX), (y+startY), startX, startY, endX, endY, slopeV, false);
				//System.out.println(" xy: " + x+ ", " + y);
			}			
		}
		else if (startX > endX) {
			double theta = Math.atan(slope);
			
			//System.out.println("theta: " + theta*180/Math.PI);
			
			double stepSize = DrawGrids.getWindowGridSizeDouble() * Math.cos(theta) ;  /* stepSize > 0*/
			//System.out.println("stepSize: " + stepSize );			
			for ( double x = (-1)*stepSize ;
			   	  (x+startX) > endX && stepSize!=0;
			   	  x -= stepSize ) 
			{
				double y = slope*x;
				drawScale(graphics2D, (x+startX), (y+startY), startX, startY, endX, endY, slopeV, false);
				//System.out.println(" xy: " + x+ ", " + y);
			}			
		}
		else if (startX==endX && startY<endY) {			
			
			double stepSize = DrawGrids.getWindowGridSizeDouble();  /* stepSize > 0*/
			//System.out.println("stepSize: " + stepSize );			
			for ( double y = stepSize ;
			   	  (y+startY) < endY && stepSize!=0;
			   	  y += stepSize ) 
			{
				drawScale(graphics2D, startX, (y+startY), startX, startY, endX, endY, slopeV, false);
				//System.out.println(" xy: " + x+ ", " + y);
			}			
		}
		else if (startX==endX && startY>endY) {			
			
			double stepSize = DrawGrids.getWindowGridSizeDouble();  /* stepSize > 0*/
			//System.out.println("stepSize: " + stepSize );			
			for ( double y = (-1)*stepSize ;
			   	  (y+startY) > endY && stepSize!=0;
			   	  y -= stepSize ) 
			{
				drawScale(graphics2D, startX, (y+startY), startX, startY, endX, endY, slopeV, false);
				//System.out.println(" xy: " + x+ ", " + y);
			}			
		}
    	
    	/* ruler's end point */
    	drawScale(graphics2D, endX, endY, startX, startY, endX, endY, slopeV, true);		
	}
	
	
	/* parameters of the method are all in window coordinates */
	private static void drawScale( 	Graphics2D graphics2D,
									double x, 		double y,
									double startX, 	double startY, 
									double endX,   	double endY, 
									double m,
									boolean isDisplayUnit ) 
	{
		int scaleLength = 12;
		int scaleStringPos = 19;		
		Point p, p2;
		Shape line;
		int scalePosX;
    	int scalePosY;
		
		p = getPoint( x, y, m, scaleLength);		
		//if ( p==null )
		//return;    	
    	line = new Line2D.Double( x, y, p.getX(), p.getY());
    	graphics2D.draw( line );  // draw the line
    	
    	/* scale number */
    	double lengthWindow = Math.sqrt( Math.pow(x-startX, 2) + Math.pow(y-startY, 2) );    	
    	double lengthGDSII = SizeSetting.trans_GDSII_X( (int)lengthWindow) - SizeSetting.trans_GDSII_X( (int)0 ); 
    	double lengthPhysical = lengthGDSII*1000000*SizeSetting.getPhysUnit();
    	String lengthPhysicalStr = "" + lengthPhysical;
    	int dotPosition = lengthPhysicalStr.indexOf(".");
    	//System.out.println("==>" + dotPosition);
    	if ( lengthPhysicalStr.length() > dotPosition+3 ) {
    		//System.out.println("too long");
    		lengthPhysicalStr = lengthPhysicalStr.substring(0,dotPosition+3);
    	}
    	
    	if (isDisplayUnit==false) {
    		return;
    	}
    	
    	/* calculate scale string */
    	
    	String lengthStr;
    	if ( lengthPhysicalStr.equals("0.0")) {
    		lengthStr = "0";
    	}
    	else {
    		lengthStr = "" + lengthPhysicalStr + "u";
    		//lengthStr = "" + lengthPhysicalStr;
    	}
    	//lengthStr = "" + (int)lengthWindow;
    	//lengthStr = "" + (int)lengthGDSII;
    	//lengthStr = "" + lengthPhysical;
    	
    	
    	/* calculate scale string position */
    	p2 = getPoint( x, y, m, scaleStringPos);
    	
    	
    	/* string length */
    	/*
    	if ( lengthStr.length() == 1) {
    		scalePosX = (int) (p2.getX()-3);
    	}
    	else if ( lengthStr.length() == 2 ) {
    		scalePosX = (int) (p2.getX()-6);
    	}
    	else if ( lengthStr.length() == 3 ) {
    		scalePosX = (int) (p2.getX()-10);
    	}
    	else {
    		scalePosX = (int) (p2.getX()-5);
    	} */
    	scalePosX = (int) (p2.getX());    	
    	scalePosY = (int) (p2.getY());
    	graphics2D.drawString( lengthStr, scalePosX, scalePosY );
		
	}
	
	
	/**  Return: (x3,y3)
	 *             / 
	 *            /
	 *  slope=m  /
	 *          /    ==> length
	 *         /
	 *        /
	 *    (x1,y1)
	 *    
	 *    Return the coordinate of the point which has 
	 *    slope "m" and the length as specified.
	 */
	private static Point getPoint(
			double x1, double y1,
			double m, double length ) 
	{
		//System.out.println("m= " + m);
		
		if (m==-0.0) {
			return( new Point( (int)(x1+length), (int)y1) );
		}
		else if ( m==Double.POSITIVE_INFINITY ) {
			//System.out.println("POSITIVE_INFINITY");
			return( new Point( (int)x1, (int)(y1-length)) );
		}
		else if ( m==Double.NEGATIVE_INFINITY ) {
			//System.out.println("NEGATIVE_INFINITY");
			return( new Point( (int)x1, (int)(y1-length)) );			
		}
		else {  /* normal case */
			
			/*
			 * We assume the start point is (0,0) and then add the
			 * coordinate back in the end.
			 */
			double x3_square = (Math.pow(length,2)) / (1+Math.pow(m,2));
			double x3 = Math.sqrt(x3_square);
			double y3 = x3*m;
			
			if (y3>0) {
				x3 = -x3;
				y3 = -y3;
			}
			
			x3 += x1;
			y3 += y1;
			
			return( new Point( (int)x3, (int)y3) );
		}	
	}


}
