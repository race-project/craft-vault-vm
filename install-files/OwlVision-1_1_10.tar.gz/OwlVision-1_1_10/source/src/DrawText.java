/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;

/*
 * Created on 6/12/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author iltseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DrawText {
	
	public static void draw(
							Graphics2D 	graphics2D, 
							int 		pntX, 
							int 		pntY, 
							DStextNode	textNode,
							boolean 	isOnScreen ) 
	{
		String string = textNode.getString();
		double angle  = textNode.getAngle();
		boolean reflection = false;
		
		if ( textNode.getStrans() != null ) {
			reflection = textNode.getStrans().getBit0();
		}
		
		double angleRAD = Math.PI * angle / 180;
		
		//System.out.println("Angle: " + angle + "\t" + "RAD: " + angleRAD );
			
		/* string's Magnification Factor */
		//System.out.println( "PhysUnit: " + SizeSetting.getPhysUnit() );
		//System.out.println( "UserUnit: " + SizeSetting.getUserUnit() );
		//System.out.println( "micrometer: " + SizeSetting.getPhysUnit()/SizeSetting.getUserUnit() );
		double compensateMag = 1.5;		/* Is this correct? The GDSII spec is not clear. */
		double lengthGDSII 	= textNode.getMag() / SizeSetting.getUserUnit();
		double lengthWindow	= lengthGDSII / SizeSetting.getScale() * compensateMag;  /* Is this correct? The GDSII spec is not clear. */
			
		int strLen = string.length();
		//double strLenWindow = strLen * lengthWindow;
		//double strLenGDSII  = strLenWindow * SizeSetting.getScale() / 1.5 ;
		double strLenGDSII = strLen * textNode.getMag() / SizeSetting.getUserUnit(); // * compensateMag;
		
		int coordX;
		int coordY;
		
		/* ToDo: how to calculate string length in pixel? */
		coordX = (int) SizeSetting.trans_X( pntX,isOnScreen);
		coordY = (int) SizeSetting.trans_Y( pntY,isOnScreen);
		
		Font font = new Font( null, Font.PLAIN, (int)lengthWindow );
		graphics2D.setFont( font );
		
		FontRenderContext frc = graphics2D.getFontRenderContext();
		float stringRenderWidth = (float)font.getStringBounds( string, frc ).getWidth();
		float stringRenderHeight = (float)font.getStringBounds( string, frc ).getHeight();
		
		double stringRenderWidthGDSII  = stringRenderWidth * SizeSetting.getScale();
		double stringRenderHeightGDSII = stringRenderHeight * SizeSetting.getScale(); 
		
		coordX = (int) SizeSetting.trans_X( pntX, isOnScreen );
		coordY = (int) SizeSetting.trans_Y( pntY, isOnScreen );
		
		int bits_12_13 = 1;		/* vertical justification - middle (Use as default) */
		int bits_14_15 = 1;		/* horizontal justification - center (Use as default) */
		
		if ( textNode.getPresentation() != null ) {
			bits_12_13 = textNode.getPresentation().getBits_12_13();
			bits_14_15 = textNode.getPresentation().getBits_14_15();
		}
		
		if ( angle == 0 ) 
		{
			if ( (reflection==false && bits_12_13 == 0) ||
				 (reflection==true  && bits_12_13 == 2) ) 
			{  
				/* vertical justification - top */
				coordY = (int) SizeSetting.trans_Y( pntY-((int)(stringRenderHeightGDSII)), isOnScreen);
			}
			else if ( bits_12_13 == 1 ) {	
				/* vertical justification - middle */
				coordY = (int) SizeSetting.trans_Y( pntY-((int)(stringRenderHeightGDSII/2)), isOnScreen);
			}
			
			if ( bits_14_15 == 1 ) {  
				/* horizontal justification - center */
				coordX = (int) SizeSetting.trans_X( pntX-((int)(stringRenderWidthGDSII/2)), isOnScreen);
			}
			else if ( bits_14_15 == 2 ) {	
				/* horizontal justification - right */
				coordX = (int) SizeSetting.trans_X( pntX-((int)(stringRenderWidthGDSII)), isOnScreen);
			}
		}	// END of angle==0
		else if ( angle == 180 ) 
		{
			if ( (reflection==false && bits_12_13 == 0) ||
				 (reflection==true  && bits_12_13 == 2) ) 
			{  
				/* vertical justification - top */
				coordY = (int) SizeSetting.trans_Y( pntY+((int)(stringRenderHeightGDSII)), isOnScreen);
			}
			else if ( bits_12_13 == 1 ) {	
				/* vertical justification - middle */
				coordY = (int) SizeSetting.trans_Y( pntY+((int)(stringRenderHeightGDSII/2)), isOnScreen);
			}
			
			if ( bits_14_15 == 1 ) {  
				/* horizontal justification - center */
				coordX = (int) SizeSetting.trans_X( pntX+((int)(stringRenderWidthGDSII/2)), isOnScreen);
			}
			else if ( bits_14_15 == 2 ) {	
				/* horizontal justification - right */
				coordX = (int) SizeSetting.trans_X( pntX+((int)(stringRenderWidthGDSII)), isOnScreen);
			}
		}
		else if ( angle == 90 )
		{
			if ( (reflection==false && bits_12_13 == 0) ||
				 (reflection==true  && bits_12_13 == 2) ) 
			{  
				/* vertical justification - top */
				coordX = (int) SizeSetting.trans_X( pntX+((int)(stringRenderHeightGDSII)), isOnScreen);
			}
			else if ( bits_12_13 == 1 ) {	
				/* vertical justification - middle */
				coordX = (int) SizeSetting.trans_X( pntX+((int)(stringRenderHeightGDSII/2)), isOnScreen);
			}
				
			if ( bits_14_15 == 1 ) {  
				/* horizontal justification - center */					
				coordY = (int) SizeSetting.trans_Y( pntY-((int)(stringRenderWidthGDSII/2)), isOnScreen);
			}
			else if ( bits_14_15 == 2 ) {	
				/* horizontal justification - right */					
				coordY = (int) SizeSetting.trans_Y( pntY-((int)(stringRenderWidthGDSII)), isOnScreen);
			}			
		}
		else if ( angle == 270 )
		{
			if ( (reflection==false && bits_12_13 == 0) ||
				 (reflection==true  && bits_12_13 == 2) )
			{  
				/* vertical justification - top */
				coordX = (int) SizeSetting.trans_X( pntX-((int)(stringRenderHeightGDSII)), isOnScreen);
			}
			else if ( bits_12_13 == 1 ) {	
				/* vertical justification - middle */
				coordX = (int) SizeSetting.trans_X( pntX-((int)(stringRenderHeightGDSII/2)), isOnScreen);
			}
					
			if ( bits_14_15 == 1 ) {  
				/* horizontal justification - center */					
				coordY = (int) SizeSetting.trans_Y( pntY+((int)(stringRenderWidthGDSII/2)), isOnScreen);
			}
			else if ( bits_14_15 == 2 ) {	
				/* horizontal justification - right */					
				coordY = (int) SizeSetting.trans_Y( pntY+((int)(stringRenderWidthGDSII)), isOnScreen);
			}
		}
		
			
		graphics2D.translate( coordX, coordY );			
		graphics2D.rotate( (-1)*angleRAD );
		//graphics2D.scale( 2, 2 );
		
			
		/* draw the string*/
		graphics2D.drawString( string, 0, 0 );
			
		//graphics2D.scale( 0.5, 0.5 );
		graphics2D.rotate( angleRAD );
		graphics2D.translate( (-1)*coordX, (-1)*coordY );
		
	}
	
	
}
