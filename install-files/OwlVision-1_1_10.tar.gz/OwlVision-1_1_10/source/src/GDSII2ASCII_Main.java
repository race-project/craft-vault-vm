/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/* modified from GDSII_to_ASCII-->GDSII_read(main entry) */

import java.io.*;


public class GDSII2ASCII_Main {
	
	public static GDSII2ASCII_Read gdsii;

	public GDSII2ASCII_Main( String inputFileName, String outputFileName ) {
				
		// System.out.println("Program starts...");
		
		File outputFile = new File(outputFileName);
		FileOutputStream outputFileStream;
		BufferedOutputStream outputFileStream_b;
		PrintStream printStream = null;
		try {
			outputFileStream = new FileOutputStream(outputFile);
			outputFileStream_b = new BufferedOutputStream(outputFileStream, 1048576);
			//printStream = new PrintStream(outputFileStream);
			printStream = new PrintStream(outputFileStream_b);
			GDSII2ASCII_Translate.setPrintStream( printStream );
		} catch (FileNotFoundException e) {
			// CANNOT WRITE TO THE FILE
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//printStream.println("Hello\n");
		
		gdsii = new GDSII2ASCII_Read( inputFileName );
		
		while (GDSII2ASCII_Read.read_record() != 0) {
			
			switch (GDSII2ASCII_Read.dataInt) {
				case 0x0000:
					/* ignore */
					break;
				case 0x0002:
					GDSII2ASCII_Translate.HEADER(gdsii);
					break;
				case 0x0102:
					GDSII2ASCII_Translate.BGNLIB(gdsii);
					break;
				case 0x0206:
					GDSII2ASCII_Translate.LIBNAME(gdsii);
					break;
				case 0x0305:
					GDSII2ASCII_Translate.UNITS(gdsii);
					break;
				case 0x0400:
					GDSII2ASCII_Translate.ENDLIB(gdsii);
					break;
				case 0x0502:
					GDSII2ASCII_Translate.BGNSTR(gdsii);
					break;
				case 0x0606:
					GDSII2ASCII_Translate.STRNAME(gdsii);
					break;
				case 0x0700:
					GDSII2ASCII_Translate.ENDSTR(gdsii);
					break;
				case 0x0800:
					GDSII2ASCII_Translate.BOUNDARY(gdsii);
					break;
				case 0x0900:
					GDSII2ASCII_Translate.PATH(gdsii);
					break;
				case 0x0A00:
					GDSII2ASCII_Translate.SREF(gdsii);
					break;
				case 0x0B00:	/* 2006/11/09: working on */
					GDSII2ASCII_Translate.AREF(gdsii);
					break;
				case 0x0C00:
					GDSII2ASCII_Translate.TEXT(gdsii);
					break;
				case 0x0D02:
					GDSII2ASCII_Translate.LAYER(gdsii);
					break;
				case 0x0E02:
					GDSII2ASCII_Translate.DATATYPE(gdsii);
					break;
				case 0x0F03:
					GDSII2ASCII_Translate.WIDTH(gdsii);
					break;
				case 0x1003:
					GDSII2ASCII_Translate.XY(gdsii);
					break;
				case 0x1100:
					GDSII2ASCII_Translate.ENDEL(gdsii);
					break;
				case 0x1206:
					GDSII2ASCII_Translate.SNAME(gdsii);
					break;
				case 0x1302:
					GDSII2ASCII_Translate.COLROW(gdsii);
					break;
				case 0x1602:
					GDSII2ASCII_Translate.TEXTTYPE(gdsii);
					break;
				case 0x1701:
					GDSII2ASCII_Translate.PRESENTATION(gdsii);
					break;
				case 0x1906:
					GDSII2ASCII_Translate.STRING(gdsii);
					break;
				case 0x1A01:
					GDSII2ASCII_Translate.STRANS(gdsii);
					break;
				case 0x1B05:
					GDSII2ASCII_Translate.MAG(gdsii);
					break;
				case 0x1C05:
					GDSII2ASCII_Translate.ANGLE(gdsii);
					break;
				case 0x2102:
					GDSII2ASCII_Translate.PATHTYPE(gdsii);
					break;
				case 0x2202:
					GDSII2ASCII_Translate.GENERATIONS(gdsii);
					break;
				case 0x2B02:
					GDSII2ASCII_Translate.PROPATTR(gdsii);
					break;
				case 0x2C06:
					GDSII2ASCII_Translate.PROPVALUE(gdsii);
					break;
				case 0x2D00:
					GDSII2ASCII_Translate.BOX(gdsii);
					break;
				case 0x2E02:	/* BOXTYPE */
					GDSII2ASCII_Translate.BOXTYPE( gdsii );
					break;
				case 0x3003:	/* BGNEXTN */
					GDSII2ASCII_Translate.BGNEXTN( gdsii );
					break;
				case 0x3103:	/* ENDEXTN */
					GDSII2ASCII_Translate.ENDEXTN( gdsii );
					break;
				default:					
					System.err.println();
					System.err.println("ERROR: GDSII record type \"" + GDSII2ASCII_Read.dataStr + "\" is not supported!");
					System.exit(1);
					break;
			}
		}
		
		printStream.close();
		
	}
		
		

}
