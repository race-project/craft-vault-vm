/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/* modified from GDSII_to_ASCII-->GDSII */

public class GDSII2ASCII_Read {
	
	public static String dataStr;
	public static int dataInt;
	public static int record_size;
	
	private static String filename;
	private static FileInputStream gdsii_stream;
	private static BufferedInputStream gdsii_stream_b;

	
    // constructor
    public GDSII2ASCII_Read(String name) {
        filename = name;
        File file = new File(filename);
        // check the existance of the file
        if (!file.exists()) {
            System.out.println("No such file!");
            System.exit(1);
        }
        
        try {
        	gdsii_stream = new FileInputStream(file);
        	gdsii_stream_b = new BufferedInputStream( gdsii_stream, 1048576);
        }
        catch (FileNotFoundException e) {
        	System.out.println("No such file!");
            System.exit(1);
        } 
    }  // GDSII
    
    
    public static int read_record() {
    	
    	read();
    	record_size = (dataInt/2)-2;
 
    	return(read());
    }

    
    public static int read() {

        try {
            byte[] buffer = new byte[2]; /* 16 bits */
            int bytes_read;
            int tmp1, tmp2, tmp3;

            //if ((bytes_read = gdsii_stream.read(buffer)) != -1) {
            if ((bytes_read = gdsii_stream_b.read(buffer)) != -1) {

                tmp1 = (int) buffer[0];
                tmp1 = tmp1 << 8;
                tmp1 = tmp1 & 0x0000FF00;
                tmp2 = (int) buffer[1];
                tmp2 = tmp2 & 0x000000FF;
                tmp3 = tmp1 | tmp2;
                String HexString = Integer.toHexString(tmp3);
                switch (HexString.length()) {
                    case 1:
                    	HexString = "000" + HexString;
                        break;
                    case 2:
                    	HexString = "00" + HexString;
                        break;
                    case 3:
                    	HexString = "0" + HexString;
                        break;
                }
                dataStr = HexString.toUpperCase();
                dataInt = tmp3;
                return(2);  /* # of bytes read */
            }  // if
            else {
                return(0);	
            }
        }
        catch (IOException e) {
        	// do nothing
        }
        finally {
        }
        
        return(0);
    }
}
