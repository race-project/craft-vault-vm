/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.io.*;

public class GDSII2ASCII_Translate {
	
	protected static double mantissa;
	private static PrintStream writeToFile;
	
	public static void setPrintStream(PrintStream p) {
		writeToFile = p;
	}
	
	public static void HEADER(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		GDSII2ASCII_Read.read();
		
		writeToFile.println("HEADER " + GDSII2ASCII_Read.dataInt + ";  # version");
	}
	
	public static void PROPATTR(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		GDSII2ASCII_Read.read();
		writeToFile.println("PROPATTR " + GDSII2ASCII_Read.dataInt + ";");
	}
	
	public static void BGNLIB(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 12) {
			error();
		}
		writeToFile.println("BGNLIB;");
		
		/* last modification time */
		writeToFile.print("  LASTMOD  {");
		print_time(gdsii);
		writeToFile.println("  # last modification time");
		
		/* last access time*/
		writeToFile.print("  LASTACC  {");
		print_time(gdsii);
		writeToFile.println("  # last access time");
	}
	
	public static void LIBNAME(GDSII2ASCII_Read gdsii) {
		writeToFile.print("LIBNAME ");
		print_string(gdsii);
	}
	
	public static void PROPVALUE(GDSII2ASCII_Read gdsii) {
		writeToFile.print("PROPVALUE ");
		print_string(gdsii);
	}
	
	public static void UNITS(GDSII2ASCII_Read gdsii) {
		int sign_bit;
		int exponent;
		int temp1, temp2;
		//int temp3, temp4;
		//int i, j;
		
		if (GDSII2ASCII_Read.record_size != 8) {
			error();
		}
		writeToFile.println("UNITS;");
		
		/* USERUNITS */
		GDSII2ASCII_Read.read();
		sign_bit = GDSII2ASCII_Read.dataInt >>> 15;
		temp1 = GDSII2ASCII_Read.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code */
		
		/* mantissa */
		/* 1st word out of 4 words */
		mantissa = 0;
		temp2 = GDSII2ASCII_Read.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
				
		/* 2nd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 8);

		/* 3rd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		
		/* 4th word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		double expo_value = Math.pow(16.0, exponent);
		
		writeToFile.print("  USERUNITS ");
		writeToFile.print((Math.pow(-1.0,sign_bit))*mantissa*expo_value);
		writeToFile.println(";");
		
		/* PHYSUNITS */
		GDSII2ASCII_Read.read();
		sign_bit = GDSII2ASCII_Read.dataInt >>> 15;
		temp1 = GDSII2ASCII_Read.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code */
		
		/* mantissa */
		/* 1st word out of 4 words */
		mantissa = 0;
		temp2 = GDSII2ASCII_Read.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
		
		/* 2nd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 8);
		
		/* 3rd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		
		/* 4th word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		expo_value = Math.pow(16.0, exponent);
		
		writeToFile.print("  PHYSUNITS ");
		writeToFile.print((Math.pow(-1.0,sign_bit))*mantissa*expo_value);
		writeToFile.println(";");
	}
	
	public static void BGNSTR(GDSII2ASCII_Read gdsii) {
		
		if (GDSII2ASCII_Read.record_size != 12) {
			error();
		}
		writeToFile.println();
		writeToFile.println("BGNSTR;  # Begin of structure");
		
		/* creation time */
		writeToFile.print("  CREATION {");
		print_time(gdsii);
		writeToFile.println("  # creation time");
		
		/* last modification time */
		writeToFile.print("  LASTMOD  {");
		print_time(gdsii);
		writeToFile.println("  # last modification time");
		
	}
	
	public static void STRNAME(GDSII2ASCII_Read gdsii) {
		writeToFile.print("STRNAME ");
		print_string(gdsii);
	}
	
	public static void BOUNDARY(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("BOUNDARY;");
		
	}
	
	public static void LAYER(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		writeToFile.print("LAYER ");
		GDSII2ASCII_Read.read();
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.println(";");
	}
	
	public static void DATATYPE(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		writeToFile.print("DATATYPE ");
		GDSII2ASCII_Read.read();
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.println(";");
	}
	
	public static void XY(GDSII2ASCII_Read gdsii) {
		int rec_size;
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;
		
		writeToFile.print("XY ");
		
		rec_size = (GDSII2ASCII_Read.record_size)/4;
		writeToFile.print(rec_size);
		writeToFile.println(";");
		
		for (int i=1; i<=rec_size; i++) {
			/* X coordinate */
			GDSII2ASCII_Read.read();
			two_bytes_high = GDSII2ASCII_Read.dataInt;
			GDSII2ASCII_Read.read();
			two_bytes_low = GDSII2ASCII_Read.dataInt;
			temp1 = two_bytes_high << 16;
			temp2 = two_bytes_low & 0x0000FFFF;
			temp3 = temp1 | temp2;
			writeToFile.print("  X: ");
			writeToFile.print(temp3);
			writeToFile.print(";\t\t\t");
			
			/* Y coordinate */
			GDSII2ASCII_Read.read();
			two_bytes_high = GDSII2ASCII_Read.dataInt;
			GDSII2ASCII_Read.read();
			two_bytes_low = GDSII2ASCII_Read.dataInt;
			temp1 = two_bytes_high << 16;
			temp2 = two_bytes_low & 0x0000FFFF;
			temp3 = temp1 | temp2;
			writeToFile.print(" Y: ");
			writeToFile.print(temp3);
			writeToFile.println(";");
		}
	}
	
	public static void ENDEL(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println("ENDEL;");
	}
	
	public static void ENDSTR(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("ENDSTR;");
	}
	
	public static void BOX(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("BOX;");
	}
	
	public static void BOXTYPE(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		writeToFile.print("BOXTYPE ");
		GDSII2ASCII_Read.read();
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.println(";");
	}
	
	public static void SREF(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("SREF;");
	}
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - first version finished
	 */
	public static void AREF(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("AREF;");
	}
	
	public static void ENDLIB(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("ENDLIB;");
	}
	
	public static void GENERATIONS(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		GDSII2ASCII_Read.read();
		writeToFile.println("GENERATIONS " + GDSII2ASCII_Read.dataInt + ";");
	}
	
	public static void SNAME(GDSII2ASCII_Read gdsii) {
		writeToFile.print("SNAME ");
		print_string(gdsii);
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - first version finished
	 */
	public static void COLROW(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 2) {
			error();
		}
		writeToFile.print("COLROW ");
		GDSII2ASCII_Read.read();
		writeToFile.print(GDSII2ASCII_Read.dataInt);	// column
		writeToFile.print(" ");
		GDSII2ASCII_Read.read();
		writeToFile.print(GDSII2ASCII_Read.dataInt);	// row
		writeToFile.println(";");
	}
	
	
	public static void STRING(GDSII2ASCII_Read gdsii) {
		writeToFile.print("STRING ");
		print_string(gdsii);
	}
	
	public static void TEXT(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("TEXT;");
	}
	
	public static void ANGLE(GDSII2ASCII_Read gdsii) {
		int sign_bit;
		int temp1, temp2;
		int exponent;
		
		if (GDSII2ASCII_Read.record_size != 4) {
			error();
		}
		writeToFile.print("ANGLE ");
		
		/* sign bit */
		GDSII2ASCII_Read.read();
		sign_bit = GDSII2ASCII_Read.dataInt >>> 15;
		
		/* exponent bits */
		temp1 = GDSII2ASCII_Read.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code*/
		
		/* mantissa */
		mantissa = 0;
		
		/* 1st word out of 4 words */
		temp2 = GDSII2ASCII_Read.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
		/* 2nd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 8);
		/* 3rd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		/* 4th word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		double expo_value = Math.pow(16.0, exponent);
		
		writeToFile.print((Math.pow(-1.0,sign_bit))*(mantissa)*(expo_value));
		writeToFile.println(";");
	}
	
	
	
	public static void MAG(GDSII2ASCII_Read gdsii) {
		int sign_bit;
		int temp1, temp2;
		int exponent;
		
		if (GDSII2ASCII_Read.record_size != 4) {
			error();
		}
		writeToFile.print("MAG ");
		
		/* sign bit */
		GDSII2ASCII_Read.read();
		sign_bit = GDSII2ASCII_Read.dataInt >>> 15;
		
		/* exponent bits */
		temp1 = GDSII2ASCII_Read.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code*/
		
		/* mantissa */
		mantissa = 0;
		
		/* 1st word out of 4 words */
		temp2 = GDSII2ASCII_Read.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
		/* 2nd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 8);
		/* 3rd word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		/* 4th word out of 4 words */
		GDSII2ASCII_Read.read();
		temp2 = GDSII2ASCII_Read.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		double expo_value = Math.pow(16.0, exponent);
		
		writeToFile.print((Math.pow(-1.0,sign_bit))*(mantissa)*(expo_value));
		writeToFile.println(";");
	}
	
	public static void accumulate_mantissa(int in_data, int right_shift, int power) {
		int temp1, temp2;
		
		for (int i=1; i<=right_shift; i++) {
			temp1 = in_data >>> (right_shift-i);
			temp2 = temp1 & 0x00000001;
			if (temp2 != 0) {
				mantissa = mantissa + (1.0/(Math.pow(2.0, power+i)));
			}
		}
	}
	
	public static void STRANS(GDSII2ASCII_Read gdsii) {
		int temp1, temp2, temp3;
		//int temp4;
		
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		writeToFile.print("STRANS ");
		GDSII2ASCII_Read.read();
		temp1 = GDSII2ASCII_Read.dataInt & 0x00008006;
		temp2 = temp1 >>> 15;
		writeToFile.print(temp2);
		writeToFile.print(",");
		temp2 = temp1 >>> 2;
		temp3 = temp2 & 0x00000001;
		writeToFile.print(temp3);
		writeToFile.print(",");
		temp2 = temp1 >>> 1;
		temp3 = temp2 & 0x00000001;
		writeToFile.print(temp3);
		writeToFile.println(";");
	}
	
	public static void PATHTYPE(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		GDSII2ASCII_Read.read();
		writeToFile.print("PATHTYPE ");
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.println(";");
	}
	
	public static void PRESENTATION(GDSII2ASCII_Read gdsii) {
		int temp1, temp2, temp3;
		//int temp4;
		
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		writeToFile.print("PRESENTATION ");
		
		GDSII2ASCII_Read.read();
		temp1 = GDSII2ASCII_Read.dataInt & 0x0000003F;
		temp2 = temp1 >>> 4;
		writeToFile.print(temp2);
		writeToFile.print(",");
		temp2 = temp1 >>> 2;
		temp3 = temp2 & 0x00000003;
		writeToFile.print(temp3);
		writeToFile.print(",");
		temp2 = temp1 & 0x00000003;
		writeToFile.print(temp2);
		writeToFile.println(";");		
	}
	
	public static void TEXTTYPE(GDSII2ASCII_Read gdsii) {
		if (GDSII2ASCII_Read.record_size != 1) {
			error();
		}
		GDSII2ASCII_Read.read();
		writeToFile.print("TEXTTYPE ");
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.println(";");
	}
	
	public static void WIDTH(GDSII2ASCII_Read gdsii) {
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;
		
		if (GDSII2ASCII_Read.record_size != 2) {
			error();
		}
		writeToFile.print("WIDTH ");
		GDSII2ASCII_Read.read();
		two_bytes_high = GDSII2ASCII_Read.dataInt;
		GDSII2ASCII_Read.read();
		two_bytes_low = GDSII2ASCII_Read.dataInt;
		temp1 = two_bytes_high << 16;
		temp2 = two_bytes_low & 0x0000FFFF;
		temp3 = temp1 | temp2;
		writeToFile.print(temp3);
		writeToFile.println(";");
	}
	
	public static void PATH( GDSII2ASCII_Read gdsii ) {
		if (GDSII2ASCII_Read.record_size != 0) {
			error();
		}
		writeToFile.println();
		writeToFile.println("PATH;");
	}
	
	
	/* BGNEXTN (3003) */
	public static void BGNEXTN( GDSII2ASCII_Read gdsii ) 
	{
		if (GDSII2ASCII_Read.record_size != 2) {
			error();
		}
		
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;		
		
		writeToFile.print("BGNEXTN ");
		
		GDSII2ASCII_Read.read();
		two_bytes_high = GDSII2ASCII_Read.dataInt;
		
		GDSII2ASCII_Read.read();
		two_bytes_low = GDSII2ASCII_Read.dataInt;
		
		temp1 = two_bytes_high << 16;
		temp2 = two_bytes_low & 0x0000FFFF;
		temp3 = temp1 | temp2;
		
		writeToFile.print(temp3);
		writeToFile.println(";");		
	}
	
	
	/* ENDEXTN (3103) */
	public static void ENDEXTN( GDSII2ASCII_Read gdsii ) 
	{		
		if (GDSII2ASCII_Read.record_size != 2) {
			error();
		}
		
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;		
		
		writeToFile.print("ENDEXTN ");
		
		GDSII2ASCII_Read.read();
		two_bytes_high = GDSII2ASCII_Read.dataInt;
		
		GDSII2ASCII_Read.read();
		two_bytes_low = GDSII2ASCII_Read.dataInt;
		
		temp1 = two_bytes_high << 16;
		temp2 = two_bytes_low & 0x0000FFFF;
		temp3 = temp1 | temp2;
		
		writeToFile.print(temp3);
		writeToFile.println(";");		
	}
	
	
	private static void print_time(GDSII2ASCII_Read gdsii) {
		GDSII2ASCII_Read.read();	/* year */
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.print("-");
		GDSII2ASCII_Read.read();	/* month */
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.print("-");
		GDSII2ASCII_Read.read();	/* day */
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.print("  ");
		GDSII2ASCII_Read.read();	/* hour */
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.print(":");
		GDSII2ASCII_Read.read();	/* minute */
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.print(":");
		GDSII2ASCII_Read.read();	/* seconds */
		writeToFile.print(GDSII2ASCII_Read.dataInt);
		writeToFile.print("};");
		
	}
	
	private static void print_string(GDSII2ASCII_Read gdsii) {
		int data1, data2;
		
		for (int i=1; i<=GDSII2ASCII_Read.record_size; i++) {
			char c;
			GDSII2ASCII_Read.read();
			data1 = GDSII2ASCII_Read.dataInt >>> 8;
			data2 = GDSII2ASCII_Read.dataInt & 0x000000FF;
			c = (char) data1;
			if (c != '\0')
				writeToFile.print(c);
			c = (char) data2;
			if (c != '\0')
				writeToFile.print(c);
		}
		writeToFile.println(";");
	}
	
	private static void error() {
		System.err.println("Error: unrecognized format!");
		System.exit(1);
	}


}
