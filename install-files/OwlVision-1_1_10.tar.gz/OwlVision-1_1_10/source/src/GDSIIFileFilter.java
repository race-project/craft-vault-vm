/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.io.File;

import javax.swing.filechooser.FileFilter;

public class GDSIIFileFilter extends FileFilter {

	public boolean accept(File file) {
		// TODO Auto-generated method stub
		// if it is a directory -- we want to show it so return true.
	    if (file.isDirectory()) 
	      return true;
	    
	    // get the extension of the file
	    
	    String extension = getExtension(file);
	    
	    //check to see if the extension is equal to "html" or "htm"
	    if ( (extension.equals("gds")) || 
	    	 (extension.equals("gds2")) || 
	    	 (extension.equals("gdsii")) ||
	    	 (extension.equals("sf")) ||
	    	 (extension.equals("strm")) ||
	    	 (extension.equals("db"))
	    	 ) 
	    { 
	       return true; 
	    }

	    //default -- fall through. False is return on all
	    //occasions except:
	    //a) the file is a directory
	    //b) the file's extension is what we are looking for.

		return false;
	}

	
	public String getDescription() {
		return "GDSII Files (*.gds, *.gds2, *.gdsii, *.sf, *.strm, *.db)";
	}
	
	
	/* Method to get the extension of the file, in lowercase */
	private String getExtension(File f) {    
		String s = f.getName();    
		int i = s.lastIndexOf('.');    
		if (i > 0 &&  i < s.length() - 1)       
			return s.substring(i+1).toLowerCase();    
		return "";
	}

}
