/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */

//import java.sql.ResultSet;
//import java.sql.SQLException;

/*
 * Created on 2005/4/2
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GDSIIreadRecords {
	
	private static double 			mantissa;
	protected static int 			struct_id;
	public static int 				element_id;
	public static int 				layer_no;
	public static int 				vertex;
	public static int 				record_type;
	public static int 				data_type;
	public static int 				box_type;
	public static int 				text_type;
	public static int 				width;
	public static String 			string;
	public static double 			angle;
	private static double			mag;
	private static DSpresentation 	presentation;
	
	// public static DSstrList GDSIIDS;
	private static DSxyList 		xyList;
	private static DSstrans 		strans;
	private static DScolrow			colrow;
	private static int				path_type;
	private static int				bgnextn_value;
	private static int				endextn_value;
	
	
	
	public static void HEADER(GDSII gdsii) {
		if (GDSII.record_size != 1) {
			error();
		}
		GDSII.read();
				
		struct_id  = 0;
		element_id = 0;
		
		DSbuild.strList = new DSstrList();
		
		// System.out.println("HEADER " + GDSII.dataInt + ";  # version");
	}
	
	
	public static void PROPATTR(GDSII gdsii) {
		
		if (GDSII.record_size != 1) {
			error();
		}
		GDSII.read();
		//System.out.println("PROPATTR " + GDSII.dataInt + ";");
	}
	
	
	public static void BGNLIB(GDSII gdsii) {
		if (GDSII.record_size != 12) {
			error();
		}
		//System.out.println("BGNLIB;");
		
		/* last modification time */
		//System.out.print(" LASTMOD  {");
		print_time(gdsii);
		//System.out.println("  # last modification time");
		
		/* last access time*/
		//System.out.print(" LASTACC  {");
		print_time(gdsii);
		//System.out.println("  # last access time");
	}
	
	public static void LIBNAME(GDSII gdsii) {
		//System.out.print("LIBNAME ");
		print_string(gdsii);
	}
	
	public static void PROPVALUE(GDSII gdsii) {
		//System.out.print("PROPVALUE ");
		print_string(gdsii,0);
	}
	
	public static void UNITS(GDSII gdsii) {
		int sign_bit;
		int exponent;
		int temp1, temp2;
		//int temp3, temp4;
		//int i, j;
		
		if (GDSII.record_size != 8) {
			error();
		}
		//System.out.println("UNITS;");
		
		/* === USERUNITS === */
		GDSII.read();
		sign_bit = GDSII.dataInt >>> 15;
		temp1 = GDSII.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code */
		
		/* mantissa */
		/* 1st word out of 4 words */
		mantissa = 0;
		temp2 = GDSII.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
				
		/* 2nd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 8);

		/* 3rd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		
		/* 4th word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		double expo_value = Math.pow(16.0, exponent);		
		
		//System.out.print(" USERUNITS ");
		//System.out.print((Math.pow(-1.0,sign_bit))*mantissa*expo_value);
		//System.out.println(";");
		
		SizeSetting.setUserUnit( (Math.pow(-1.0,sign_bit))*mantissa*expo_value );
		
		/* === PHYSUNITS === */
		GDSII.read();
		sign_bit = GDSII.dataInt >>> 15;
		temp1 = GDSII.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code */
		
		/* mantissa */
		/* 1st word out of 4 words */
		mantissa = 0;
		temp2 = GDSII.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
		
		/* 2nd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 8);
		
		/* 3rd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		
		/* 4th word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		expo_value = Math.pow(16.0, exponent);
		
		//System.out.print(" PHYSUNITS ");
		//System.out.print((Math.pow(-1.0,sign_bit))*mantissa*expo_value);
		//System.out.println(";");
		
		SizeSetting.setPhysUnit( (Math.pow(-1.0,sign_bit))*mantissa*expo_value );		
	}
	
	
	public static void BGNSTR(GDSII gdsii) {
		
		if (GDSII.record_size != 12) {
			error();
		}
		//System.out.println();
		//System.out.println("BGNSTR;  # Begin of structure");
		
		/* creation time */
		//System.out.print(" CREATION {");
		print_time(gdsii);
		//System.out.println("  # creation time");
		
		/* last modification time */
		//System.out.print(" LASTMOD  {");
		print_time(gdsii);
		//System.out.println("  # last modification time");
		
		struct_id++;
		
		DSbuild.boundaryList = new DSboundaryList();
		DSbuild.boxList  = new DSboxList();
		DSbuild.srefList = new DSsrefList();
		DSbuild.arefList = new DSarefList();
		DSbuild.pathList = new DSpathList();
		DSbuild.textList = new DStextList();
	}
	
	
	public static void STRNAME(GDSII gdsii) {
		//System.out.print("STRNAME ");
		print_string(gdsii);
		//LDB.store_struct_id_name();
		
		//GDSIIDS.insert(string);
		DSbuild.strNode = new DSstrNode(string);

		CellTableInfo.insert( string );
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - initial version
	 */
	public static void COLROW( GDSII gdsii )
	{
		if (GDSII.record_size != 2) {
			error();
		}
		
		GDSII.read();		
		int col = GDSII.dataInt;
		
		GDSII.read();
		int row = GDSII.dataInt;
	
		colrow = new DScolrow( col, row );		
	}
	
	
	public static void BOUNDARY(GDSII gdsii) {
		
		if (GDSII.record_size != 0) {
			error();
		}
		
		element_id++;
		record_type = 8;
	}
	
	
	public static void LAYER(GDSII gdsii) 
	{
		if (GDSII.record_size != 1) {
			error();
		}
		//System.out.print("LAYER ");
		GDSII.read();
		//System.out.print(GDSII.dataInt);
		//System.out.println(";");
		
		layer_no = GDSII.dataInt;
		LayerTableInfo.insert( layer_no );
	}
	
	
	public static void DATATYPE(GDSII gdsii) {
		if (GDSII.record_size != 1) {
			error();
		}
		//System.out.print("DATATYPE ");
		GDSII.read();
		//System.out.print(GDSII.dataInt);
		//System.out.println(";");
		
		data_type = GDSII.dataInt;
	}
	
	
	public static void GENERATIONS(GDSII gdsii) {
		if (GDSII.record_size != 1) {
			error();
		}
		GDSII.read();
	}
	
	
	public static void XY(GDSII gdsii) {
		int rec_size;
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;
		int x_coord, y_coord;
		
		//System.out.print("XY ");
		
		rec_size = (GDSII.record_size)/4;
		//System.out.print(rec_size);
		//System.out.println(";");
		
		//DS_build.xyList = new DSxyList();
		xyList = new DSxyList();
		
		vertex = rec_size;
		
		for (int i=1; i<=rec_size; i++) {
			/* X coordinate */
			GDSII.read();
			two_bytes_high = GDSII.dataInt;
			GDSII.read();
			two_bytes_low = GDSII.dataInt;
			temp1 = two_bytes_high << 16;
			temp2 = two_bytes_low & 0x0000FFFF;
			temp3 = temp1 | temp2;
			//System.out.print(" X: ");
			//System.out.print(temp3);
			//System.out.print(";\t\t");
			x_coord = temp3;
			
			/* Y coordinate */
			GDSII.read();
			two_bytes_high = GDSII.dataInt;
			GDSII.read();
			two_bytes_low = GDSII.dataInt;
			temp1 = two_bytes_high << 16;
			temp2 = two_bytes_low & 0x0000FFFF;
			temp3 = temp1 | temp2;
			//System.out.print(" Y: ");
			//System.out.print(temp3);
			//System.out.println(";");
			y_coord = temp3;
			
			// store the coordinates
			xyList.insert(x_coord, y_coord);
		}
	}
	
	
	public static void ENDEL(GDSII gdsii) 
	{
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("ENDEL;\n");
		
		/* store data */
		switch(record_type) {
		
			case 8: /* BOUNDARY */
				/* create a boundaryNode */
				DSbuild.boundaryNode = new DSboundaryNode(
						GDSIIreadRecords.layer_no, 
						GDSIIreadRecords.data_type,
						xyList,
						null);
				/* insert boundaryNode to boundaryList */
				DSbuild.boundaryList.insert(DSbuild.boundaryNode);
				break;
			case 45: /* BOX */
				/* create a boxNode */
				DSbuild.boxNode = new DSboxNode(
						GDSIIreadRecords.layer_no, 
						GDSIIreadRecords.data_type,
						xyList,
						null);
				/* insert boundaryNode to boundaryList */
				DSbuild.boxList.insert(DSbuild.boxNode);
				break;
			case 9: /* PATH */
				/* create a boundaryNode */
				DSbuild.pathNode = new DSpathNode(
						GDSIIreadRecords.layer_no, 
						GDSIIreadRecords.data_type,
						GDSIIreadRecords.path_type,
						GDSIIreadRecords.width,
						GDSIIreadRecords.bgnextn_value,
						GDSIIreadRecords.endextn_value,
						xyList,
						null);
				/* insert boundaryNode to boundaryList */
				DSbuild.pathList.insert(DSbuild.pathNode);
				break;
			case 10: /* SREF */
				/* create a boxNode */
				DSbuild.srefNode = new DSsrefNode(
						GDSIIreadRecords.string,
						GDSIIreadRecords.strans,
						GDSIIreadRecords.angle,
						xyList,
						null );
				/* insert boundaryNode to boundaryList */
				DSbuild.srefList.insert(DSbuild.srefNode);
				// System.out.println("ANGLE: " + Translate.angle);
				break;
			case 11: /* AREF */
				DSbuild.arefNode = new DSarefNode(
						GDSIIreadRecords.string,
						GDSIIreadRecords.strans,
						GDSIIreadRecords.angle,
						GDSIIreadRecords.colrow,
						xyList,
						null );
				DSbuild.arefList.insert( DSbuild.arefNode );
				break;
			case 12: /* TEXT */
				/* create a textNode */
				DSbuild.textNode = new DStextNode(
						GDSIIreadRecords.layer_no, 
						GDSIIreadRecords.text_type,
						GDSIIreadRecords.presentation,
						GDSIIreadRecords.strans,
						GDSIIreadRecords.mag,
						GDSIIreadRecords.angle,
						xyList,
						GDSIIreadRecords.string,
						null);
				/* insert textNode to textList */
				DSbuild.textList.insert(DSbuild.textNode);
				break;
			default:
				/* do nothing */
				break;
		}
	}
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/10 - AREF supported
	 */
	public static void ENDSTR(GDSII gdsii) 
	{
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("ENDSTR;");
		
		DSbuild.insert_boundaryList_to_strNode();
		DSbuild.insert_boxList_to_strNode();
		DSbuild.insert_srefList_to_strNode();
		DSbuild.insert_arefList_to_strNode();
		DSbuild.insert_pathList_to_strNode();
		DSbuild.insert_textList_to_strNode();
		
		DSbuild.insert_strNode_to_strList();
	}
	
	
	public static void BOX(GDSII gdsii) {
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("BOX;");
		
		element_id++;
		record_type = 45;
	}
	
	public static void BOXTYPE(GDSII gdsii) {
		if (GDSII.record_size != 1) {
			error();
		}
		//System.out.print("BOXTYPE ");
		GDSII.read();
		//System.out.print(GDSII.dataInt);
		//System.out.println(";");
		
		box_type = GDSII.dataInt;
	}
	
	public static void SREF(GDSII gdsii) {
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("SREF;");
		
		angle  = 0;			/* initialize */
		strans = null;		/* initialize */
		element_id++;
		record_type = 10;  	/* SREF */
	}
	
	
	/* Author: I-Lun Tseng
	 * History: initial version
	 */
	public static void AREF(GDSII gdsii) {
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("AREF;");
		
		angle  = 0;			/* initialize */
		strans = null;		/* initialize */
		element_id++;
		record_type = 11;  	/* AREF */
	}
	
	
	public static void ENDLIB(GDSII gdsii) {
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("ENDLIB;");
	}
	
	
	public static void SNAME(GDSII gdsii) {
		//System.out.print("SNAME ");
		print_string(gdsii);
	}
	
	
	public static void STRING(GDSII gdsii) {
		//System.out.print("STRING ");
		print_string(gdsii);
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/15 - added MAG and ANGLE
	 */
	public static void TEXT(GDSII gdsii) 
	{
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("TEXT;");
		
		text_type = 0;			/* initialize */
		presentation = null;	/* initialize */
		strans = null;			/* initialize */
		mag = 0;				/* initialize */
		angle  = 0;				/* initialize */
		element_id++;
		record_type = 12;
	}
	
	
	public static void MAG(GDSII gdsii) 
	{
		int sign_bit;
		int temp1, temp2;
		int exponent;
		
		if (GDSII.record_size != 4) {
			error();
		}
		//System.out.print("MAG ");
		
		/* sign bit */
		GDSII.read();
		sign_bit = GDSII.dataInt >>> 15;
		
		/* exponent bits */
		temp1 = GDSII.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code*/
		
		/* mantissa */
		mantissa = 0;
		
		/* 1st word out of 4 words */
		temp2 = GDSII.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
		
		/* 2nd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 8);
		
		/* 3rd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		
		/* 4th word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		double expo_value = Math.pow(16.0, exponent);
		
		mag = (Math.pow(-1.0,sign_bit))*(mantissa)*(expo_value);
		
		//System.out.println( mag );
		
		//System.out.println(";");
	}
	
	
	public static void ANGLE(GDSII gdsii) {
		int sign_bit;
		int temp1, temp2;
		int exponent;
		
		if (GDSII.record_size != 4) {
			error();
		}
		//System.out.print("ANGLE ");
		
		/* sign bit */
		GDSII.read();
		sign_bit = GDSII.dataInt >>> 15;
		
		/* exponent bits */
		temp1 = GDSII.dataInt & 0x00007F00;  /* mask bits */
		exponent = (temp1 >>> 8) - 64;  /* excess-64 code*/
		
		/* mantissa */
		mantissa = 0;
		
		/* 1st word out of 4 words */
		temp2 = GDSII.dataInt & 0x000000FF;
		accumulate_mantissa(temp2, 8, 0);
		/* 2nd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 8);
		/* 3rd word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 24);
		/* 4th word out of 4 words */
		GDSII.read();
		temp2 = GDSII.dataInt;
		accumulate_mantissa(temp2, 16, 40);
		
		double expo_value = Math.pow(16.0, exponent);
		
		// System.out.print((Math.pow(-1.0,sign_bit))*(mantissa)*(expo_value));
		// System.out.println(";");
		
		angle = (Math.pow(-1.0,sign_bit))*(mantissa)*(expo_value);
		// System.out.println("== angle ==> " + angle);
	}
	
		
	public static void accumulate_mantissa(int in_data, int right_shift, int power) {
		int temp1, temp2;
		
		for (int i=1; i<=right_shift; i++) {
			temp1 = in_data >>> (right_shift-i);
			temp2 = temp1 & 0x00000001;
			if (temp2 != 0) {
				mantissa = mantissa + (1.0/(Math.pow(2.0, power+i)));
			}
		}
	}
	
	
	public static void STRANS(GDSII gdsii) 
	{
		int temp1, temp2;
		int temp3, temp4;
		
		int bit0, bit13, bit14;
		
		if (GDSII.record_size != 1) {
			error();
		}
		//System.out.print("STRANS ");
		GDSII.read();
		temp1 = GDSII.dataInt & 0x00008006;
		temp2 = temp1 >>> 15;
		bit0 = temp2;
		//System.out.print(temp2);
		//System.out.print(",");
		temp2 = temp1 >>> 2;
		temp3 = temp2 & 0x00000001;
		bit13 = temp3;
		//System.out.print(temp3);
		//System.out.print(",");
		temp2 = temp1 >>> 1;
		temp4 = temp2 & 0x00000001;
		bit14 = temp4;
		//System.out.print(temp4);
		//System.out.println(";");
		
		strans = new DSstrans( bit0, bit13, bit14 );
	}
	
	
	public static void PATHTYPE(GDSII gdsii) {
		if (GDSII.record_size != 1) {
			error();
		}
		GDSII.read();
		//System.out.print("PATHTYPE ");
		//System.out.print(GDSII.dataInt);
		//System.out.println(";");
		
		path_type = GDSII.dataInt;
	}
	
	
	public static void PRESENTATION(GDSII gdsii) {
		int temp1, temp2, temp3;
		
		if (GDSII.record_size != 1) {
			error();
		}
		//System.out.print("PRESENTATION ");
		
		GDSII.read();
		temp1 = GDSII.dataInt & 0x0000003F;
		temp2 = temp1 >>> 4;
		//System.out.print(temp2);
		//System.out.print(",");
		int bits_10_11 = temp2;
		
		temp2 = temp1 >>> 2;
		temp3 = temp2 & 0x00000003;
		//System.out.print(temp3);
		//System.out.print(",");
		int bits_12_13 = temp3;
		
		temp2 = temp1 & 0x00000003;
		//System.out.print(temp2);
		//System.out.println(";");
		int bits_14_15 = temp2;
		
		presentation = new DSpresentation( bits_10_11, bits_12_13, bits_14_15 );
	}
	
	
	public static void TEXTTYPE(GDSII gdsii) {
		if (GDSII.record_size != 1) {
			error();
		}
		GDSII.read();
		//System.out.print("TEXTTYPE ");
		//System.out.print(GDSII.dataInt);
		//System.out.println(";");
		
		text_type = GDSII.dataInt;
	}
	
	
	public static void WIDTH(GDSII gdsii) {
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;
		
		if (GDSII.record_size != 2) {
			error();
		}
		//System.out.print("WIDTH ");
		GDSII.read();
		two_bytes_high = GDSII.dataInt;
		GDSII.read();
		two_bytes_low = GDSII.dataInt;
		temp1 = two_bytes_high << 16;
		temp2 = two_bytes_low & 0x0000FFFF;
		temp3 = temp1 | temp2;
		//System.out.print(temp3);
		//System.out.println(";");
		
		width = temp3;
	}
	
	
	public static void PATH( GDSII gdsii ) {
		if (GDSII.record_size != 0) {
			error();
		}
		//System.out.println("PATH;");
		
		element_id++;
		record_type = 9;
		
		layer_no = 0;		/* initialize */
		data_type = 0;		/* initialize */
		path_type = 0;		/* initialize */
		width = 0;			/* initialize */
		bgnextn_value = 0;	/* initialize */
		endextn_value = 0;	/* initialize */
	}
	
	
	/* BGNEXTN (3003) */
	public static void BGNEXTN( GDSII gdsii ) 
	{
		if (GDSII.record_size != 2) {
			error();
		}
		
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;		
		
		//writeToFile.print("BGNEXTN ");
		
		GDSII.read();
		two_bytes_high = GDSII.dataInt;
		
		GDSII.read();
		two_bytes_low = GDSII.dataInt;
		
		temp1 = two_bytes_high << 16;
		temp2 = two_bytes_low & 0x0000FFFF;
		temp3 = temp1 | temp2;
		
		//writeToFile.print(temp3);
		//writeToFile.println(";");
		
		bgnextn_value = temp3;
	}
	
	
	/* ENDEXTN (3103) */
	public static void ENDEXTN( GDSII gdsii )
	{		
		if (GDSII.record_size != 2) {
			error();
		}
		
		int two_bytes_high, two_bytes_low;
		int temp1, temp2, temp3;		
		
		//writeToFile.print("ENDEXTN ");
		
		GDSII.read();
		two_bytes_high = GDSII.dataInt;
		
		GDSII.read();
		two_bytes_low = GDSII.dataInt;
		
		temp1 = two_bytes_high << 16;
		temp2 = two_bytes_low & 0x0000FFFF;
		temp3 = temp1 | temp2;
		
		//writeToFile.print(temp3);
		//writeToFile.println(";");
		
		endextn_value = temp3;
	}
	
	
	public static void SKIPRECORD(GDSII gdsii) {
		
		for (int i=0; i<GDSII.record_size; i++) {
			GDSII.read();
		}		
	}
	
	
	private static void print_time(GDSII gdsii) {
		GDSII.read();	/* year */
		//System.out.print(GDSII.dataInt);
		//System.out.print("-");
		GDSII.read();	/* month */
		//System.out.print(GDSII.dataInt);
		//System.out.print("-");
		GDSII.read();	/* day */
		//System.out.print(GDSII.dataInt);
		//System.out.print("  ");
		GDSII.read();	/* hour */
		//System.out.print(GDSII.dataInt);
		//System.out.print(":");
		GDSII.read();	/* minute */
		//System.out.print(GDSII.dataInt);
		//System.out.print(":");
		GDSII.read();	/* seconds */
		//System.out.print(GDSII.dataInt);
		//System.out.print("};");
	}
	

	private static void print_string(GDSII gdsii) {
		int data1, data2;
		StringBuffer str = new StringBuffer("");; 
		//string = "";
		
		for (int i=1; i<=GDSII.record_size; i++) {
			char c;
			GDSII.read();
			data1 = GDSII.dataInt >>> 8;
			data2 = GDSII.dataInt & 0x000000FF;
			c = (char) data1;
			if (c != '\0') {
				//string = string + c;
				str.append(c);
			}
			c = (char) data2;
			if (c != '\0') {
				//string = string + c;
				str.append(c);
			}
		}
		string = str.toString();
		
		//System.out.println("STRING: " + string);
	}
	
	
	
	private static void print_string(GDSII gdsii, int type) {
		//int data1, data2;
		
		for (int i=1; i<=GDSII.record_size; i++) {
			//char c;
			GDSII.read();
			//data1 = GDSII.dataInt >>> 8;
			//data2 = GDSII.dataInt & 0x000000FF;
			//c = (char) data1;
			//if (c != '\0') {
				//System.out.print(c);
			//}
			//c = (char) data2;
			//if (c != '\0') {
				//System.out.print(c);
			//}
		}
		/* System.out.println(";"); */
	}
	
	
	private static void error() {
		System.err.println("ERROR: unrecognized format!");
		System.exit(1);
	}

}
