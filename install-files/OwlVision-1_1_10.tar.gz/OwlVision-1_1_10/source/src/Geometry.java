/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */

/*
 * Created on 6/12/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author iltseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Geometry {
	
	/*
	 * Test whether a point "r" lies left or right of the directed line
	 * through two points "p" and "q".
	 * 
	 *     	"p" = (px,py)
	 * 		"q" = (qx,qy)
	 * 		"r" = (rx,ry)
	 * 
	 * 		    | 1  px  py |
	 *      D = | 1  qx  qy |
	 *          | 1  rx  ry |
	 * 
	 * If D<0,  turn right.
	 * If D>0,  turn left.
	 * If D==0, colinear.
	 *   
	 */
	
	public static boolean isTurnLeft(
								int px, int py,
								int qx, int qy,
								int rx, int ry ) 
	{
		double det = determinant( px,py,qx,qy,rx,ry );

		if (det>0) {
			return( true );
		}

		return( false );
	}
	
	
	public static boolean isTurnRight(
								int px, int py,
								int qx, int qy,
								int rx, int ry ) 
	{
		double det = determinant( px,py,qx,qy,rx,ry );
		
		if (det<0) {
			return( true );
		}
		
		return( false );		
	}
	
	
	public static double determinant(
								int px, int py,
								int qx, int qy,
								int rx, int ry )
	{
		double pX = px;
		double pY = py;
		double qX = qx;
		double qY = qy;
		double rX = rx;
		double rY = ry;
		double det = qX*rY + rX*pY + pX*qY - qX*pY - pX*rY - rX*qY ;
		
		return( det );		
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/28
	 */
	/*
	 * 		  (p,q)
	 * 			o
	 * 			|\
	 * 			| \
	 * 			|  \    slope = m
	 * 			|	\	length = e
	 * 			|    \
	 * 			|     \
	 * 			|      \
	 * 			|		\
	 * 			---------o (0,0)
	 */
	/* Inputs:  m, e
	 * Returns: (p1, q1) and (p2, q2)
	 */
	public static TwoVertices calculateVertexAccordingToSlopeAndLength( double m, double e )
	{
		double p1, p2;
		double q1, q2;
		
		p1 = Math.sqrt( ( Math.pow( e, 2 ) ) / ( 1 + Math.pow( m, 2 ) ) );
		p2 = (-1)*p1;
		
		q1 = m * p1;
		q2 = m * p2;
		
		return( new TwoVertices( (int)p1, (int)q1, (int)p2, (int)q2 ) );
	}
	

}
