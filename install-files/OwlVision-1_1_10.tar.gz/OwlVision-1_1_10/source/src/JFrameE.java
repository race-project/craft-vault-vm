/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import javax.swing.*; 
import java.awt.event.*; 
import java.beans.PropertyVetoException;

public class JFrameE extends JFrame implements ComponentListener {

	public JFrameE(String titleString) {
		// TODO Auto-generated constructor stub
		addComponentListener(this); 
		this.setTitle( titleString );
	}

	/* Resize the main window (JDesktop) */
	public void componentResized(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		//System.out.println("Resized");		
		arrangeWindows();		
	}

	public void componentMoved(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void componentShown(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void componentHidden(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public void arrangeWindows() {
		int frame02width = 200;
		int frame02height = this.getContentPane().getSize().height / 3 + 10;
		int frame03height = this.getContentPane().getSize().height / 3 - 20;
		int frame04height = this.getContentPane().getSize().height - frame02height - frame03height;
		int frame05height = 100;
		try {
			MainClass.intFrame01.setIcon(false);
			MainClass.intFrame02.setIcon(false);
			MainClass.intFrame03.setIcon(false);
			MainClass.intFrame04.setIcon(false);
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		MainClass.intFrame01.setLocation(0,0);
		MainClass.intFrame01.setSize( this.getContentPane().getSize().width - frame02width, this.getContentPane().getSize().height - frame05height );
		MainClass.intFrame02.setLocation( this.getContentPane().getSize().width - frame02width, 0);
		MainClass.intFrame02.setSize( frame02width, frame02height );
		MainClass.intFrame03.setLocation( this.getContentPane().getSize().width - frame02width, frame02height );
		MainClass.intFrame03.setSize( frame02width, frame03height );
		MainClass.intFrame04.setLocation( this.getContentPane().getSize().width - frame02width, frame02height + frame03height );
		MainClass.intFrame04.setSize( frame02width, frame04height );
		MainClass.intFrame05.setLocation(0, this.getContentPane().getSize().height - frame05height );
		MainClass.intFrame05.setSize( this.getContentPane().getSize().width - frame02width, frame05height );
		
		
		/*
		System.out.println( "size: " +
							draw_polygons.minX + ", " +
							draw_polygons.maxX + ", " +
							draw_polygons.minY + ", " +
							draw_polygons.maxY 
							);
		System.out.println( "Window Size: " +
				draw_polygons.window_width + ", " +
				draw_polygons.window_height
				);
		*/
	}

}
