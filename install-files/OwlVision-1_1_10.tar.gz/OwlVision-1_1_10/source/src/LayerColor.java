/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Color;


public class LayerColor {
	
	private Color	color;
	private boolean isFill;
	
	
	public LayerColor(int r, int g, int b, int a, int fill) 
	{
		color = new Color( r, g, b, a );
		
		if ( fill == 1 ) {
			isFill = true;
		}
		else {
			isFill = false;
		}
	}
	
	
	public int getRed() {
		return( color.getRed() );
	}
	
	public int getGreen() {
		return( color.getGreen() );
	}
	
	public int getBlue() {
		return( color.getBlue() );
	}
	
	public int getAlpha() {
		return( color.getAlpha() );
	}
	
	public Color getColor() {
		return( color );
	}
	
	public boolean isFill() {
		return( isFill );
	}
	
	public void setFill( boolean f ) {
		isFill = f;
	}
	

}
