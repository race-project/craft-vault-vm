/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */

import java.awt.Color;

import javax.swing.table.AbstractTableModel;

public class LayerTable extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String[] headings = new String[] {			
			"No.", "Display", "Color", "Fill"
			//"Layer No.", "Display?", "Color"
	};
	
	
	/* should be set to private */
	public static Object[][] data = new Object[][] { 
		{ " ", Boolean.FALSE }
	};
	
	public int getRowCount() {
		return( data.length );
	}
	
	public int getColumnCount() {
		return( data[0].length );
	}
	
	public Object getValueAt(int row, int column) {
		return( data[row][column] );
	}
	
	public String getColumnName(int column) {
		return( headings[column] );
	}
	
	public Class getColumnClass(int column) {
		return( data[0][column].getClass() );
	}
	
	
	/* "Display", "Color", and "Fill" columns are editable.
	 * "Layer No." column is not editable.
	 */
	public boolean isCellEditable(int rowIndex, int columnIndex) 
	{
		if ( columnIndex == 1 || columnIndex == 2 || columnIndex == 3 )
		{
			return(true);
		}
			
		return(false);
	}
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/20 - added "Change Color ?"
	 */
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) 
	{
		//System.out.println("[ " + rowIndex + ", "+ columnIndex + " ]" );
		
		switch( columnIndex ) 
		{
			/* Display Layer ? */
			case 1:
				if ( data[rowIndex][1] == Boolean.TRUE ) {
					data[rowIndex][1] = Boolean.FALSE;
					setLayerInfo( rowIndex, columnIndex, false );
				}
				else {
					data[rowIndex][1] = Boolean.TRUE;
					setLayerInfo( rowIndex, columnIndex, true );
				}
				break;
				
			/* Change Color ? */
			case 2:
				//Color c = (Color) data[rowIndex][2];
				//System.out.println( "Color: " + c.getRed() + ", " + c.getGreen() + ", " + c.getBlue() );
				Color newColor = (Color) MainClass.colorEditor.getCellEditorValue();
				//System.out.println( "newColor: " + newColor );
				data[rowIndex][2] = newColor;	// set the color on the frame (intFrame02)
				int layerNo = ((Integer) data[rowIndex][0]).intValue();
				DrawColor.setColorOnly( layerNo, newColor );
				
				DrawLayout.isRedrawImage(true);	// new
				PanelCenter.g2D.repaint();		// redraw the layout
				
				break;
			
			/* Fill */
			case 3:
				Boolean currFillValue = (Boolean) data[rowIndex][3]; 
				int layer_No = ((Integer) data[rowIndex][0]).intValue();
				
				if ( currFillValue.booleanValue() == true ) {
					data[rowIndex][3] = new Boolean( false );
					DrawColor.setFill( layer_No, false );
				}
				else {
					data[rowIndex][3] = new Boolean( true );
					DrawColor.setFill( layer_No, true );
				}
					
				DrawLayout.isRedrawImage(true);	// new
				PanelCenter.g2D.repaint();		// redraw the layout
				
				break;
				
			default:
				/* do nothing */
				break;
		}
		

		//fireTableCellUpdated(rowIndex, columnIndex);
	} 
	
	
	public void setLayerInfo(int rowIndex, int columnIndex, boolean value) 
	{
		if (value == true) {
			//System.out.println("Please display layer_no: " + data[rowIndex][0] );
			LayerTableInfo.removeDontDisplayHT( data[rowIndex][0].toString() );
		}
		else {
			//System.out.println("Please do not display layer_no: " + data[rowIndex][0] );
			LayerTableInfo.addDontDisplayHT( data[rowIndex][0].toString() );
		}
		
		DrawLayout.isRedrawImage(true);	// new
		PanelCenter.g2D.repaint();		// redraw the layout
	}


}
