/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Color;
import java.util.Hashtable;
import java.util.Arrays;

import javax.swing.JComboBox;

public class LayerTableInfo {
	
	private static Hashtable 	layerHT; 			/* record the used layers */
	
	//private static Object[]   sorted_layerNo;
	//private static String[]   sorted_layerNo_str;
	//private static int[] 		sorted_layerNo; 
	private static Hashtable 	dontDisplayHT;
	

	public static void addDontDisplayHT( String layer ) 
	{
		dontDisplayHT.put( layer, layer );
	}
	
	
	public static void removeDontDisplayHT( String layer ) 
	{
		dontDisplayHT.remove( layer );
	}
	
	
	public static boolean mayIdisplayLayer( int layer ) 
	{
		if ( dontDisplayHT.contains("" + layer)==true ) {
			return(false);
		}
		return(true);
	}
	
	
	public static void initialize() {
		layerHT = new Hashtable();
		dontDisplayHT = new Hashtable();
	}
	
	
	public static void insert( int layer_num ) {
	
		String layerno = ""+layer_num;
		if ( layerHT.containsKey(layerno) ) {
			return;
		}
		else {		
			layerHT.put( layerno, layerno );
		}		
	}
	
	
	public static void putData() {

		Object[] sorted_layerNo = layerHT.keySet().toArray(); 
		
		putLayerDataToLayerTable( sorted_layerNo );
	}
	
	
	/* put the data */
	public static void putLayerDataToLayerTable( Object[] sorted_layerNo ) {
		
		LayerTable.data = new Object[layerHT.size()][4];								// number of columns = 4
		
		//String[] str_array = new String [layerHT.size()]; 
		int[]    int_array = new int [layerHT.size()];
		
		for (int i=0; i<layerHT.size(); i++) {
			//str_array[i] = (String) sorted_layerNo[i];
			//int_array[i] = Integer.parseInt( str_array[i] );
			int_array[i] = Integer.parseInt( (String) sorted_layerNo[i] );
		}
		
		// sorting (array of layer numbers)
		Arrays.sort( int_array );
		
		for (int i=0; i<layerHT.size(); i++) 
		{
			LayerTable.data[i][0] = new Integer(int_array[i]);							// Column #1: Layer No.
			LayerTable.data[i][1] = Boolean.TRUE;										// Column #2: Display
			LayerColor lc = DrawColor.getColor( int_array[i] );
			float r = (float) lc.getRed()   / (float) 255;
			float g = (float) lc.getGreen() / (float) 255;
			float b = (float) lc.getBlue()  / (float) 255;			
			LayerTable.data[i][2] = new Color( r, g, b);								// Column #3: Layer Color
			LayerTable.data[i][3] = new Boolean( DrawColor.getIsFill(int_array[i]) );	// Column #4: isFill
		}
		
	}
	
	
	public static void updateLayers( JComboBox cbLayer1, JComboBox cbLayer2 ) {
		
		Object sortedLayerNo [] = layerHT.keySet().toArray();
		//String strArray [] = new String [layerHT.size()];
		int    intArray [] = new int [layerHT.size()];
		
		for (int i=0; i<layerHT.size(); i++) {
			intArray[i] = Integer.parseInt( (String) sortedLayerNo[i] );
		}
		
		Arrays.sort( intArray );
		
		for (int i=0; i<layerHT.size(); i++) {
			//System.out.println( intArray[i] );
			cbLayer1.addItem( String.valueOf( intArray[i] ) );
			cbLayer2.addItem( String.valueOf( intArray[i] )  );
		}
		
	}
	

}
