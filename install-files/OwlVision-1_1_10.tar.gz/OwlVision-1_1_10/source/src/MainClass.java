/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */
import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.dnd.DropTarget;
import java.io.*;
import java.util.Arrays;


/*
 * This is the main class of OwlVision GDSII Viewer.
 * Author:  I-Lun Tseng
 * website: http://www.owlvision.com
 * 
 * This file was created on April 02, 2005
 *
 */


/**
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MainClass {
	
	public static GDSII gdsii = null;
	public static DrawLayout g2D;
	protected static JFrameE frame;
	private static String[] arguments;
	public static JInternalFrame intFrame01;  // Layout View
	public static JInternalFrame intFrame02;  // Layer Toggle
	public static JInternalFrame intFrame03;  // Cell Info
	public static JInternalFrame intFrame04;  // Cell Toggle
	public static JScrollPane    intFrame05;  // Console Window
	public static JEditorPane    consoleText;
	public static String productName    = "OwlVision GDSII Viewer";
	public static String productVersion = "1.1.10";
	public static String productWWW     = "http://www.owlvision.org";
	public static String productBuild   = "December 16, 2007";
	public static String consoleMessage;
	private static String openFileDir = null;
	
	private static boolean enableChooseCell = false;
	
	public static ColorEditor colorEditor = new ColorEditor();
	
	private static DropTarget dt;

	public static void main(String[] args) 
	{
		arguments = args;

		//JFrame.setDefaultLookAndFeelDecorated(true);
		
		//Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
               
        // Has argument[0]
        if (arguments.length!=0) {
          new Thread() {
            public void run() {
              try {
        	      //msg("===== Thread =====");
              	  /* wait for JFrame to appear */
        		  Thread.sleep(1000);  
        		  gdsii = new GDSII(arguments[0]);
        		  execute();
        	  } catch (InterruptedException e) { }
            }
          }.start();
        }	// Has argument[0]
        		
	} // end of main()
	
	
	private static void createAndShowGUI() 
	{	
		GDSII.setReady(false);
		//frame = new JFrameE("GDSII Viewer");
		frame = new JFrameE( productName );
		frame.setJMenuBar(new MainMenu());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);
		frame.setLocation(0,0);
		frame.setBackground( SystemColor.window );		/* added on 2006/11/23 */
		
		JDesktopPane jdesktop = new JDesktopPane();
		
		/* ==== Internal Frame 01 ==== */
		intFrame01 = new JInternalFrame("Layout View", true, false, true, true);		
		intFrame01.setLocation(0,0);  // will be changed latter
		intFrame01.setSize(500,400);  // will be changed latter	
		
		DropTarget dt = new DropTarget( intFrame01, new DnDDropListener() );
		
		intFrame01.setVisible(true);
		
		//frame.setContentPane(new PanelAll());
		intFrame01.setContentPane( new PanelAll() );
		jdesktop.add(intFrame01);
		
		/* ==== Internal Frame 02 ==== */
		intFrame02 = new JInternalFrame("Layer", true, false, true, true);
		intFrame02.setLocation(0,0);  // will be changed latter
		intFrame02.setSize(100,100);  // will be changed latter
		intFrame02.setVisible(true);
		/*
		 * See: fireLayerTable()
		 * LayerTable is drawn by this method in this class. 
		 */		       
		jdesktop.add(intFrame02);
		
		/* Internal Frame 03 */
		intFrame03 = new JInternalFrame("Cell Hierarchy", true, false, true, true);
		intFrame03.setLocation(0,0);  // will be changed latter
		intFrame03.setSize(100,100);  // will be changed latter
		intFrame03.setVisible(true);		
		jdesktop.add(intFrame03);
		
		/* Internal Frame 04 */
		intFrame04 = new JInternalFrame("Cell Toggle", true, false, true, true);
		intFrame04.setLocation(0,0);  // will be changed latter
		intFrame04.setSize(100,100);  // will be changed latter
		intFrame04.setVisible(true);		
		jdesktop.add(intFrame04);
		
		/* Console Window */		
		//consoleText = new JTextArea();
		consoleText = new JTextPane();
		//consoleText = new JEditorPane();
		//consoleMessage = productName + " - " + "version: " + productVersion + "\n";		
		consoleMessage =  productName + " version " + productVersion + ", Copyright (C) 2005, 2006, 2007 OwlVision authors\n";
		consoleMessage += productName + " comes with ABSOLUTELY NO WARRANTY.\n";
		consoleMessage += "This is free software, and you are welcome to redistribute it under certain conditions.\n";
		
		consoleText.setText(consoleMessage);
	    intFrame05 = new JScrollPane(consoleText);
		intFrame05.setLocation(0,0);
		intFrame05.setSize(100,100);
		intFrame05.setVisible(true);
		jdesktop.add( intFrame05 );
		
		frame.setContentPane(jdesktop);
		frame.setVisible(true);
	}	
	
	
	/* read GDSII file */
	private static void read_translate_store() 
	{	
		double count = 0;
		UnsupportedGDSIIrecords unsupportedRecords = new UnsupportedGDSIIrecords();
		
		while (GDSII.read_record() != 0) {	
			switch (GDSII.dataInt) {
				case 0x0000:
					/* ignore */
					break;
				case 0x0002:
					GDSIIreadRecords.HEADER(gdsii);
					PanelStatusBar.setProgress(GDSII.progressVal);
					break;
				case 0x0102:
					GDSIIreadRecords.BGNLIB(gdsii);
					break;
				case 0x0206:
					GDSIIreadRecords.LIBNAME(gdsii);
					break;
				case 0x0305:
					GDSIIreadRecords.UNITS(gdsii);
					break;
				case 0x0400:
					GDSIIreadRecords.ENDLIB(gdsii);
					PanelStatusBar.setProgress(GDSII.progressVal);
					break;
				case 0x0502:
					GDSIIreadRecords.BGNSTR(gdsii);
					break;
				case 0x0606:
					GDSIIreadRecords.STRNAME(gdsii);
					break;
				case 0x0700:
					GDSIIreadRecords.ENDSTR(gdsii);
					break;
				case 0x0800:
					GDSIIreadRecords.BOUNDARY(gdsii);
					break;
				case 0x0900:
					GDSIIreadRecords.PATH(gdsii);
					break;
				case 0x0A00:
					GDSIIreadRecords.SREF(gdsii);
					break;
				case 0x0B00:	/* added on 2006/11/09 */
					GDSIIreadRecords.AREF(gdsii);
					break;
				case 0x0C00:
					GDSIIreadRecords.TEXT(gdsii);
					break;
				case 0x0D02:
					GDSIIreadRecords.LAYER(gdsii);
					break;
				case 0x0E02:
					GDSIIreadRecords.DATATYPE(gdsii);
					break;
				case 0x0F03:
					GDSIIreadRecords.WIDTH(gdsii);
					break;
				case 0x1003:
					GDSIIreadRecords.XY(gdsii);
					break;
				case 0x1100:
					GDSIIreadRecords.ENDEL(gdsii);
					break;
				case 0x1206:
					GDSIIreadRecords.SNAME(gdsii);
					break;
				case 0x1302:	/* added on 2006/11/09 */
					GDSIIreadRecords.COLROW(gdsii);
					break;
				case 0x1602:
					GDSIIreadRecords.TEXTTYPE(gdsii);
					break;
				case 0x1701:
					GDSIIreadRecords.PRESENTATION(gdsii);
					break;
				case 0x1906:
					GDSIIreadRecords.STRING(gdsii);
					break;
				case 0x1A01:
					GDSIIreadRecords.STRANS(gdsii);
					break;
				case 0x1B05:
					GDSIIreadRecords.MAG(gdsii);
					break;
				case 0x1C05:
					GDSIIreadRecords.ANGLE(gdsii);
					break;
				case 0x2102:
					GDSIIreadRecords.PATHTYPE(gdsii);
					break;
				case 0x2202:
					GDSIIreadRecords.GENERATIONS(gdsii);
					break;
				case 0x2B02:
					GDSIIreadRecords.PROPATTR(gdsii);
					break;
				case 0x2C06:
					GDSIIreadRecords.PROPVALUE(gdsii);
					break;
				case 0x2D00:
					GDSIIreadRecords.BOX( gdsii );
					break;
				case 0x2E02:
					GDSIIreadRecords.BOXTYPE(gdsii);
					break;
				case 0x3003:	/* BGNEXTN */
					GDSIIreadRecords.BGNEXTN( gdsii );
					break;
				case 0x3103:	/* ENDEXTN */
					GDSIIreadRecords.ENDEXTN( gdsii );
					break;
				default:
					//System.out.println();
					//System.out.println("ERROR: GDSII record type \"" + GDSII.dataStr + "\" is not supported!");
					String HexString = Integer.toHexString( GDSII.dataInt );
            		switch (HexString.length()) {
                		case 1:
                			HexString = "000" + HexString;
                			break;
                		case 2:
                			HexString = "00" + HexString;
                			break;
                		case 3:
                			HexString = "0" + HexString;
                			break;
            		}
            		String recordTypeStr = HexString.toUpperCase();
					//System.out.println("WARNING: GDSII record type \"" + recordTypeStr + "\" is not supported!");
            		//OwlVisionMessages.showConsoleMsg( JOptionPane.WARNING_MESSAGE, 30000, recordTypeStr );
            		unsupportedRecords.showConsoleMsg( recordTypeStr );
					GDSIIreadRecords.SKIPRECORD(gdsii);
					//System.exit(0);
					break;
			}
			
			/* Progress Bar */
			count++;
			if (count%10000 == 0) {
				//System.out.println("count=" + count + ", " + count%10);
				PanelStatusBar.setProgress( GDSII.progressVal );
			}
			
		}		
	}  // END of read_translate_store()
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/10 - initial version
	 */
	public static void setCurrentDir( String dir ) 
	{
		openFileDir = dir;
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/10 - initial version
	 */
	public static String getCurrentDir()
	{
		return( openFileDir );
	}
	
	
	protected static void chooseFile() 
	{
		// use the current directory as the default path
		File file = null;
		JFileChooser chooser;
		
		if ( MainClass.getCurrentDir() == null) {
			chooser = new JFileChooser(".");  // current directory
		}
		else {
			chooser = new JFileChooser( MainClass.getCurrentDir() );  // current directory
		}
		chooser.setFileFilter( new GDSIIFileFilter() );
		
		int result = chooser.showOpenDialog(frame);
		if (result == JFileChooser.CANCEL_OPTION) return;
		try {
			file = chooser.getSelectedFile();
			
			//MainClass.appendConsoleText("Opening file: " + file.getAbsolutePath() + " ....\n" );
			OwlVisionMessages.showConsoleMsg( JOptionPane.INFORMATION_MESSAGE, 20000, file.getAbsolutePath() );
			
			MainClass.setCurrentDir( file.getParent() );  // get the directory of the file
			
			gdsii = new GDSII( file.getAbsolutePath() );
			
			MainMenu.enableFileCloseItem();
		}
		catch (Exception e) {
			System.err.println("Could not open file: " + e);
		}
		
		final SwingWorker worker = new SwingWorker() {
	        public Object construct() {
	            //...code that might take a while to execute is here...
        		
	        	execute();

	            return null;
	        }
	    };
	    worker.start();
		
	}	// chooseFile()
	
	
	protected static void chooseCell( String cellName ) {
			
		if ( enableChooseCell ) {  /* chooseCell() is enabled */
			
			DSbuild.chooseCellReset();
			ToolBar.ZoomFactor = 1;
			DrawLayout.isZoomFactorChanged(true);
			DrawLayout.renewImageSize();
			PanelVBar.set_to_default_position();  // vertical scroll bar
			PanelHBar.set_to_default_position();  // horizontal scroll bar
			
			DSbuild.setSelectedCell( cellName );
			DSbuild.getLayoutSize( cellName );
			MainClass.appendConsoleText("Cell \"" + cellName + "\" was chosen.\n");
			//System.out.println( "selectedCell: "+ DS_build.getSelectedCell() );
			
			final SwingWorker worker = new SwingWorker() {
		        public Object construct() {
		            //...code that might take a while to execute is here...
	        		
		        	executeChooseCell();

		            return null;
		        }
		    };
		    worker.start();		    
		}
	}	// chooseCell()
	
	
	private static void executeChooseCell() {
		
		PanelStatusBar.setProgressBarVisible(true);
				
		SizeSetting.initialize();
		GDSII.setReady(true);
		DrawLayout.isRedrawImage(true);
		PanelCenter.g2D.repaint();
		PanelStatusBar.setProgressBarVisible(false);
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/09 - modified "DSbuild.getLayoutSize()"
	 * 			2006/11/10 - added error handling of missing 'color.txt' file
	 */
	/* read the GDSII file and draw the layout */
	public static void execute() 
	{
		// read the color scheme file 'color.txt'
		DrawColor.read( null );
		
		enableChooseCell = false;
		
		DSbuild.reset();
		LayerTableInfo.initialize();
		CellTableInfo.initialize();
		ToolBar.ZoomFactor = 1;
		DrawLayout.isZoomFactorChanged(true);
		DrawLayout.renewImageSize();
		
		PanelVBar.set_to_default_position();  // vertical scroll bar
		PanelHBar.set_to_default_position();  // horizontal scroll bar
		
        PanelStatusBar.setProgressBarVisible(true);
    	GDSII.setReady(false);
    	
		read_translate_store();		    	// Read the input GDSII file
		
		DSbuild.translatePath2Boundary();	// translate PATH elements into BOUNDARY elements
		
		/* Bounding Box:
		 *   Build cell-level bounding box for each cell.
		 *   Build element-level bounding box for each element.
		 *   Used in "DSbuild.buildQuadTreeStructure()" for building quad trees
		 */
		DSbuild.buildBoundingBoxInfo();
		
		/* Bounding Box for the whole layout:
		 * The information will be used while drawing the layout on the screen.
		 */
		DSbuild.getLayoutSize(null);
		
		//DS_build.buildOverallBoundingBoxInfo();
		
		/* DEBUG routine */
		/*
		BoundingBox bbox = DS_build.getOverallBbox("LAYOUT");
		System.out.println(" bbox: minX: " + bbox.getMinX() );
		System.out.println(" bbox: maxX: " + bbox.getMaxX() );
		System.out.println(" bbox: minY: " + bbox.getMinY() );
		System.out.println(" bbox: maxY: " + bbox.getMaxY() );
		*/
		
		SizeSetting.initialize();
		GDSII.setReady(true);
		DrawLayout.isRedrawImage(true); 
		
		/* ==== Quad Trees ==== */
		
		/* ToDo - should consider STRANS, AREF */
		MainClass.appendConsoleText("Building data structures ...  ");
		
		DSbuild.buildQuadTreeStructure(); 	// build the Quad Tree
		
		MainClass.appendConsoleText("[ OK ]\n");
		
		/* ==== Draw the layout ==== */
		
		PanelCenter.g2D.repaint();		// redraw the layout
		PanelStatusBar.setProgressBarVisible(false);
		MainClass.appendConsoleText("File was opened successfully.\n");
				
		LayerTableInfo.putData();	// add/update contents in intFrame02
		CellTableInfo.putData();
		
		fireupLayerToggle();  // intFrame02
		fireupCellInfo();     // intFrame03
		fireupCellToggle();   // intFrame04
		fireupCellComboBox(); // ComboBox - list of cells
		
		enableChooseCell = true;
	}
	
	
	/* intFrame02 */
	public static void fireupLayerToggle() 
	{
		TableModel tbmodel = new LayerTable();
		JTable jtable = new JTable( tbmodel );
		
		jtable.getColumnModel().getColumn(0).setPreferredWidth(40);  // set column size (Layer No.)
		jtable.getColumnModel().getColumn(1).setPreferredWidth(50);  // set column size (Display)
		jtable.getColumnModel().getColumn(2).setPreferredWidth(50);  // set column size (Color Selection)
		jtable.getColumnModel().getColumn(3).setPreferredWidth(40);  // set column size (Fill)
				
		
		jtable.setDefaultRenderer( Color.class, new ColorRenderer(true) );  // display color
		jtable.setDefaultEditor( Color.class, colorEditor );  		// edit color
				
		
		intFrame02.setContentPane( new JScrollPane(jtable) );
	}
	
	
	/* intFrame03 */
	private static void fireupCellInfo() {
		//TableModel tbmodel = new LayerTable();	
		//JTable jtable = new JTable( tbmodel );
		//MutableTreeNode treeroot = new DefaultMutableTreeNode("Root"); 
		//DefaultTreeModel treemodel = new DefaultTreeModel( treeroot );
		//JTree jtree = new JTree( treemodel );		
		JTree jtree = new JTree( DSbuild.createTreeModel() );
		//intFrame03.setContentPane( new JScrollPane(jtree) );
		
		JScrollPane jScrollPane = new JScrollPane(jtree);
		intFrame03.setContentPane( jScrollPane);
		//jScrollPane.setSize(100, 100);
		//jScrollPane.setVisible(true);
		//intFrame03.getContentPane().add( jScrollPane );
		//intFrame03.setVisible(true);
		//intFrame03.getContentPane().add( new JScrollPane(), BorderLayout.SOUTH );
	} 
	
	
	/* intFrame04 */
	private static void fireupCellToggle() {
		TableModel tbmodel = new CellTable();	
		JTable jtable = new JTable( tbmodel );
		jtable.getColumnModel().getColumn(0).setPreferredWidth(150);  // set column size
		jtable.getColumnModel().getColumn(1).setPreferredWidth(60);  // set column size
		intFrame04.setContentPane( new JScrollPane(jtable) );
	}
	
	
	private static void fireupCellComboBox() {
		
		DSstrNode rootCell;
		int numberOfCells   = DSbuild.strList.getNumber();
		String [] cellNames = new String [numberOfCells-1];
		
		ToolBar.clearComboBox();
		
		if ( DSbuild.strList.getTail().getSrefList().getHead() == null &&
	   		 DSbuild.strList.getHead().getSrefList().getHead() != null ) 
	   	{
	   		rootCell = DSbuild.strList.getHead();
	   	}
	   	else {
	   		rootCell = DSbuild.strList.getTail();
	   	}
		
		int index = 0;
		/* for each cell */
        for (DSstrNode strNode = DSbuild.strList.getHead(); 
             strNode != null; 
             strNode = strNode.getNext() ) 
        {
        	if ( strNode.getName().equals( rootCell.getName() ) == false ) {
        		cellNames[index] = strNode.getName();
        		index++ ;
        	}
        }
        
        Arrays.sort( cellNames );
        
        //ToolBar.addToComboBox( strNode.getName() );
        
        
        ToolBar.addToComboBox( rootCell.getName() );
        
        for (int i = 0; i < numberOfCells-1; i++ ) {
        	ToolBar.addToComboBox( cellNames[i] );
        }
        
        ToolBar.setComboBoxSelectedItem( rootCell.getName() );
		
	}

	public static void appendConsoleText( String string ) {
		MainClass.consoleText.setText( MainClass.consoleText.getText() + string );
	}
	
	public static void msg(Object o) {
		System.out.println(o);
	}


		
} 
