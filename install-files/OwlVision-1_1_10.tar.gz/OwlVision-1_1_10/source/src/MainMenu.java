/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/10
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
//import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;
import java.awt.Dimension;



/**
 * Author:  I-Lun Tseng
 *
 */
public class MainMenu extends JMenuBar {
	
	//private static JCheckBoxMenuItem 	originPoint;
	private static JMenuItem 			fileCloseItem;
	//String[] fileItems = new String[] {"Open", "Exit"};
	//char[]  fileShortcuts = {'O','X'};
	
	/**
	 * Added by Eclipse v3.1
	 */
	private static final long serialVersionUID = 1L;

	public MainMenu() {
		
		
		ActionListener menuItemListener = new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
				/*
				System.out.println("Menu item [" + event.getActionCommand() +
						"] was pressed."); */
				
				/* File --> Open GDSII File */
				if (event.getActionCommand().equals("Open GDSII File ...")) {
					MainClass.chooseFile();
				}
				
				/* File --> Close */
				else if (event.getActionCommand().equals("Close File")) {
					// ToDo: Close the file so that the file can be deleted
					GDSII.closeFile();
					disableFileCloseItem();
					MainClass.appendConsoleText("File was closed.\n");
					//System.exit(0);
				}
				
				/* File --> Save As JPG */
				else if (event.getActionCommand().equals("Save As JPG ...")) 
				{
					file_SaveAsJPG();
				}
				
				/* File --> Save As GIF */
				else if (event.getActionCommand().equals("Save As GIF ...")) 
				{
					file_SaveAsGIF();
				}
				
				/* File --> Open Layer Color Settings ... */
				else if (event.getActionCommand().equals("Open Layer Color Settings ...")) 
				{
					//System.out.println("Open Layer Color Settings ...");
					file_OpenLayerColors();
				}
				
				/* File --> Save Layer Colors ... */
				else if (event.getActionCommand().equals("Save Layer Color Settings ...")) 
				{
					//System.out.println("Save Layer Color Settings ...");
					file_SaveLayerColors();
				}
				
				/* File --> Exit */
				else if (event.getActionCommand().equals("Exit")) {
					System.exit(0);
				}
				
				/* View --> Show Toolbar */
				else if (event.getActionCommand().equals("Show Toolbar")) {
					if ( PanelAll.getToolbarState() == true ) {
						//System.out.println("set to false");
						PanelAll.setToolbarState(false);
						MainClass.appendConsoleText("Toolbar OFF.\n");
					}
					else {
						//System.out.println("set to true");
						PanelAll.setToolbarState(true);
						MainClass.appendConsoleText("Toolbar ON.\n");
					}
					PanelAll.redrawToolbar();
				}
				
				/* View --> Show All */
				else if (event.getActionCommand().equals("Show All")) {
					ToolBar.ZoomFactor = 1;
					PanelHBar.set_to_default_position();
					PanelVBar.set_to_default_position();
					DrawLayout.isZoomFactorChanged(true);
					DrawLayout.renewImageSize();
					PanelCenter.g2D.repaint();
					MainClass.appendConsoleText("Show All.\n");
				}
				
				/* View --> Zoom In */
				else if (event.getActionCommand().equals("Zoom In")) {
					ToolBar.ZoomFactor *= 1.05; 
					DrawLayout.isZoomFactorChanged(true);
					DrawLayout.renewImageSize();
					PanelCenter.g2D.repaint();
					MainClass.appendConsoleText("Zoom In.\n");
				}
				
				/* View --> Zoom Out */
				else if (event.getActionCommand().equals("Zoom Out")) {
					ToolBar.ZoomFactor *= 0.95;
					DrawLayout.isZoomFactorChanged(true);
					DrawLayout.renewImageSize();
					PanelCenter.g2D.repaint();
					MainClass.appendConsoleText("Zoom Out.\n");
				}
				
				/* View --> Zoom Area */
				else if (event.getActionCommand().equals("Zoom Area")) {					
					MainClass.appendConsoleText("Zoom Area: This is not implemented yet.\n");
				}
				
				/* View --> Origin Point */
				else if (event.getActionCommand().equals("Origin Point")) {
					//System.out.println("OriginPoint: " + DrawOriginPoint.getState() );
					if ( DrawOriginPoint.getState() == true ) {
						//System.out.println("set to false");
						DrawOriginPoint.setState(false);
						MainClass.appendConsoleText("Origin point OFF.\n");
					}
					else {
						//System.out.println("set to true");
						DrawOriginPoint.setState(true);
						MainClass.appendConsoleText("Origin point ON.\n");
					}
					PanelCenter.g2D.repaint();
				}
				
				/* View --> Grids */
				else if (event.getActionCommand().equals("Grids")) {
					//System.out.println("Grids: " + DrawGrids.getState() );
					if ( DrawGrids.getState() == true ) {
						//System.out.println("set to false");
						DrawGrids.setState(false);
						MainClass.appendConsoleText("Grids OFF.\n");
					}
					else {
						//System.out.println("set to true");
						DrawGrids.setState(true);
						MainClass.appendConsoleText("Grids ON.\n");
					}
					PanelCenter.g2D.repaint();
				}
				
				/* View --> Boundary elements */
				else if (event.getActionCommand().equals("Boundary elements")) {
					if ( Draw.getIsDrawBoundaryState() == true ) {
						//System.out.println("set to false");
						Draw.setIsDrawBoundaryState(false);
						MainClass.appendConsoleText("View Boundary elements: OFF.\n");
					}
					else {
						//System.out.println("set to true");
						Draw.setIsDrawBoundaryState(true);
						MainClass.appendConsoleText("View Boundary elements: ON.\n");
					}
					DrawLayout.isRedrawImage( true );
					PanelCenter.g2D.repaint();
				}
				
				/* View --> Box elements */
				else if (event.getActionCommand().equals("Box elements")) {
					if ( Draw.getIsDrawBoxState() == true ) {
						//System.out.println("set to false");
						Draw.setIsDrawBoxState(false);
						MainClass.appendConsoleText("View Box elements: OFF.\n");
					}
					else {
						//System.out.println("set to true");
						Draw.setIsDrawBoxState(true);
						MainClass.appendConsoleText("View Box elements: ON.\n");
					}
					DrawLayout.isRedrawImage( true );
					PanelCenter.g2D.repaint();
				}
				
				/* View --> Path elements */
				else if (event.getActionCommand().equals("Path elements")) {
					if ( Draw.getIsDrawPathState() == true ) {
						//System.out.println("set to false");
						Draw.setIsDrawPathState(false);
						MainClass.appendConsoleText("View Path elements: OFF.\n");
					}
					else {
						//System.out.println("set to true");
						Draw.setIsDrawPathState(true);
						MainClass.appendConsoleText("View Path elements: ON.\n");
					}
					DrawLayout.isRedrawImage( true );
					PanelCenter.g2D.repaint();
				}
				
				/* View --> Text elements */
				else if (event.getActionCommand().equals("Text elements")) {
					if ( Draw.getIsDrawTextState() == true ) {
						//System.out.println("set to false");
						Draw.setIsDrawTextState(false);
						MainClass.appendConsoleText("View Text elements: OFF.\n");
					}
					else {
						//System.out.println("set to true");
						Draw.setIsDrawTextState(true);
						MainClass.appendConsoleText("View Text elements: ON.\n");
					}
					DrawLayout.isRedrawImage( true );
					PanelCenter.g2D.repaint();
				}
				
				/* Tools --> Arrange Windows */
				else if (event.getActionCommand().equals("Arrange Windows")) {
					MainClass.frame.arrangeWindows();
				}
				
				/* Tools --> Ruler : Create */
				else if (event.getActionCommand().equals("Ruler : Create")) {
					Ruler.create();
				}
				
				/* Tools --> Ruler : Remove */
				else if (event.getActionCommand().equals("Ruler : Remove")) {
					Ruler.remove();
					PanelCenter.g2D.repaint();
				}
				
				/* Tools --> Boolean Mask Operation ... */
				else if (event.getActionCommand().equals("Boolean Mask Operation ...")) {
					
					booleanMaskOperation();					
				}
				
				/* Translate --> GDSII to ASCII */
				else if (event.getActionCommand().equals("GDSII to ASCII ...")) {
					
					JTextField tfFromFile = new JTextField();
					JTextField tfToFile   = new JTextField();
					String mTitle    = "Please enter the input and output file names.";
					String mFromFile = "From (GDSII) :";
					String mToFile   = "To (ASCII) :";
					String mQuestion = "Perform Translation?";
					String mSpace = "     ";
					JButton bFromFile = new JButton("Browse");
					JButton bToFile = new JButton("Browse");
					Dimension tfSize = new Dimension(650, 28);	// text field size
					Dimension bSize = new Dimension(70, 28);	// button size
					tfFromFile.setPreferredSize(tfSize);
					tfToFile.setPreferredSize(tfSize);
					bFromFile.setPreferredSize(bSize);
					bToFile.setPreferredSize(bSize);
					TranslateFunction.setG2AFromTextField(tfFromFile);
					TranslateFunction.setG2AToTextField(tfToFile);
					
					// FROM FILE
					bFromFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
						JFileChooser fileChooserFrom;
						
						if (MainClass.getCurrentDir() == null) {
							fileChooserFrom = new JFileChooser(".");  // current directory
						}
						else {
							fileChooserFrom = new JFileChooser( MainClass.getCurrentDir() );  // current directory
						}
						
						fileChooserFrom.setFileFilter( new GDSIIFileFilter() );
						int result = fileChooserFrom.showOpenDialog(MainClass.frame);
						if (result == JFileChooser.APPROVE_OPTION) 
						{
							File fileFrom = fileChooserFrom.getSelectedFile();
							MainClass.setCurrentDir( fileFrom.getParent() );
							TranslateFunction.setG2AFromFile( fileFrom );
							//System.out.println("FileName -- " + fileFrom.getAbsolutePath());
							TranslateFunction.getG2AFromFileName();
						}
						//System.out.println("FROM\n");
					} } );
					
					// TO FILE
					bToFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
						JFileChooser fileChooserTo;						
						if (MainClass.getCurrentDir() == null) {
							fileChooserTo = new JFileChooser(".");  // current directory
						}
						else {
							fileChooserTo = new JFileChooser( MainClass.getCurrentDir() );  // current directory
						}						
						
						int result = fileChooserTo.showSaveDialog(MainClass.frame);
						if (result == JFileChooser.APPROVE_OPTION) {
							File fileTo = fileChooserTo.getSelectedFile();
							TranslateFunction.setG2AToFile(fileTo);
							//System.out.println("FileName -- " + fileTo.getAbsolutePath());
							TranslateFunction.getG2AToFileName();
						}
						//System.out.println("TO\n");
					} } );
					
					// GDSII-->ASCII Dialog Box
					int gdsii2ascii_result = 
						JOptionPane.showOptionDialog(MainClass.frame, 
							new Object[] {mTitle, mSpace, mFromFile, tfFromFile, bFromFile, mSpace, mToFile, tfToFile, bToFile, mSpace, mQuestion},
							"Translate GDSII into ASCII", JOptionPane.YES_NO_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null, null, null);
					// click "OK"
					if (gdsii2ascii_result == JOptionPane.OK_OPTION) {
						/* Perform Translation */
						final String myFromFile = tfFromFile.getText();	// inputFileName
						final String myToFile   = tfToFile.getText();	// outputFileName
						
						new Thread() {
							public void run() {
								
								PanelStatusBar.progressBarIndeterminate(true,"GDSII to ASCII");
								
								/* Main Translation Method */
								new GDSII2ASCII_Main( myFromFile, myToFile );
								
								PanelStatusBar.progressBarIndeterminate(false,"");
								JOptionPane.showMessageDialog(MainClass.frame, "GDSII to ASCII translation completed.");
								
							}
						}.start();
						
						/*
						new GDSII2ASCII_Main("" + tfFromFile.getText(),   // inputFileName
								             "" + tfToFile.getText() );   // outputFileName
								             */
						//JOptionPane.showMessageDialog(MainClass.frame, "Translation has been started in the background. Please check the result latter.");
					}
					
					
				}
				
				/* Translate --> ASCII to GDSII */
				else if (event.getActionCommand().equals("ASCII to GDSII ...")) 
				{
					JTextField tfFromFile = new JTextField();
					JTextField tfToFile   = new JTextField();
					String mTitle    = "Please enter the input and output file names.";
					String mFromFile = "From (ASCII) :";
					String mToFile   = "To (GDSII) :";
					String mQuestion = "Perform Translation?";
					String mSpace = "     ";
					JButton bFromFile = new JButton("Browse");
					JButton bToFile = new JButton("Browse");
					Dimension tfSize = new Dimension(650, 28);	// text field size
					Dimension bSize = new Dimension(70, 28);	// button size
					tfFromFile.setPreferredSize(tfSize);
					tfToFile.setPreferredSize(tfSize);
					bFromFile.setPreferredSize(bSize);
					bToFile.setPreferredSize(bSize);
					TranslateFunction.setA2GFromTextField(tfFromFile);
					TranslateFunction.setA2GToTextField(tfToFile);
					
					// FROM FILE
					bFromFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
						JFileChooser fileChooserFrom;
						if (MainClass.getCurrentDir() == null) {
							fileChooserFrom = new JFileChooser(".");  // current directory
						}
						else {
							fileChooserFrom = new JFileChooser( MainClass.getCurrentDir() );  // current directory
						}
						
						int result = fileChooserFrom.showOpenDialog(MainClass.frame);
						if (result == JFileChooser.APPROVE_OPTION) 
						{
							File fileFrom = fileChooserFrom.getSelectedFile();
							MainClass.setCurrentDir( fileFrom.getParent() );
							TranslateFunction.setA2GFromFile(fileFrom);
							//System.out.println("FileName -- " + fileFrom.getAbsolutePath());
							TranslateFunction.getA2GFromFileName();
						}
						//System.out.println("FROM\n");
					} } );
					
					// TO FILE
					bToFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
						JFileChooser fileChooserTo;
						if (MainClass.getCurrentDir() == null) {
							fileChooserTo = new JFileChooser(".");  // current directory
						}
						else {
							fileChooserTo = new JFileChooser( MainClass.getCurrentDir() );  // current directory
						}		
						
						fileChooserTo.setFileFilter( new GDSIIFileFilter() );
						int result = fileChooserTo.showSaveDialog(MainClass.frame);
						if (result == JFileChooser.APPROVE_OPTION) {
							File fileTo = fileChooserTo.getSelectedFile();
							TranslateFunction.setA2GToFile(fileTo);
							//System.out.println("FileName -- " + fileTo.getAbsolutePath());
							TranslateFunction.getA2GToFileName();
						}
						//System.out.println("FROM\n");
					} } );
					
					// ASCII-->GDSII Dislog Box
					int ascii2gdsii_result = 
						JOptionPane.showOptionDialog(MainClass.frame, 
							new Object[] {mTitle, mSpace, mFromFile, tfFromFile, bFromFile, mSpace, mToFile, tfToFile, bToFile, mSpace, mQuestion},
							"Translate ASCII into GDSII", JOptionPane.YES_NO_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null, null, null);	
					// click "OK"
					if (ascii2gdsii_result == JOptionPane.OK_OPTION) {
						/* Perform Translation */
						final String myFromFile = tfFromFile.getText();	// inputFileName
						final String myToFile   = tfToFile.getText();	// outputFileName
						new Thread() {
							public void run() {
								PanelStatusBar.progressBarIndeterminate(true, "ASCII to GDSII");
								/* Main Translation Method */
								ASCII2GDSII.MainMethod( myFromFile, myToFile );
								PanelStatusBar.progressBarIndeterminate(false,"");
								JOptionPane.showMessageDialog(MainClass.frame, "ASCII to GDSII translation completed.");
							}
						}.start();
						//JOptionPane.showMessageDialog(MainClass.frame, "Translation has been started in the background. Please check the result latter.");
					}
				}
				
				/* About - Software Info. */
				else if (event.getActionCommand().equals("About ...")) {
					String html = "<html> <table border=0>"
								  + "<tr><td colspan=2><font face=\"MS Sans Serif\" size=\"5\" color=\"#0000FF\">" + MainClass.productName + "</font></td></tr>"
						          + "<tr><td width=75> <font face=\"Times New Roman\" size=4>  Version: </font></td><td><font face=\"Times New Roman\" size=4>" + MainClass.productVersion + "</font></td></tr>"
						          + "<tr><td width=75> <font face=\"Times New Roman\" size=4>  Build:   </font></td><td><font face=\"Times New Roman\" size=4>" + MainClass.productBuild + "</font></td></tr>"
						          + "<tr><td width=75> <font face=\"Times New Roman\" size=4>  Author:  </font></td><td><font face=\"Times New Roman\" size=4> I-Lun Tseng </font></td></tr>"
						          + "<tr><td width=75> <font face=\"Times New Roman\" size=4>  Website: </font></td><td><font face=\"Times New Roman\" size=4>" + MainClass.productWWW + "     </font></td></tr>"
								  + "<tr><td width=75> <font face=\"Times New Roman\" size=4>  E-mail: </font></td><td><font face=\"Times New Roman\" size=4>" + "info@owlvision.org" + "</font></td></tr>";
								
					
					JLabel label = new JLabel( html );
					JOptionPane.showOptionDialog(MainClass.frame, 
							new Object[] {label},
							"About OwlVision", JOptionPane.DEFAULT_OPTION,
							JOptionPane.INFORMATION_MESSAGE,
							null, null, null);
				}
			}
		}; 
		
		
		/* ================== */
		/* ==  MENU ITEMS  == */
		/* ================== */
		
		
		/* ==== File ==== */
		JMenu fileMenu = new JMenu("File");
		//fileMenu.setEnabled(false);
		
		/* File --> Open */
		JMenuItem openItem = new JMenuItem("Open GDSII File ...", 'O');
		openItem.addActionListener( menuItemListener );
		fileMenu.add(openItem);
		
		/* File --> Close */
		fileCloseItem = new JMenuItem("Close File", 'C');
		fileCloseItem.addActionListener( menuItemListener );
		fileMenu.add(fileCloseItem);
		fileCloseItem.setEnabled(false);
		
		/* File --> separator */
		fileMenu.addSeparator();
		
		/* File --> Save As JPG ... */
		JMenuItem saveJPGitem = new JMenuItem("Save As JPG ...", 'J');
		saveJPGitem.addActionListener( menuItemListener );
		fileMenu.add(saveJPGitem);
		
		/* File --> Save As GIF ... */
		JMenuItem saveGIFitem = new JMenuItem("Save As GIF ...", 'G');
		saveGIFitem.addActionListener( menuItemListener );
		fileMenu.add(saveGIFitem);
		
		/* File --> separator */
		fileMenu.addSeparator();
		
		/* File --> Open Layer Color Settings ... */
		JMenuItem openLayerColors = new JMenuItem("Open Layer Color Settings ...", 'L');
		openLayerColors.addActionListener( menuItemListener );
		fileMenu.add( openLayerColors );
		
		/* File --> Save Layer Color Settings ... */
		JMenuItem saveLayerColors = new JMenuItem("Save Layer Color Settings ...", 'S');
		saveLayerColors.addActionListener( menuItemListener );
		fileMenu.add( saveLayerColors );
		
		/* File --> separator */
		fileMenu.addSeparator();
		
		/* File --> Exit */
		JMenuItem exitItem = new JMenuItem("Exit", 'X');
		exitItem.addActionListener( menuItemListener );
		fileMenu.add(exitItem);
				
		add(fileMenu);
		
		
		/* ==== View ==== */
		JMenu viewMenu;
		viewMenu = new JMenu("View");
		
		/* View --> Toolbar */
		JCheckBoxMenuItem showToolbarItem;
		showToolbarItem = new JCheckBoxMenuItem("Show Toolbar");
		showToolbarItem.addActionListener( menuItemListener );
		showToolbarItem.setState(true);
		viewMenu.add(showToolbarItem);
		
		/* View --> separator */
		viewMenu.addSeparator();
		
		/* View --> Show All */
		JMenuItem showAllItem;
		showAllItem = new JMenuItem("Show All", 'S');
		showAllItem.addActionListener( menuItemListener );
		viewMenu.add(showAllItem);
		
		/* View --> Zoom In */
		JMenuItem zoomInItem;
		zoomInItem = new JMenuItem("Zoom In", 'I');
		zoomInItem.addActionListener( menuItemListener );
		viewMenu.add(zoomInItem);
		
		/* View --> Zoom Out */
		JMenuItem zoomOutItem;
		zoomOutItem = new JMenuItem("Zoom Out", 'O');
		zoomOutItem.addActionListener( menuItemListener );
		viewMenu.add(zoomOutItem);
		
		/* View --> Zoom Area */
		JMenuItem zoomAreaItem; 
		zoomAreaItem = new JMenuItem("Zoom Area", 'A');
		zoomAreaItem.addActionListener( menuItemListener );
		viewMenu.add(zoomAreaItem);
		
		/* View --> separator */
		viewMenu.addSeparator();
		
		/* View --> Origin Point */
		JCheckBoxMenuItem originPointItem; 
		originPointItem = new JCheckBoxMenuItem("Origin Point");
		originPointItem.addActionListener( menuItemListener );
		originPointItem.setState(true);
		DrawOriginPoint.setState(true);
		viewMenu.add(originPointItem);
		
		/* View --> Grids */
		JCheckBoxMenuItem gridPointsItem;
		gridPointsItem = new JCheckBoxMenuItem("Grids");
		gridPointsItem.addActionListener( menuItemListener );
		gridPointsItem.setState(true);
		DrawGrids.setState(true);
		viewMenu.add( gridPointsItem );
		
		/* View --> separator */
		viewMenu.addSeparator();
		
		/* View --> showBoundary */
		JCheckBoxMenuItem showBoundaryItem;
		showBoundaryItem = new JCheckBoxMenuItem("Boundary elements");
		showBoundaryItem.addActionListener( menuItemListener );
		showBoundaryItem.setState(true);
		Draw.setIsDrawBoundaryState(true);
		viewMenu.add( showBoundaryItem );
		
		/* View --> showBox */
		JCheckBoxMenuItem showBoxItem;
		showBoxItem = new JCheckBoxMenuItem("Box elements");
		showBoxItem.addActionListener( menuItemListener );
		showBoxItem.setState(true);
		Draw.setIsDrawBoxState(true);
		viewMenu.add( showBoxItem );
		
		/* View --> showPath */
		JCheckBoxMenuItem showPathItem;
		showPathItem = new JCheckBoxMenuItem("Path elements");
		showPathItem.addActionListener( menuItemListener );
		showPathItem.setState(true);
		Draw.setIsDrawPathState(true);
		viewMenu.add( showPathItem );
		
		/* View --> showText */
		JCheckBoxMenuItem showTextItem;
		showTextItem = new JCheckBoxMenuItem("Text elements");
		showTextItem.addActionListener( menuItemListener );
		showTextItem.setState(true);
		Draw.setIsDrawTextState(true);
		viewMenu.add( showTextItem );
				
		add(viewMenu);
		
		
		/* ==== Tools ==== */
		JMenu toolsMenu = new JMenu("Tools");
		
		/* Tools --> Arrange Windows */
		JMenuItem arrangewinItem = new JMenuItem("Arrange Windows", 'A');
		arrangewinItem.addActionListener(menuItemListener);
		toolsMenu.add(arrangewinItem);
		
		/* Tools --> separator */
		toolsMenu.addSeparator();
		
		/* Tools --> Create Ruler */
		JMenuItem rulerCreate = new JMenuItem("Ruler : Create", 'C');
		rulerCreate.addActionListener(menuItemListener);
		toolsMenu.add(rulerCreate);
		
		/* Tools --> Remove Ruler */
		JMenuItem rulerRemove = new JMenuItem("Ruler : Remove", 'R');
		rulerRemove.addActionListener(menuItemListener);
		toolsMenu.add(rulerRemove);
		
		/* Tools --> separator */
		toolsMenu.addSeparator();
		
		/* Tools --> Boolean Mask Operation */
		JMenuItem booleanOp = new JMenuItem("Boolean Mask Operation ...", 'B');
		booleanOp.addActionListener(menuItemListener);
		toolsMenu.add( booleanOp );
		
		/* Tools --> separator */
		toolsMenu.addSeparator();
		
		/* Tools --> Options */
		JMenuItem optionsItem = new JMenuItem("Options...", 'O');
		optionsItem.addActionListener(menuItemListener);
		toolsMenu.add(optionsItem);
		
		optionsItem.setEnabled(false);
		add(toolsMenu);
		
		
		/* ==== Translate ==== */
		JMenu translateMenu = new JMenu("Translate");
		
		/* Translate --> GDSII to ASCII*/
		JMenuItem g2aItem = new JMenuItem("GDSII to ASCII ...", 'G');
		translateMenu.add(g2aItem);
		g2aItem.addActionListener(menuItemListener);
		JMenuItem a2gItem = new JMenuItem("ASCII to GDSII ...", 'A');
		a2gItem.addActionListener(menuItemListener);
		translateMenu.add(a2gItem);
		
		add(translateMenu);
		
		
		/* ==== Help ==== */
		JMenu helpMenu = new JMenu("Help");
		
		/* Help --> About ... */
		JMenuItem aboutItem = new JMenuItem("About ...", 'A');
		aboutItem.addActionListener(menuItemListener);
		helpMenu.add(aboutItem);
		
		add(helpMenu);
	}
	
	
	public static void enableFileCloseItem() {
		fileCloseItem.setEnabled( true );
	}
	
	
	public static void disableFileCloseItem() {
		fileCloseItem.setEnabled( false );
	}
	
	
	/* Boolean Mask Operation */
	private static void booleanMaskOperation() {
		
		//System.out.println("Boolean Mask Operation ...");
		
		if (!GDSII.isReady()) {       
			OwlVisionMessages.showConsoleMsg( JOptionPane.INFORMATION_MESSAGE, 10020, "");
        	return;
        }
		
		Dimension tfSize = new Dimension(650, 28);	// text field size
		Dimension bSize = new Dimension(70, 28);	// button size
		
		/* INPUT */
		String mInput  = "<html><font color=red size=4>Input";
		String mLayer1 = "Layer Number: ";
		JComboBox cbLayer1 = new JComboBox();
		String mOp     = "Boolean Operation: ";
		JComboBox cbOp = new JComboBox();
		cbOp.addItem("AND");
		//cbOp.addItem("OR");
		//cbOp.addItem("NOT");
		//cbOp.addItem("XOR");
		String mLayer2 = "Layer Number: ";
		JComboBox cbLayer2 = new JComboBox();
		String mSpace = "     ";
		/* OUTPUT */
		String mOutput  = "<html><font color=red size=4>Output";
		String mOFileName = "File Name: ";
		JTextField tfToFile   = new JTextField();
		tfToFile.setPreferredSize(tfSize);
		tfToFile.setText("Boolean.gds");  /* default output file name */
		
		JButton bToFile = new JButton("Browse");
		bToFile.setPreferredSize(bSize);
		String mLayer3 = "Layer Number (0~255): ";
		JTextField tfToLayerNo = new JTextField();
		tfToLayerNo.setPreferredSize(tfSize);
		tfToLayerNo.setText("99");	/* default output layer */					
		BooleanMaskOperation.setToTextField( tfToFile );
		
		/* set used layers */
		LayerTableInfo.updateLayers( cbLayer1, cbLayer2 );
		
		// TO FILE
		bToFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
			JFileChooser fileChooserTo;						
			if (MainClass.getCurrentDir() == null) {
				fileChooserTo = new JFileChooser(".");  // current directory
			}
			else {
				fileChooserTo = new JFileChooser( MainClass.getCurrentDir() );  // current directory
			}						
			
			int result = fileChooserTo.showSaveDialog(MainClass.frame);
			if (result == JFileChooser.APPROVE_OPTION) {
				File fileTo = fileChooserTo.getSelectedFile();
				BooleanMaskOperation.setToFile( fileTo );
				BooleanMaskOperation.getToFile();
				
			}
		} } );
		
		/* Dialog Box (Boolean Mask Operation) */
		int isPerformBooleanMaskOperation = 
		JOptionPane.showOptionDialog(MainClass.frame, 
				new Object[] {mInput, mLayer1, cbLayer1, mOp, cbOp, mLayer2, cbLayer2, mSpace, mOutput, mOFileName, tfToFile, bToFile, mLayer3, tfToLayerNo, mSpace},
				"Boolean Mask Operation", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null, null, null);
		
		/* Perform Boolean Operation */
		if ( isPerformBooleanMaskOperation == JOptionPane.OK_OPTION ) {
			
			BooleanMaskOperation.setLayer1( (String)cbLayer1.getSelectedItem() );
			BooleanMaskOperation.setLayer2( (String)cbLayer2.getSelectedItem() );
			BooleanMaskOperation.setOpType( (String)cbOp.getSelectedItem() );
			
			BooleanMaskOperation.setOutputFileName( tfToFile.getText() );
			BooleanMaskOperation.setOutputLayer( tfToLayerNo.getText() );
			
			/* carry out the Boolean operation */
			BooleanMaskOperation.performBoolean();
		}
		
	}
	
	
	/* File --> Save As JPG */
	private static void file_SaveAsJPG() {
		
		String mTitle  = "Please enter the desired image size and output file name.";
		String mSpace  = "     ";
		String mImageW = "Image Width (1~1200 pixels):";
		JTextField tfImageW = new JTextField();
		tfImageW.setText("800");	// default value
		String mImageH = "Image Height (1~1200 pixels):";
		JTextField tfImageH = new JTextField();
		tfImageH.setText("800");	// default value
		String mFileName = "Output File Name:";
		final JTextField tfFileName = new JTextField();
		
		File fileJPG = new File("layout.JPG");  // default JPG file name
		tfFileName.setText( fileJPG.getAbsolutePath() );
		
		JButton bToFileBrowse = new JButton("Browse");
				
		
		// Browse files and directories
		bToFileBrowse.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
			JFileChooser fileChooser;						
			if ( MainClass.getCurrentDir() == null) {
				fileChooser = new JFileChooser(".");  // current directory
			}
			else {
				fileChooser = new JFileChooser( MainClass.getCurrentDir() );  // current directory
			}
			
			int result = fileChooser.showSaveDialog(MainClass.frame);
			if (result == JFileChooser.APPROVE_OPTION) {
				File fileGIF = fileChooser.getSelectedFile();
				final String fn = fileGIF.getAbsolutePath();
				tfFileName.setText( fn );
			}
			//System.out.println("TO\n");
		} } );
							
		int saveAsJPG_result = 
			JOptionPane.showOptionDialog(MainClass.frame, 
				new Object[] {mTitle, mSpace, mImageW, tfImageW, mImageH, tfImageH, mSpace, mFileName, tfFileName, bToFileBrowse, mSpace },
				"Save as JPG", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null, null, null);
							
		if ( saveAsJPG_result==JOptionPane.OK_OPTION ) 
		{
			fileJPG = new File( tfFileName.getText() );
			
			//System.out.println("==> " + fileJPG.getAbsolutePath() );
			
			SaveAsJPG.save( fileJPG, 	// file
							Integer.parseInt( tfImageW.getText()), 		// image Width
							Integer.parseInt( tfImageH.getText()) );	// image height
			
			//JOptionPane.showMessageDialog( MainClass.frame, "File '" + fileJPG.getAbsolutePath() + "' was saved.");
			
			JOptionPane.showMessageDialog( 	MainClass.frame, 
											"File '" + fileJPG.getAbsolutePath() + "' was saved.", 
											"Completed", 			// title of the message dialog box
											JOptionPane.INFORMATION_MESSAGE );
			
		}
		
	}
	
	
	/* File --> Save As GIF */
	private static void file_SaveAsGIF() 
	{
		String mTitle  = "Please enter the desired image size and output file name.";
		String mSpace  = "     ";
		String mImageW = "Image Width (1~1200 pixels):";
		JTextField tfImageW = new JTextField();
		tfImageW.setText("800");	// default value
		String mImageH = "Image Height (1~1200 pixels):";
		JTextField tfImageH = new JTextField();
		tfImageH.setText("800");	// default value
		String mFileName = "Output File Name:";
		final JTextField tfFileName = new JTextField();
		
		File fileGIF = new File("layout.GIF");  // default GIF file name		
		tfFileName.setText( fileGIF.getAbsolutePath() );
		
		JButton bToFileBrowse = new JButton("Browse");
		
		// Browse files and directories
		bToFileBrowse.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) {
			JFileChooser fileChooser;						
			if (MainClass.getCurrentDir() == null) {
				fileChooser = new JFileChooser(".");  // current directory
			}
			else {
				fileChooser = new JFileChooser( MainClass.getCurrentDir() );  // current directory
			}												
			int result = fileChooser.showSaveDialog(MainClass.frame);
			if (result == JFileChooser.APPROVE_OPTION) {
				File fileGIF = fileChooser.getSelectedFile();
				final String fn = fileGIF.getAbsolutePath();
				tfFileName.setText( fn );
			}
			//System.out.println("TO\n");
		} } );
				
		int saveAsGIF_result = 
			JOptionPane.showOptionDialog(MainClass.frame, 
				new Object[] {mTitle, mSpace, mImageW, tfImageW, mImageH, tfImageH, mSpace, mFileName, tfFileName, bToFileBrowse, mSpace },
				"Save as GIF", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null, null, null);
				
		if ( saveAsGIF_result==JOptionPane.OK_OPTION )
		{
			fileGIF = new File( tfFileName.getText() );
			SaveAsGIF.save( fileGIF, 	// file
							Integer.parseInt( tfImageW.getText()), 		// image Width
							Integer.parseInt( tfImageH.getText()) );	// image height
			
			//JOptionPane.showMessageDialog( MainClass.frame, "File '" + fileGIF.getAbsolutePath() + "' was saved.");
			
			JOptionPane.showMessageDialog( 	MainClass.frame, 
											"File '" + fileGIF.getAbsolutePath() + "' was saved.", 
											"Completed", 			// title of the message dialog box
											JOptionPane.INFORMATION_MESSAGE );
			
		}
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/24 - initial version
	 */
	private static void file_OpenLayerColors()
	{
		String mTitle    = "Please enter the file name.";
		String mSpace = "     ";
		final JTextField tfFromFile   = new JTextField();
		Dimension tfSize = new Dimension(650, 28);	// text field size
		tfFromFile.setPreferredSize(tfSize);
		JButton bFromFile = new JButton("Browse");
		Dimension bSize = new Dimension(70, 28);	// button size
		bFromFile.setPreferredSize(bSize);	
		
		/* FROM FILE */
		bFromFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) 
		{
			JFileChooser fileChooserTo;						
			if (MainClass.getCurrentDir() == null) {
				fileChooserTo = new JFileChooser(".");  // current directory
			}
			else {
				fileChooserTo = new JFileChooser( MainClass.getCurrentDir() );  // current directory
			}						
			
			int result = fileChooserTo.showOpenDialog( MainClass.frame );
			if (result == JFileChooser.APPROVE_OPTION) 
			{
				File fileFrom = fileChooserTo.getSelectedFile();
				
				String filePathName = "" + fileFrom.getAbsolutePath();				
				tfFromFile.setText( filePathName );
			}
		} } );
		
		
		/* Dialog Box */
		int openLayerColors_Result = JOptionPane.showOptionDialog( MainClass.frame, 
							new Object[] {mTitle, mSpace, tfFromFile, bFromFile, mSpace },
							"Open Layer Color Settings", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null, null, null);
		
		if ( openLayerColors_Result == JOptionPane.OK_OPTION ) 
		{
			//System.out.println("" + tfFromFile.getText() );
			//File fileFrom = new File( tfFromFile.getText() );
			
			DrawColor.read( tfFromFile.getText() );
			
			LayerTableInfo.putData();		// add/update contents in MainClass.intFrame02
			MainClass.fireupLayerToggle();  // MainClass.intFrame02
			DrawLayout.isRedrawImage(true);	// new
			PanelCenter.g2D.repaint();		// redraw the layout
		}		
	}  // END of file_OpenLayerColors()
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/21 - initial version
	 */
	private static void file_SaveLayerColors()
	{
		if ( GDSII.isReady() == false ) {
			/* If a GDSII file has not been opened (thus no layer color data), use default layer color values. */			
			DrawColor.read( null );
			//JOptionPane.showMessageDialog( MainClass.frame, "There is no layer color settings at the moment.", "ERROR", JOptionPane.ERROR_MESSAGE );
        	//return;
        }
		
		String defaultFileName = "color.txt";
		String gdsiiFileName = GDSII.getFileName();
		String layerColorSettingsFileName;
		
		if ( gdsiiFileName == null ) {
			layerColorSettingsFileName = defaultFileName;
		}
		else {
			layerColorSettingsFileName = gdsiiFileName + ".owl";
		}
		
		
		String mTitle    = "Please enter the file name.";
		String mSpace = "     ";
		final JTextField tfToFile   = new JTextField();
		Dimension tfSize = new Dimension(650, 28);	// text field size
		tfToFile.setPreferredSize(tfSize);
		JButton bToFile = new JButton("Browse");
		Dimension bSize = new Dimension(70, 28);	// button size
		bToFile.setPreferredSize(bSize);
		
		//File toFileColor = new File("color.txt"); 
		File toFileColor = new File( layerColorSettingsFileName );
		tfToFile.setText( "" + toFileColor.getAbsolutePath() );
		
		/* TO FILE */
		bToFile.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent ae) 
		{
			JFileChooser fileChooserTo;						
			if (MainClass.getCurrentDir() == null) {
				fileChooserTo = new JFileChooser(".");  // current directory
			}
			else {
				fileChooserTo = new JFileChooser( MainClass.getCurrentDir() );  // current directory
			}						
			
			int result = fileChooserTo.showSaveDialog(MainClass.frame);
			if (result == JFileChooser.APPROVE_OPTION) 
			{
				File fileTo = fileChooserTo.getSelectedFile();
				
				String filePathName = "" + fileTo.getAbsolutePath();				
				tfToFile.setText( filePathName );
			}
			//System.out.println("TO\n");
		} } );
		
		
		/* Dialog Box */
		int saveLayerColors_Result = JOptionPane.showOptionDialog( MainClass.frame, 
							new Object[] {mTitle, mSpace, tfToFile, bToFile, mSpace },
							"Save Layer Color Settings", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null, null, null);
		
		
		if ( saveLayerColors_Result == JOptionPane.OK_OPTION ) 
		{
			toFileColor = new File( tfToFile.getText() );
			//String filePathName = tfToFile.getText();			
			//System.out.println( "Save: " + filePathName );
			
			FileOutputStream 		outputFileStream;
			BufferedOutputStream 	outputFileStream_b;
			PrintStream 			printStream;
			
			try {
				outputFileStream = new FileOutputStream( toFileColor );
				outputFileStream_b = new BufferedOutputStream( outputFileStream );
				printStream = new PrintStream(outputFileStream_b);
				
				/* comment lines */
				printStream.println("# This file is intended for use by OwlVision GDSII Viewer - version " + MainClass.productVersion + ".");
				printStream.println("# This file contains settings for presentation of different layers (eg. color and fill).");
				printStream.println("# ");
				printStream.println("# ================================================");
				printStream.println("# layer_number  Red   Green    Blue   Alpha  fill");
				printStream.println("# ================================================");
				
				/* write layer color data into the nominated file */
				DrawColor.saveAsColorSettings( printStream );
				
				printStream.close();
				outputFileStream_b.close();
				outputFileStream.close();
				
			} catch (FileNotFoundException e) {
				/* File Not Found */
				String errorMsg = "The file was not found.";
				JOptionPane.showMessageDialog( MainClass.frame, errorMsg, "ERROR", JOptionPane.ERROR_MESSAGE );
			} catch (IOException e) {
				// TODO Auto-generated catch block
			}
			
		}
		
		
	}
	
	

}
