/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.util.Iterator;
import java.util.LinkedList;

/*  The region-finding procedures
 * 
 *  Procedures (Methods) in this class are related to the following paper:
 *  
 *        J. Nievergelt and F. P. Preparata
 *        "Plane-Sweep Algorithms for Intersecting Geometric Figures"
 *        Communications of the ACM, 
 *        October 1982, vol 25, no. 10
 *        pp. 739-747
 */

public class Nievergelt {

	
	/* case "START"
	 *                 nodeP
	 *                  /\
	 *                 /  \
	 *                /    \
	 *        tEdge  /      \  sEdge
	 *              /        \
	 *             /          \
	 */
	public static void caseStart( 	DSxyDNode 			nodeP, 
									DSsearchTree 		rStr, 
									DSxySearchTreeNode 	currNode )
	{
		int scanLinePosX = currNode.getX();
		int scanLinePosY = currNode.getY();
		
		DSxyDNode	sEdge, tEdge;
		
		int compare_result = Nievergelt.compare( nodeP.getPrev(), nodeP, scanLinePosX, scanLinePosY );
		
		if ( compare_result < 0 ) {
			sEdge = nodeP;
			tEdge = nodeP.getPrev();
		}
		else {
			sEdge = nodeP.getPrev();
			tEdge = nodeP;
		}
		
		//System.out.println();
		
		DSsearchTreeNode	sNewEdge, tNewEdge;
		
		sNewEdge = rStr.insert( sEdge, scanLinePosX, scanLinePosY );  // insert the s edge into "R"
		tNewEdge = rStr.insert( tEdge, scanLinePosX, scanLinePosY );  // insert the t edge into "R"
		
		//DSsearchTreeNode hEdge = sNewEdge.getRightNeighbor( rStr, scanLinePosX, scanLinePosY );
		//DSsearchTreeNode lEdge = tNewEdge.getLeftNeighbor( rStr, scanLinePosX, scanLinePosY );
		
		sNewEdge.getData().insertAboveHead( nodeP );
		DEBUG_dumpRegion( sNewEdge.getData().getAboveRegion() );
		
		sNewEdge.getData().insertBelowTail( nodeP );
		DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );
		
		tNewEdge.getData().insertAboveHead( nodeP );
		DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );
		
		tNewEdge.getData().insertBelowTail( nodeP );
		DEBUG_dumpRegion( tNewEdge.getData().getBelowRegion() );
		
	}
	
	
	/* case "BEND"
	 *              \  
	 *               \
	 *        sEdge   \
	 *                 \
	 *                  \ 
	 *                   o nodeP 
	 *                  / 
	 *                 /  
	 *                /    
	 *        tEdge  /      
	 *              /                 
	 */
	public static void caseBend(	DSxyDNode 			nodeP, 
									DSsearchTree 		rStr, 
									DSxySearchTreeNode 	currNode )
	{
		int scanLinePosX = currNode.getX();
		int scanLinePosY = currNode.getY();

		DSxyDNode	sEdge, tEdge;

		//int compare_result = Nievergelt.compare( nodeP.getPrev(), nodeP, scanLinePosX, scanLinePosY );

		if ( nodeP.getX()==scanLinePosX && nodeP.getY()==scanLinePosY &&  
			 BooleanMaskOperation.scanLineOrderCompare( nodeP, nodeP.getNext() ) > 0 ) 
		{
			sEdge = nodeP.getPrev();
			tEdge = nodeP;
		}
		else {
			sEdge = nodeP;
			tEdge = nodeP.getPrev();
		}

		//System.out.println();

		DSsearchTreeNode	sNewEdge, tNewEdge;
		sNewEdge = rStr.find( sEdge );
		
		/* remove sEdge from "R" */
		rStr.remove( sEdge, scanLinePosX, scanLinePosY );
	
		/* insert tEdge */
		tNewEdge = rStr.insert( tEdge, scanLinePosX, scanLinePosY );  // insert the t edge into "R"

		
		/* === top-down === */		
		if ( BooleanMaskOperation.scanLineOrderCompare( nodeP, nodeP.getNext() ) > 0 ) 
		{
			sNewEdge.getData().insertAboveHead( nodeP );
			DEBUG_dumpRegion( sNewEdge.getData().getAboveRegion() );
		
			sNewEdge.getData().insertBelowTail( nodeP );
			DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );
		
			tNewEdge.getData().setAboveRegion( sNewEdge.getData().getAboveRegion() );
			DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );
		
			tNewEdge.getData().setBelowRegion( sNewEdge.getData().getBelowRegion() );
			DEBUG_dumpRegion( tNewEdge.getData().getBelowRegion() );
		}
		/* === bottom-up === */	
		else {
			sNewEdge.getData().insertAboveTail( nodeP );
			DEBUG_dumpRegion( sNewEdge.getData().getAboveRegion() );
		
			sNewEdge.getData().insertBelowHead( nodeP );
			DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );
		
			tNewEdge.getData().setAboveRegion( sNewEdge.getData().getAboveRegion() );
			DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );
		
			tNewEdge.getData().setBelowRegion( sNewEdge.getData().getBelowRegion() );
			DEBUG_dumpRegion( tNewEdge.getData().getBelowRegion() );
		}		
	}
	
	
	/* case "END"  
	 *                 \          /
	 *                  \        /
	 *            tEdge  \      /  sEdge
	 *                    \    / 
	 *                     \  /
	 *                      \/
	 *                     nodeP
	 */
	public static void caseEnd( 	DSxyDNode 			nodeP, 
									DSsearchTree 		rStr, 
									DSxySearchTreeNode 	currNode )
	{
		int scanLinePosX = currNode.getX();
		int scanLinePosY = currNode.getY();

		DSxyDNode	sEdge, tEdge;

		int compare_result = Nievergelt.compare( nodeP.getPrev(), nodeP, scanLinePosX, scanLinePosY );

		if ( compare_result < 0 ) {
			sEdge = nodeP;
			tEdge = nodeP.getPrev();
		}
		else {
			sEdge = nodeP.getPrev();
			tEdge = nodeP;
		}

		//System.out.println();
		
		DSsearchTreeNode  sNewEdge = rStr.find( sEdge );
		DSsearchTreeNode  tNewEdge = rStr.find( tEdge );
		
		//sNewEdge.getData().insertBelowRegion( nodeP );
		//tNewEdge.getData().insertBelowRegion( nodeP );

		
		/* the sEdge is top-down */
		if ( Nievergelt.compare( sEdge, sEdge.getNext(), scanLinePosX, scanLinePosY) > 0 ) 
		{
			DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );
			sNewEdge.getData().insertBelowTail( nodeP );
			DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );			
			DEBUG_dumpRegion( tNewEdge.getData().getBelowRegion() );
			sNewEdge.getData().insertBelowTail( tNewEdge.getData().getBelowRegion() );
			DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );
			tNewEdge.getData().setBelowRegion( sNewEdge.getData().getBelowRegion() );
			DEBUG_dumpRegion( tNewEdge.getData().getBelowRegion() );
			
			DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );
			tNewEdge.getData().insertAboveTail( nodeP );
			DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );		
			DEBUG_dumpRegion( sNewEdge.getData().getAboveRegion() );
			tNewEdge.getData().insertAboveTail( sNewEdge.getData().getAboveRegion() );
			DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );
			sNewEdge.getData().setAboveRegion( tNewEdge.getData().getAboveRegion() );
			DEBUG_dumpRegion( sNewEdge.getData().getAboveRegion() );
		}
		/* the sEdge is bottom-up */
		else {
			
		}
		
		//DEBUG_dumpRegion( sNewEdge.getData().getAboveRegion() );
		//DEBUG_dumpRegion( sNewEdge.getData().getBelowRegion() );
		//DEBUG_dumpRegion( tNewEdge.getData().getAboveRegion() );
		//DEBUG_dumpRegion( tNewEdge.getData().getBelowRegion() );
		
		
		rStr.remove( sEdge, scanLinePosX, scanLinePosY );
		rStr.remove( tEdge, scanLinePosX, scanLinePosY );
	}
	
	
	private static void DEBUG_dumpRegion( LinkedList list ) {
		
		System.out.println("    ----------");
		
		Iterator it = list.listIterator();
		
		while( it.hasNext() )
		{
			DSxyDNode node = (DSxyDNode) it.next();
			
			System.out.println("    => (" + node.getX() + "," + node.getY() + ")" );						
		}
		
		System.out.println("    ----------");
		
	}
	
				
	/* copied from DSsearchTreeData.compare() */	
	public static int compare( DSxyDNode edge1node, DSxyDNode edge2node, int scanLinePosX, int scanLinePosY ) {
		// DSsearchTreeData d = data;
		
		/* node --> edge1node */
		/* data.getNode() --> edge2node */
		
		double xPos1 = findIntersectionWithScanLine( edge1node, scanLinePosX, scanLinePosY );
		double xPos2 = findIntersectionWithScanLine( edge2node, scanLinePosX, scanLinePosY );
		
		if ( (xPos1 == xPos2) || Math.abs(xPos1-xPos2)<10  ) {  /* considered equal if the difference is very small */
			double m1 = Utilities.calculateSlope( edge1node.getX(), edge1node.getY(), edge1node.getNext().getX(), edge1node.getNext().getY() );
			double m2 = Utilities.calculateSlope( edge2node.getX(), edge2node.getY(), edge2node.getNext().getX(), edge2node.getNext().getY() );
			
			/* test if both edges are above the scan line */
			if ( edge1node.getY()>=scanLinePosY && edge1node.getNext().getY()>=scanLinePosY &&
				 edge2node.getY()>=scanLinePosY && edge2node.getNext().getY()>=scanLinePosY && edge2node.getY()!=edge2node.getNext().getY() )  // not horizontal 
			{
				/* ABOVE THE SCAN-LINE */
				
				if (m1==m2) {
					return( 0 );
				}
				else if ( m1==0 && m2!=0 ) {
					return( 1 );
				}
				else if ( m1!=0 && m2==0 ) {
					return( -1 );
				}
				else if ( (m1 > 0 && m2 > 0) || (m1 < 0 && m2 < 0) ) {
					if ( m1 > m2 ) {
						return( -1 );
					}
					else {
						return( 1 );
					}
				}
				else if ( m1 > 0 && m2 < 0 ) {
					return( 1 );
				}
				else if ( m1 < 0 && m2 > 0 ) {
					return( -1 );
				}		
			}
			else {
				/* BELOW THE SCAN-LINE */
				
				if (m1==m2) {
					return( 0 );
				}
				else if ( m1==0 && m2!=0 ) {
					return( 1 );
				}
				else if ( m1!=0 && m2==0 ) {
					return( -1 );
				}
				else if ( (m1 > 0 && m2 > 0) || (m1 < 0 && m2 < 0) ) {
					if ( m1 > m2 ) {
						return( 1 );
					}
					else {
						return( -1 );
					}
				}
				else if ( m1 > 0 && m2 < 0 ) {
					return( -1 );
				}
				else if ( m1 < 0 && m2 > 0 ) {
					return( 1 );
				}		
			}
		}
		else if ( xPos1 > xPos2) {
			return( 1 );
		}
		else if ( xPos1 < xPos2 ) {
			return( -1 );
		}
						
		return( -2 );  /* error */
	}
	
	
	/* copied from DSsearchTreeData.findIntersectionWithScanLine() */
	private static double findIntersectionWithScanLine( DSxyDNode n, int scanLinePosX, int scanLinePosY ) 
	{					
		int x1 = n.getX();
		int y1 = n.getY();
		int x2 = n.getNext().getX();
		int y2 = n.getNext().getY();
		
		/* horizontal line */
		if ( y1==y2 && y2==scanLinePosY ) {
			/* report the coordinate with smaller x */
			if ( x1 < x2 ) {
				return( x1 );
			}
			return( x2 ); 
		}
		
		PointInt p = Utilities.findIntersectionWithHorizontalLine( x1, y1, x2, y2, scanLinePosY );
		
		return( p.getX() );		
	}

	
	
	
	
}
