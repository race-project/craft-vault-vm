/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import javax.swing.JOptionPane;

public class OwlVisionMessages {
	
	private static final String msg_10000 = "Cell \"";
	private static final String msg_10001 = "\" is not defined!";
	private static final String msg_10002 = "The program will terminate!";
	
	private static final String msg_10020 = "Please open the GDSII layout first.\n";
	
	/* normal messages */
	private static final String msg_20000 = "Opening file: ";
	private static final String msg_20001 = " ....\n";
	
	/* WARNING MESSAGES */
	private static final String msg_30000 = "GDSII record type \"";
	private static final String msg_30001 = "\" is not supported!\n";
	
	
	public static String get( int messageID, String str01 ) {
		String string;
		
		switch (messageID) {
			case 10000:
				 string = msg_10000 + str01 + msg_10001 + " " + msg_10002;
				 break;
			case 10010:
				 string = msg_10000 + str01 + msg_10001;
				 break;
			case 10020:
				 string = msg_10020;
				 break;
			case 20000:
				 string = msg_20000 + str01 + msg_20001;
				 break;
			case 30000:
				 string = msg_30000 + str01 + msg_30001;
				 break;
			default:				
				 string = "";
				 break;
				
		}
		
		return(string);
	}
	
	
	public static void showConsoleMsg( int msgType, int msgID, String str01 ) {
	
		String msgString = "";
		
		switch ( msgType ) {
			case JOptionPane.INFORMATION_MESSAGE:
				 msgString = "";
			     break;
			case JOptionPane.ERROR_MESSAGE:
				 msgString = "ERROR: ";
				 break;
			case JOptionPane.WARNING_MESSAGE:
				msgString = "WARNING: ";
				 break;
			default:
				 break;
		}
		
		msgString = msgString + get( msgID, str01);
		
		MainClass.appendConsoleText( msgString );
	}
	
	
	
	public static void show( int msgType, int msgID, String str01 ) {
		String title;
		
		switch ( msgType ) {
		    /* ERROR_MESSAGE */
			case JOptionPane.ERROR_MESSAGE:		 
				 title = "ERROR #" + msgID;
				 JOptionPane.showMessageDialog(MainClass.frame,
						OwlVisionMessages.get( msgID, str01), title, msgType );
				 break;
			case JOptionPane.WARNING_MESSAGE:
				 title = "WARNING #" + msgID;
				 JOptionPane.showMessageDialog(MainClass.frame,
						OwlVisionMessages.get( msgID, str01), title, msgType );
				 break;
			default:
				 break;
		}
	}

}
