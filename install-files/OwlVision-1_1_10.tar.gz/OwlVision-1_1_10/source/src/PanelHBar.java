/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.BorderLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.JScrollBar;

/*
 * Created on 2005/4/25
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
//import java.awt.*;
import javax.swing.*;

//import ScrollBar.MyAdjustmentListenerH;

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PanelHBar extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static JScrollBar hbar;
	
	private static final int hbarMin     = 0; 
	private static final int hbarMax     = 1050;
	private static final int hbarExtent  = 50;
	private static final int hbarInitVal = (hbarMax-hbarExtent)/2;  // initial value (cental value)
	
	private static int       hbarValue   = hbarInitVal;
	
	public PanelHBar() {
		setLayout(new BorderLayout());
		
		//hbar = new JScrollBar(JScrollBar.HORIZONTAL, 125, 50, 0, 300);
		hbar = new JScrollBar(JScrollBar.HORIZONTAL, hbarInitVal, hbarExtent, hbarMin, hbarMax);
		hbar.addAdjustmentListener(new MyAdjustmentListenerH());
		
		add(hbar, BorderLayout.CENTER);
		add(new JLabel("     "), BorderLayout.EAST);
		
	}
	
	// Horizontal Scrollbar
	class MyAdjustmentListenerH implements AdjustmentListener {
		public void adjustmentValueChanged(AdjustmentEvent e) {
			//System.out.println("H_ScrollBar value: "+ e.getValue());			
			hbarValue = e.getValue();
			float tmpVal01 = (float) DrawLayout.getImageWidth() / (float) hbarInitVal;
			float tmpVal02 = (float)hbarInitVal - (float)hbarValue;
			float tmpVal03 = tmpVal01 * tmpVal02;
			DrawLayout.setImagePositionX( (int) tmpVal03 );
			PanelCenter.g2D.repaint();  // re-paste image
		}
	}
	
	public static void set_to_default_position() {
		hbar.setValue( hbarInitVal );
	}
	
	public static int getValue() {
		return( hbarValue );
	}
	
	public static void setPosition() {
		float tmpVal01 = (float) DrawLayout.getImageWidth() / (float) hbarInitVal;
		float tmpVal02 = (float)hbarInitVal - (float)hbarValue;
		float tmpVal03 = tmpVal01 * tmpVal02;
		DrawLayout.setImagePositionX( (int) tmpVal03 );
	}
	

}
