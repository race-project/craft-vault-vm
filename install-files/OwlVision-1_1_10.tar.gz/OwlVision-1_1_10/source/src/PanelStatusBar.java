/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/25
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import javax.swing.*;
import javax.swing.border.*;
//import javax.swing.BoxLayout;
import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;

import javax.swing.JProgressBar;


/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PanelStatusBar extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static JLabel window_coord_label, gdsii_coord_label;
	private static JProgressBar progressBar;
	boolean state;

	public PanelStatusBar() {
		
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();

		
		gdsii_coord_label = new JLabel();
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.WEST;
		constraints.weightx = 0.1;
		gdsii_coord_label.setPreferredSize(new Dimension(200, 25)); 
		//gdsii_coord_label.setText(" GDSII coordinates: (0, 0) ");
		gdsii_coord_label.setText(" GDSII: (0, 0) ");
		//gdsii_coord_label.setBorder(new EtchedBorder(EtchedBorder.LOWERED) );
		gdsii_coord_label.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED) );
		add(gdsii_coord_label, constraints);
		
		
		window_coord_label = new JLabel();
		constraints.gridx = 1;
		constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.WEST;
		constraints.weightx = 0.1;
		window_coord_label.setPreferredSize(new Dimension(200, 25)); 
		//window_coord_label.setText(" Window coordinates: (0, 0) ");
		window_coord_label.setText(" Window: (0, 0) ");
		//window_coord_label.setBorder(new EtchedBorder(EtchedBorder.RAISED) );
		window_coord_label.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED) );
		add(window_coord_label, constraints);
		
		/* Progress Bar */
		progressBar = new JProgressBar(0, 1000);
		constraints.gridx = 2;
		constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.EAST;
		constraints.weightx = 0.8;
		progressBar.setStringPainted(true);
		add(progressBar, constraints);
		progressBar.setVisible(false);
		
		//progressBar.setValue(300);
			
	}
	
	
	
	public static void showCoord(int x, int y) {
		
		String t = " GDSII: (" + SizeSetting.trans_GDSII_X(x) + ", " + SizeSetting.trans_GDSII_Y(y) + ") ";
		
		if ( GDSII.isReady() ) {
			gdsii_coord_label.setText(t);		
			window_coord_label.setText(" Window: (" + x + ", " + y + ") ");
		} 
		else {
			gdsii_coord_label.setText("");		
			window_coord_label.setText("");
		}		
	}
	
	
	public static void setProgress(double val) {
		progressBar.setValue( (int)(val*1000) );
	}
	
	public static void setProgressBarVisible(boolean val) {
		progressBar.setVisible(val);
	}

	/* test */
	public static void progressBarIndeterminate(boolean value, String str) {
		if (value == true) {
			progressBar.setVisible(true);
			progressBar.setString(str);
			progressBar.setIndeterminate(true);
		}
		else {
			progressBar.setIndeterminate(false);			
			progressBar.setString(null);	// default value
			progressBar.setVisible(false);
			//progressBar.setStringPainted(true);
		}
		
	}
	
}
