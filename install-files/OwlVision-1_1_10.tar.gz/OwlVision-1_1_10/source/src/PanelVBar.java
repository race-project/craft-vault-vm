/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/25
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.awt.BorderLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.*;

//import ScrollBar.MyAdjustmentListenerV;

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PanelVBar extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static JScrollBar vbar;
	
	private static final int vbarMin     = 0; 
	private static final int vbarMax     = 1050;
	private static final int vbarExtent  = 50;
	private static final int vbarInitVal = (vbarMax-vbarExtent)/2;  // initial value
	
	private static int       vbarValue   = vbarInitVal;
	
	public PanelVBar() {
		vbar = new JScrollBar(JScrollBar.VERTICAL, vbarInitVal, vbarExtent, vbarMin, vbarMax);
		vbar.addAdjustmentListener(new MyAdjustmentListenerV());
		setLayout(new BorderLayout());
		add(vbar, BorderLayout.EAST);
		
	}
	
	// Vertical Scrollbar
	class MyAdjustmentListenerV implements AdjustmentListener {
		public void adjustmentValueChanged(AdjustmentEvent e) {
			//System.out.println("V_ScrollBar value: "+ e.getValue());
			vbarValue = e.getValue();
			float tmpVal01 = (float) DrawLayout.getImageHeight() / (float) vbarInitVal;
			float tmpVal02 = (float) vbarInitVal - (float) vbarValue ;
			float tmpVal03 = tmpVal01 * tmpVal02;
			DrawLayout.setImagePositionY( (int) tmpVal03 );
			//DrawLayout.setImagePositionY(  (SizeSetting.getImageHeight()/(vbarInitVal*2))*(vbarValue) );
			PanelCenter.g2D.repaint();  // re-paste image
		}
	}
	
	public static void set_to_default_position() {
		vbar.setValue( vbarInitVal );
	}
	
	public static int getValue() {
		return( vbarValue );
	}
	
	public static void setPosition() {
		float tmpVal01 = (float) DrawLayout.getImageHeight() / (float) vbarInitVal;
		float tmpVal02 = (float) vbarInitVal - (float) vbarValue ;
		float tmpVal03 = tmpVal01 * tmpVal02;
		DrawLayout.setImagePositionY( (int) tmpVal03 );
	}

}
