/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


import java.awt.Point;


public class PathToBoundary {
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/26 - started working on this method
	 */
	public static DSxyList path2boundary( DSpathNode pathNode ) {
		
		switch( pathNode.getPathtype() ) 
		{
			case 0:		/* square-ended path */
				return( path2boundary_pathtype_0( pathNode.getXYlist(), pathNode.getWidth() ) );
				/* break; */
			case 1:		/* round-ended path */
				return( path2boundary_pathtype_0( pathNode.getXYlist(), pathNode.getWidth() ) );
				//break;
			case 2:		/* square-ended path */
				return( path2boundary_pathtype_2_or_4( pathNode, 2 ) );
				//break;
			case 4:		/* square-ended path with user-defined extensions */
				return( path2boundary_pathtype_2_or_4( pathNode, 4 ) );
				/* break; */
			default:
				return( path2boundary_pathtype_0( pathNode.getXYlist(), pathNode.getWidth() ) );
				/* break; */
		}
		
		//return( null );
	}
	
	
	/* translate a PATH element to a BOUNDARY element */
	/* Modified from "DrawPath.drawPath()" */
	private static DSxyList path2boundary_pathtype_0(	
														DSxyList   xyList,
														int        width )
	{
		Point [] point = new Point [xyList.getNumber()*2];

		int x0=0, y0=0;  /* previous node: initialize */
		int x1=0, y1=0;  /* current node: initialize */
		int x2=0, y2=0;  /* next node: initialize */
		int numOfPoints = xyList.getNumber();

		double w = width/2;

		int i;
		DSxyNode xyNode;
		
		/* all of the nodes in the path */
		for ( i=0, xyNode = xyList.getHead(); 
			  i< numOfPoints; 
			  i++, xyNode = xyNode.getNext() ) 
		{
			//System.out.println("i = " + i );

			x1 = xyNode.getX();  /* current node */
			y1 = xyNode.getY();	 /* current node */	
			
			if ( xyNode.getNext()!=null) {
				x2 = xyNode.getNext().getX(); /* next node */
				y2 = xyNode.getNext().getY(); /* next node */	
			}
		
			/* THE FIRST VERTEX */
			if (i==0) {
				/* vertical edge */
				if ( x1==x2 ) {
					/* up */
					if (y1<=y2) {
						point[i] = new Point( (int)(x1-w), y1);
						point[2*numOfPoints-i-1] = new Point( (int)(x1+w), y1 );		            	
					}
					/* down */
					else {
						point[i] = new Point( (int)(x1+w), y1);
						point[2*numOfPoints-i-1] = new Point( (int)(x1-w), y1 );
					}					
				}
				/* horizontal edge */
				else if ( y1==y2 ) {
					/* to the right */
					if (x1<=x2) {
						point[i] = new Point( x1, (int)(y1+w) );
						point[2*numOfPoints-i-1] = new Point( x1, (int)(y1-w) );						
					}
					/* to the left */
					else {
						point[i] = new Point( x1, (int)(y1-w) );
						point[2*numOfPoints-i-1] = new Point( x1, (int)(y1+w) );
					}
				}
				/* non-Manhattan edge */
				else {
					double m1 = ((double)y1-(double)y2)/((double)x1-(double)x2);
					double m2 = (-1)/m1;
					double a1 = (-1)*w/(Math.sqrt(1+Math.pow(m2,2)));
					double a2 = m2*a1;
					double b1 = (-1)*a1;
					double b2 = m2*b1;
					/* up */
					if (y1<=y2) {
						if (a1<=b1) {
							point[i] = new Point((int)(a1+x1),(int)(a2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
						}
						else {
							point[i] = new Point((int)(b1+x1),(int)(b2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));		        			
						}
					}
					/* down */
					else {
						if (a1<=b1) {
							point[i] = new Point((int)(b1+x1),(int)(b2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));		        					        			
						}
						else {
							point[i] = new Point((int)(a1+x1),(int)(a2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
						}
					}
				}
			}
			/* THE LAST POINT */
			else if (i==xyList.getNumber()-1) {

				/* vertical edge */
				if ( x0==x1 ) {
					/* up */
					if (y0<=y1) {
						point[i] = new Point( (int)(x1-w), y1);
						point[2*numOfPoints-i-1] = new Point((int)(x1+w),y1);
					}
					/* down */
					else {
						point[i] = new Point((int)(x1+w), y1);
						point[2*numOfPoints-i-1] = new Point((int)(x1-w),y1);
					}					
				}
				/* horizontal edge */
				else if ( y0==y1 ) {
					/* to the right */
					if (x0<=x1) {
						point[i] = new Point(x1,(int)(y1+w));
						point[2*numOfPoints-i-1] = new Point(x1,(int)(y1-w));
					}
					/* to the left */
					else {
						point[i] = new Point(x1,(int)(y1-w));
						point[2*numOfPoints-i-1] = new Point(x1,(int)(y1+w));
					}
				}
				/* non-Manhattan edge */
				else {
					double m1 = ((double)y0-(double)y1)/((double)x0-(double)x1);
					double m2 = (-1)/m1;
					double a1 = (-1)*w/(Math.sqrt(1+Math.pow(m2,2)));
					double a2 = m2*a1;
					double b1 = (-1)*a1;
					double b2 = m2*b1;
					/* up */
					if (y0<=y1) {
						if (a1<=b1) {
							point[i] = new Point((int)(a1+x1),(int)(a2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
						}
						else {		        			
							point[i] = new Point((int)(b1+x1),(int)(b2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));
						}
					}
					/* down */
					else {
						if (a1<=b1) {
							point[i] = new Point((int)(b1+x1),(int)(b2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(a1+x1),(int)(a2+y1));
						}
						else {
							point[i] = new Point((int)(a1+x1),(int)(a2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(b1+x1),(int)(b2+y1));
			
						}
					}
				}
			}
			/* MIDDLE VERTICES */
			else {
				double m01 = ((double)y0-(double)y1)/((double)x0-(double)x1);
				double m12 = ((double)y1-(double)y2)/((double)x1-(double)x2);

				double x00 = x0 - x1;
				double y00 = y0 - y1;
				double x20 = x2 - x1;
				double y20 = y2 - y1;
				double m01p;
				double px;
				double py;

				if (m01==0) {  /* special case */
					m01p  = (-1)/m01;  /* Infinity: not used */
					px = 0;
					py = w;
				}
				else {  /* normal case */
					m01p  = (-1)/m01;
					px = w/(Math.sqrt(1+Math.pow(m01p,2)));
					py = px*m01p;	
				}

				double a = 100000/( Math.sqrt(Math.pow(x00,2)+ Math.pow(y00,2)) );
				double b = 100000/( Math.sqrt(Math.pow(x20,2)+ Math.pow(y20,2)) );
				double m_1 = (a*y00-b*y20)/(a*x00-b*x20);

				/* special case: (m_1==Infinity) */
				if (a*x00==b*x20) {
					double s1 = px + py*py/px;
					double s2 = 0;
					/* up */
					if (y1<y2) {
						if (s1>0) {
							point[i] = new Point((int)(-s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(s1+x1),(int)(0+y1));
						}
						else {
							point[i] = new Point((int)(s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(-s1+x1),(int)(0+y1));
						}		
					}
					/* down */
					else {  /* y1>y2 */
						if (s1>0) {
							point[i] = new Point((int)(s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(-s1+x1),(int)(0+y1));
						}
						else {
							point[i] = new Point((int)(-s1+x1),(int)(0+y1));
							point[2*numOfPoints-i-1] = new Point((int)(s1+x1),(int)(0+y1));							
						}
					}
				}
				/* special case: (m_1==0) */
				else if (a*y00==b*y20) {
					//System.out.println("Special Case: m_1==0");;
					double s1 = 0;
					//double s2 = px + py*py/px;
					double s2 = py + px*px/py;
					/* to the right */
					if (x1<x2) {
						if (s2>0) {
							point[i] = new Point((int)(0+x1),(int)(s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(-s2+y1));
						}
						else {
							point[i] = new Point((int)(0+x1),(int)(-s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(s2+y1));						
						}
					}
					/* to the left */
					else {
						if (s2>0) {
							point[i] = new Point((int)(0+x1),(int)(-s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(s2+y1));
						}
						else {
							point[i] = new Point((int)(0+x1),(int)(s2+y1));
							point[2*numOfPoints-i-1] = new Point((int)(0+x1),(int)(-s2+y1));						
						}
					}
				}
				/* normal case */
				else {
					double m_2 = (-1)/m_1;
					/*
					 double m01p  = (-1)/m01;
					 double px = w/(Math.sqrt(1+Math.pow(m01p,2)));
					 double py = px*m01p;
					 */
					double s1 = (px*px+py*py)/(px+py*m_2);
					double s2 = s1*m_2;
					double qx;
					double qy;
	
					if (m01==0) {
						qx = 0;
						qy = -w;
					}
					else {
						qx = -px;
						qy = qx*m01p;
					}
	
					double t1 = (qx*qx+qy*qy)/(qx+qy*m_2);
					double t2 = t1*m_2;
	
					if ( Geometry.isTurnLeft( x0,y0,x1,y1,(int)(s1+x1),(int)(s2+y1)) ) {
						point[i] = new Point((int)(s1+x1),(int)(s2+y1));
						point[2*numOfPoints-i-1] = new Point((int)(t1+x1),(int)(t2+y1));
					}
					else {						
						point[i] = new Point((int)(t1+x1),(int)(t2+y1));
						point[2*numOfPoints-i-1] = new Point((int)(s1+x1),(int)(s2+y1));
					}

				}  /* END of normal case */
			}  /* END of MIDDLE POINTS */

			x0 = x1;  /* set previous node */
			y0 = y1;  /* set previous node */		
		}

		//Point pnt;
		//Polygon poly = new Polygon();
		//int rotatedX1, rotatedY1; 

		//for ( i = 0; i< numOfPoints*2; i++ ) {  			
			//pnt = DS_build.rotate( (int)point[i].getX(), (int)point[i].getY(), angle);
			//rotatedX1 = (int) pnt.getX();
			//rotatedY1 = (int) pnt.getY();

			//poly.addPoint( (int) SizeSetting.trans_X( rotatedX1+shiftX ), 
			//			   (int) SizeSetting.trans_Y( rotatedY1+shiftY ) );
		//}
		//graphics2D.draw( poly );

		
		
		DSxyList resultantXYlist = new DSxyList();
		
		for ( i = 0; i< numOfPoints*2; i++ ) {
			resultantXYlist.insert( (int)point[i].getX(), (int)point[i].getY() );
		}
		
		// use the first point(vertex) as the last point (repeatition)
		resultantXYlist.insert( (int)point[0].getX(), (int)point[0].getY() );  
		
		return( resultantXYlist ); 
		
	}
	
	
	/* Author:  I-Lun Tseng
	 * History: 2006/11/26 - started working
	 * 			2006/11/28 - initial version finished
	 */
	private static DSxyList path2boundary_pathtype_2_or_4( DSpathNode pathNode, int pathtype ) 
	{
		int xPrev = 0, yPrev = 0;	/* the previous vertex */
		int xCurr = 0, yCurr = 0;	/* the current vertex */
		int xNext = 0, yNext = 0;	/* the next vertex */
		
		//int width = pathNode.getWidth();
		
		DSxyList xyList = pathNode.getXYlist();
		int numOfVertices = xyList.getNumber();
		
		int bgnextn = 0;
		int endextn = 0;
		
		if ( pathtype == 4 ) {
			bgnextn = pathNode.getBgnextnValue();
		}
		else if ( pathtype == 2 ) {
			bgnextn = pathNode.getWidth() / 2;
		}
		
		if ( pathtype == 4 ) {
			endextn = pathNode.getEndextnValue();
		}
		else if ( pathtype == 2 ) {
			endextn = pathNode.getWidth() / 2;
		}
		
		
		int i;
		DSxyNode xyNode;
		
		for ( i = 0, xyNode = xyList.getHead(); 
		      i < numOfVertices; 
		      i++, xyNode = xyNode.getNext() )
		{
			xCurr = xyNode.getX();	/* current node */
			yCurr = xyNode.getY();	/* current node */
			
			if ( xyNode.getNext()!=null ) {
				xNext = xyNode.getNext().getX();	/* next node */
				yNext = xyNode.getNext().getY();	/* next node */	
			}
			
			/* THE FIRST VERTEX */
			if ( i==0 ) {
				/* vertical edge */
				if ( xCurr == xNext ) {
					/* up */
					if ( yCurr <= yNext ) {
						xyNode.setY( yCurr - bgnextn );
					}
					/* down */
					else {
						xyNode.setY( yCurr + bgnextn );
					}
				}
				/* horizontal edge */
				else if ( yCurr == yNext ) {
					/* to the right */
					if ( xCurr <= xNext ) {
						xyNode.setX( xCurr - bgnextn );
					}
					/* to the left */
					else {
						xyNode.setX( xCurr + bgnextn );
					}
				}
				/* non-Manhattan edge */
				else {
					double m = ((double)(yCurr - yNext)) / ((double)(xCurr - xNext));
					double e = 0;
					
					if ( pathtype == 4 ) {
						e = pathNode.getBgnextnValue();
					}
					else if ( pathtype == 2 ) {
						e = pathNode.getWidth() / 2;
					}
					
					TwoVertices twoVertices = Geometry.calculateVertexAccordingToSlopeAndLength( m, e );
					
					int p1 = twoVertices.getX1() + xCurr;
					int q1 = twoVertices.getY1() + yCurr;
					int p2 = twoVertices.getX2() + xCurr;
					int q2 = twoVertices.getY2() + yCurr;
					
					if ( e >= 0 ) {
						if ( (xCurr <= p1 && p1 <= xNext) || 
							 (xCurr >= p1 && p1 >= xNext) ) {
							//p = p2;
							xyNode.setXY( p2, q2 );
						}
						else {
							//p = p1;
							xyNode.setXY( p1, q1 );
						}
					}
					else {
						if ( (xCurr <= p1 && p1 <= xNext) ||
							 (xCurr >= p1 && p1 >= xNext) ) {
							//p = p1;
							xyNode.setXY( p1, q1 );
						}
						else {
							//p = p2;
							xyNode.setXY( p2, q2 );
						}
					}
				}
			}			
			/* THE LAST VERTEX */
			else if ( i==numOfVertices-1 ) {
				/* vertical edge */
				if ( xPrev == xCurr ) {
					/* up */
					if ( yPrev <= yCurr ) {
						xyNode.setY( yCurr + endextn );
					}
					/* down */
					else {
						xyNode.setY( yCurr - endextn );
					}					
				}
				/* horizontal edge */
				else if ( yPrev == yCurr ) {
					/* to the right */
					if ( xPrev <= xCurr ) {
						xyNode.setX( xCurr + endextn );
					}
					/* to the left */
					else {
						xyNode.setX( xCurr - endextn );
					}
				}
				/* non-Manhattan edge */
				else {
					/* similiar to "THE FIRST VERTEX - non-Manhattan edge" */
					
					double m = ((double)(yCurr - yPrev)) / ((double)(xCurr - xPrev));
					double e = 0;
					
					if ( pathtype == 4 ) {
						e = pathNode.getEndextnValue();
					}
					else if ( pathtype == 2 ) {
						e = pathNode.getWidth() / 2;
					}
					
					TwoVertices twoVertices = Geometry.calculateVertexAccordingToSlopeAndLength( m, e );
					
					int p1 = twoVertices.getX1() + xCurr;
					int q1 = twoVertices.getY1() + yCurr;
					int p2 = twoVertices.getX2() + xCurr;
					int q2 = twoVertices.getY2() + yCurr;
					
					if ( e >= 0 ) {
						if ( (xCurr <= p1 && p1 <= xNext) || 
							 (xCurr >= p1 && p1 >= xNext) ) {
							//p = p2;
							xyNode.setXY( p2, q2 );
						}
						else {
							//p = p1;
							xyNode.setXY( p1, q1 );
						}
					}
					else {
						if ( (xCurr <= p1 && p1 <= xNext) ||
							 (xCurr >= p1 && p1 >= xNext) ) {
							//p = p1;
							xyNode.setXY( p1, q1 );
						}
						else {
							//p = p2;
							xyNode.setXY( p2, q2 );
						}
					}
				}
			}
			/* MIDDLE VERTICES */
			else {
				/* do nothing */
			}	
			
			xPrev = xCurr;  /* set previous node */
			yPrev = yCurr;  /* set previous node */
		}
		
		return( path2boundary_pathtype_0( pathNode.getXYlist(), pathNode.getWidth() ) );
	}


}
