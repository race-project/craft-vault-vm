/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class QuadTreeNode {
	
	private int			  depth;	 /* the current depth */
	
	private QuadTreeNode  ULeft;     /* Upper Left  (0) */
	private QuadTreeNode  URight;    /* Upper Right (1) */
	private QuadTreeNode  LLeft;     /* Lower Left  (2) */
	private QuadTreeNode  LRight;    /* Lower Right (3) */
	
	private DSelements	  elements;  /* leaf node: the layout geometry */
	
	private static final boolean DEBUG_SHOW_QUAD_TREE_DEPTH = false;
	private static final int MAX_QUAD_TREE_DEPTH    = 4;
	private static final int MAX_QUAD_TREE_ELEMENTS = 20;  // 10K polg --> 1000
	
	
	public QuadTreeNode( int dep ) {
		depth    = dep;
		ULeft    = null;
		URight   = null;
		LLeft    = null;
		LRight   = null;
		elements = null; 
	}
	
	public void setDepth( int dep ) {
		depth = dep;
	}
	
	public int getDepth() {
		return depth;
	}
	
	public QuadTreeNode getULeft() {
		return( ULeft );
	}
	public QuadTreeNode getURight() {
		return( URight );
	}
	public QuadTreeNode getLLeft() {
		return( LLeft );
	}
	public QuadTreeNode getLRight() {
		return( LRight );
	}
	public DSelements getElements() {
		return( elements );
	}
	
	public DSboundaryList getBoundaryList() {
		return( elements.getBoundaryList() );
	}
	
	public void newElements() {
		elements = new DSelements();
	}
	
	/* addElement - BOUNDARY */
	public void addElement( DSboundaryNode bdNode ) {
		
		if (elements==null) {
			elements = new DSelements();
		}
		
		DSboundaryList bdList = elements.getBoundaryList();
		
		if (bdList==null) {
			DSboundaryList newList = new DSboundaryList();
			newList.insert( bdNode );
			elements.setBoundaryList( newList );
		}
		else {
			bdList.insert( bdNode );
		}
	}
	
	public void addUL( DSboundaryNode bdNode, int dep ) {
		if (ULeft==null) {
			ULeft = new QuadTreeNode( dep );
		}
		ULeft.addElement( bdNode );		
	}
	
	public void addUR( DSboundaryNode bdNode, int dep ) {
		if (URight==null) {
			URight = new QuadTreeNode( dep );
		}
		URight.addElement( bdNode );		
	}
	
	public void addLL( DSboundaryNode bdNode, int dep ) {
		if (LLeft==null) {
			LLeft = new QuadTreeNode( dep );
		}
		LLeft.addElement( bdNode );
	}
	
	public void addLR( DSboundaryNode bdNode, int dep ) {
		if (LRight==null) {
			LRight = new QuadTreeNode( dep );
		}
		LRight.addElement( bdNode );
	}
	
	/* addElement - BOX */
	public void addElement( DSboxNode boNode ) {
		
		if (elements==null) {
			elements = new DSelements();
		}
		
		DSboxList boList = elements.getBoxList();
		
		if (boList==null) {
			DSboxList newList = new DSboxList();
			newList.insert( boNode );
			elements.setBoxList( newList );
		}
		else {
			boList.insert( boNode );
		}
	}
	
	public void addUL( DSboxNode boNode, int dep ) {
		if (ULeft==null) {
			ULeft = new QuadTreeNode( dep );
		}
		ULeft.addElement( boNode );		
	}
	
	public void addUR( DSboxNode boNode, int dep ) {
		if (URight==null) {
			URight = new QuadTreeNode( dep );
		}
		URight.addElement( boNode );		
	}
	
	public void addLL( DSboxNode boNode, int dep ) {
		if (LLeft==null) {
			LLeft = new QuadTreeNode( dep );
		}
		LLeft.addElement( boNode );
	}
	
	public void addLR( DSboxNode boNode, int dep ) {
		if (LRight==null) {
			LRight = new QuadTreeNode( dep );
		}
		LRight.addElement( boNode );
	}
	
	/* addElement - TEXT */
	public void addElement( DStextNode txNode ) {
		
		if (elements==null) {
			elements = new DSelements();
		}
		
		DStextList txList = elements.getTextList();
		
		if (txList==null) {
			DStextList newList = new DStextList();
			newList.insert( txNode );
			elements.setTextList( newList );
		}
		else {
			txList.insert( txNode );
		}
	}
	
	public void addUL( DStextNode txNode, int dep ) {
		if (ULeft==null) {
			ULeft = new QuadTreeNode( dep );
		}
		ULeft.addElement( txNode );		
	}
	
	public void addUR( DStextNode txNode, int dep ) {
		if (URight==null) {
			URight = new QuadTreeNode( dep );
		}
		URight.addElement( txNode );		
	}
	
	public void addLL( DStextNode txNode, int dep ) {
		if (LLeft==null) {
			LLeft = new QuadTreeNode( dep );
		}
		LLeft.addElement( txNode );
	}
	
	public void addLR( DStextNode txNode, int dep ) {
		if (LRight==null) {
			LRight = new QuadTreeNode( dep );
		}
		LRight.addElement( txNode );
	}
	
	/* addElement - PATH */
	public void addElement( DSpathNode paNode) {
		
		if (elements==null) {
			elements = new DSelements();
		}
		
		DSpathList paList = elements.getPathList();
		
		if (paList==null) {
			DSpathList newList = new DSpathList();
			newList.insert( paNode );
			elements.setPathList( newList );
		}
		else {
			paList.insert( paNode );
		}
	}
	
	public void addUL( DSpathNode paNode, int dep ) {
		if (ULeft==null) {
			ULeft = new QuadTreeNode( dep );
		}
		ULeft.addElement( paNode );		
	}
	
	public void addUR( DSpathNode paNode, int dep  ) {
		if (URight==null) {
			URight = new QuadTreeNode( dep );
		}
		URight.addElement( paNode );		
	}
	
	public void addLL( DSpathNode paNode, int dep  ) {
		if (LLeft==null) {
			LLeft = new QuadTreeNode( dep );
		}
		LLeft.addElement( paNode );
	}
	
	public void addLR( DSpathNode paNode, int dep  ) {
		if (LRight==null) {
			LRight = new QuadTreeNode( dep );
		}
		LRight.addElement( paNode );
	}
	
	/* addElement - SREF */
	public void addElement( DSsrefNode srefNode ) {
		
		if (elements==null) {
			elements = new DSelements();
		}
		
		DSsrefList srefList = elements.getSrefList();
		
		if (srefList==null) {
			DSsrefList newList = new DSsrefList();
			newList.insert( srefNode );
			elements.setSrefList( newList );
		}
		else {
			srefList.insert( srefNode );
		}
	}
	
	public void addUL( DSsrefNode srefNode, int dep ) {
		if (ULeft==null) {
			ULeft = new QuadTreeNode( dep );
		}
		ULeft.addElement( srefNode );		
	}
	
	public void addUR( DSsrefNode srefNode, int dep ) {
		if (URight==null) {
			URight = new QuadTreeNode( dep );
		}
		URight.addElement( srefNode );		
	}
	
	public void addLL( DSsrefNode srefNode, int dep ) {
		if (LLeft==null) {
			LLeft = new QuadTreeNode( dep );
		}
		LLeft.addElement( srefNode );
	}
	
	public void addLR( DSsrefNode srefNode, int dep ) {
		if (LRight==null) {
			LRight = new QuadTreeNode( dep );
		}
		LRight.addElement( srefNode );
	}
	
	/* addElement - AREF */
	public void addElement( DSarefNode arefNode ) {
		
		if (elements==null) {
			elements = new DSelements();
		}
		
		DSarefList arefList = elements.getArefList();
		
		if (arefList==null) {
			DSarefList newList = new DSarefList();
			newList.insert( arefNode );
			elements.setArefList( newList );
		}
		else {
			arefList.insert( arefNode );
		}
	}
	
	
	/* === build Sub Quad Tree === */
	
	
	/* BOUNDARY */
	public void divideBoundaryElementsIntoQuadTrees( BoundingBox bbox ) 
	{		
		int divX = bbox.getMidX();  // divider line
		int divY = bbox.getMidY();  // divider line
		
		if ( elements == null ) {
			return;
		}
		if ( elements.getBoundaryList() == null ) {
			return;
		}
		if ( elements.getBoundaryList().getNumber() <= MAX_QUAD_TREE_ELEMENTS ) {  // # of polygons (17)
			return;  /* do not divide into subtrees if less than the number */											  
		} 
		if ( depth > MAX_QUAD_TREE_DEPTH ) {	// the quad tree depth, normally less than 5~6 
			return;  // do not divide into subtrees if greater than the number 
		}
		
		if ( DEBUG_SHOW_QUAD_TREE_DEPTH ) {
			System.out.println("depth: " + depth);
		}
		
		DSboundaryList tempBDlist = new DSboundaryList();  // temporary boundary list 
		
		for ( DSboundaryNode bdNode = elements.getBoundaryList().getHead();
		      bdNode != null;
		      bdNode = bdNode.getNext() ) 
		{
			int bd_minX = bdNode.getMinX();  // element's minX
    		int bd_maxX = bdNode.getMaxX();  // element's maxX
    		int bd_minY = bdNode.getMinY();  // element's minY
    		int bd_maxY = bdNode.getMaxY();  // element's maxY
    		
    		/* ULeft */
    		if ( (divX >= bd_maxX) && (divY <= bd_minY) ) {
    			DSboundaryNode bd_new = new DSboundaryNode(bdNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUL( bd_new, depth+1 );
    		}
    		/* URight */
    		else if ( (divX <= bd_minX) && (divY <= bd_minY) ) {
    			DSboundaryNode bd_new = new DSboundaryNode(bdNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUR( bd_new, depth+1 );
    		}        		
    		/* LLeft */
    		else if ( (divX >= bd_maxX) && (divY >= bd_maxY) ) {
    			DSboundaryNode bd_new = new DSboundaryNode(bdNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addLL( bd_new, depth+1 );
    		}
    		/* LRight */
    		else if ( (divX <= bd_minX) && (divY >= bd_maxY) ) {
				DSboundaryNode bd_new = new DSboundaryNode(bdNode);  /* create a new DSboundaryNode */  /* may not need to create new */
				addLR( bd_new, depth+1 );
			}
    		else {
    			DSboundaryNode bd_new = new DSboundaryNode(bdNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			tempBDlist.insert( bd_new );
    		}
		}
		
		elements.setBoundaryList( tempBDlist );
		
		if (ULeft!=null) {
			BoundingBox bboxUL = new BoundingBox( bbox.getMinX(), divX, divY, bbox.getMaxY() );
			ULeft.divideBoundaryElementsIntoQuadTrees( bboxUL );
		}		
		if (URight!=null) {
			BoundingBox bboxUR = new BoundingBox( divX, bbox.getMaxX(), divY, bbox.getMaxY() );
			URight.divideBoundaryElementsIntoQuadTrees( bboxUR );
		}
		if (LLeft!=null) {
			BoundingBox bboxLL = new BoundingBox( bbox.getMinX(), divX, bbox.getMinY(), divY );
			LLeft.divideBoundaryElementsIntoQuadTrees( bboxLL );
		}
		if (LRight!=null) {
			BoundingBox bboxLR = new BoundingBox( divX, bbox.getMaxX(), bbox.getMinY(), divY );
			LRight.divideBoundaryElementsIntoQuadTrees( bboxLR );
		}
	}  // END of divideBoundaryElementsIntoQuadTrees()
	
	
	/* BOX */
	public void divideBoxElementsIntoQuadTrees( BoundingBox bbox ) 
	{
		
		
		int divX = bbox.getMidX();  // divider line
		int divY = bbox.getMidY();  // divider line
		
		if ( elements == null ) {
			return;
		}
		if ( elements.getBoxList() == null ) {
			return;
		}
		if ( elements.getBoxList().getNumber() <= MAX_QUAD_TREE_ELEMENTS ) {  // # of polygons (17)
			return;  /* do not divide into subtrees if less than the number */											  
		} 
		if ( depth > MAX_QUAD_TREE_DEPTH ) {	// the quad tree depth, normally less than 5~6 
			return;  // do not divide into subtrees if greater than the number 
		}
		
		if ( DEBUG_SHOW_QUAD_TREE_DEPTH ) {
			System.out.println("depth: " + depth);
		}
		
		DSboxList tempBOXlist = new DSboxList();
		
		for ( DSboxNode boxNode = elements.getBoxList().getHead();
		      boxNode != null;
		      boxNode = boxNode.getNext() ) 
		{
			int box_minX = boxNode.getMinX();  // element's minX
    		int box_maxX = boxNode.getMaxX();  // element's maxX
    		int box_minY = boxNode.getMinY();  // element's minY
    		int box_maxY = boxNode.getMaxY();  // element's maxY
    		
    		/* ULeft */
    		if ( (divX >= box_maxX) && (divY <= box_minY) ) {
    			DSboxNode box_new = new DSboxNode(boxNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUL( box_new, depth+1 );
    		}
    		/* URight */
    		else if ( (divX <= box_minX) && (divY <= box_minY) ) {
    			DSboxNode box_new = new DSboxNode(boxNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUR( box_new, depth+1 );
    		}        		
    		/* LLeft */
    		else if ( (divX >= box_maxX) && (divY >= box_maxY) ) {
    			DSboxNode box_new = new DSboxNode(boxNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addLL( box_new, depth+1 );
    		}
    		/* LRight */
    		else if ( (divX <= box_minX) && (divY >= box_maxY) ) {
				DSboxNode box_new = new DSboxNode(boxNode);  /* create a new DSboundaryNode */  /* may not need to create new */
				addLR( box_new, depth+1 );
			}
    		else {
    			DSboxNode box_new = new DSboxNode(boxNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			tempBOXlist.insert( box_new );
    			
    		}
		}
		
		elements.setBoxList( tempBOXlist );
		
		if (ULeft!=null) {
			BoundingBox bboxUL = new BoundingBox( bbox.getMinX(), divX, divY, bbox.getMaxY() );
			ULeft.divideBoxElementsIntoQuadTrees( bboxUL );
		}		
		if (URight!=null) {
			BoundingBox bboxUR = new BoundingBox( divX, bbox.getMaxX(), divY, bbox.getMaxY() );
			URight.divideBoxElementsIntoQuadTrees( bboxUR );
		}
		if (LLeft!=null) {
			BoundingBox bboxLL = new BoundingBox( bbox.getMinX(), divX, bbox.getMinY(), divY );
			LLeft.divideBoxElementsIntoQuadTrees( bboxLL );
		}
		if (LRight!=null) {
			BoundingBox bboxLR = new BoundingBox( divX, bbox.getMaxX(), bbox.getMinY(), divY );
			LRight.divideBoxElementsIntoQuadTrees( bboxLR );
		}
	} // END of divideBoxElementsIntoQuadTrees()
	
	
	/* TEXT */
	public void divideTextElementsIntoQuadTrees( BoundingBox bbox ) 
	{		
		int divX = bbox.getMidX();  // divider line
		int divY = bbox.getMidY();  // divider line
		
		if ( elements == null ) {
			return;
		}
		if ( elements.getTextList() == null ) {
			return;
		}
		if ( elements.getTextList().getNumber() <= MAX_QUAD_TREE_ELEMENTS ) {  // # of polygons (17)
			return;  /* do not divide into subtrees if less than the number */											  
		} 
		if ( depth > MAX_QUAD_TREE_DEPTH ) {	// the quad tree depth, normally less than 5~6 
			return;  // do not divide into subtrees if greater than the number 
		}
		
		if ( DEBUG_SHOW_QUAD_TREE_DEPTH ) {
			System.out.println("depth: " + depth);
		}
		
		DStextList tempTXlist = new DStextList();  // temporary text list 
		
		for ( DStextNode txNode = elements.getTextList().getHead();
		      txNode != null;
		      txNode = txNode.getNext() ) 
		{
			int tx_minX = txNode.getMinX();  // element's minX
    		int tx_maxX = txNode.getMaxX();  // element's maxX
    		int tx_minY = txNode.getMinY();  // element's minY
    		int tx_maxY = txNode.getMaxY();  // element's maxY
    		
    		/* ULeft */
    		if ( (divX >= tx_maxX) && (divY <= tx_minY) ) {
    			DStextNode tx_new = new DStextNode(txNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUL( tx_new, depth+1 );
    		}
    		/* URight */
    		else if ( (divX <= tx_minX) && (divY <= tx_minY) ) {
    			DStextNode tx_new = new DStextNode(txNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUR( tx_new, depth+1 );
    		}        		
    		/* LLeft */
    		else if ( (divX >= tx_maxX) && (divY >= tx_maxY) ) {
    			DStextNode tx_new = new DStextNode(txNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addLL( tx_new, depth+1 );
    		}
    		/* LRight */
    		else if ( (divX <= tx_minX) && (divY >= tx_maxY) ) {
				DStextNode tx_new = new DStextNode(txNode);  /* create a new DSboundaryNode */  /* may not need to create new */
				addLR( tx_new, depth+1 );
			}
    		else {
    			DStextNode tx_new = new DStextNode(txNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			tempTXlist.insert( tx_new );
    		}
		}
		
		elements.setTextList( tempTXlist );
		
		if (ULeft!=null) {
			BoundingBox bboxUL = new BoundingBox( bbox.getMinX(), divX, divY, bbox.getMaxY() );
			ULeft.divideTextElementsIntoQuadTrees( bboxUL );
		}		
		if (URight!=null) {
			BoundingBox bboxUR = new BoundingBox( divX, bbox.getMaxX(), divY, bbox.getMaxY() );
			URight.divideTextElementsIntoQuadTrees( bboxUR );
		}
		if (LLeft!=null) {
			BoundingBox bboxLL = new BoundingBox( bbox.getMinX(), divX, bbox.getMinY(), divY );
			LLeft.divideTextElementsIntoQuadTrees( bboxLL );
		}
		if (LRight!=null) {
			BoundingBox bboxLR = new BoundingBox( divX, bbox.getMaxX(), bbox.getMinY(), divY );
			LRight.divideTextElementsIntoQuadTrees( bboxLR );
		}
	}  // END of divideTextElementsIntoQuadTrees()
		
	
	/* PATH */
	public void dividePathElementsIntoQuadTrees( BoundingBox bbox ) 
	{
		int divX = bbox.getMidX();  // divider line
		int divY = bbox.getMidY();  // divider line
		
		if ( elements == null ) {
			return;
		}
		if ( elements.getPathList() == null ) {
			return;
		}
		if ( elements.getPathList().getNumber() <= MAX_QUAD_TREE_ELEMENTS ) {  // # of polygons (17)
			return;  /* do not divide into subtrees if less than the number */											  
		} 
		if ( depth > MAX_QUAD_TREE_DEPTH ) {	// the quad tree depth, normally less than 5~6 
			return;  // do not divide into subtrees if greater than the number 
		}
		
		if ( DEBUG_SHOW_QUAD_TREE_DEPTH ) {
			System.out.println("depth: " + depth);
		}
		
		DSpathList tempPathList = new DSpathList();
		
		for ( DSpathNode paNode = elements.getPathList().getHead();
		      paNode != null;
		      paNode = paNode.getNext() ) 
		{
			int pa_minX = paNode.getMinX();  // element's minX
    		int pa_maxX = paNode.getMaxX();  // element's maxX
    		int pa_minY = paNode.getMinY();  // element's minY
    		int pa_maxY = paNode.getMaxY();  // element's maxY
    		
    		/* ULeft */
    		if ( (divX >= pa_maxX) && (divY <= pa_minY) ) {
    			DSpathNode pa_new = new DSpathNode(paNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUL( pa_new, depth+1 );
    		}
    		/* URight */
    		else if ( (divX <= pa_minX) && (divY <= pa_minY) ) {
    			DSpathNode pa_new = new DSpathNode(paNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUR( pa_new, depth+1 );
    		}        		
    		/* LLeft */
    		else if ( (divX >= pa_maxX) && (divY >= pa_maxY) ) {
    			DSpathNode pa_new = new DSpathNode(paNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addLL( pa_new, depth+1 );
    		}
    		/* LRight */
    		else if ( (divX <= pa_minX) && (divY >= pa_maxY) ) {
				DSpathNode pa_new = new DSpathNode(paNode);  /* create a new DSboundaryNode */  /* may not need to create new */
				addLR( pa_new, depth+1 );
			}
    		else {
    			DSpathNode pa_new = new DSpathNode(paNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			tempPathList.insert( pa_new );
    		}
		}
		
		elements.setPathList( tempPathList );
		
		if (ULeft!=null) {
			BoundingBox bboxUL = new BoundingBox( bbox.getMinX(), divX, divY, bbox.getMaxY() );
			ULeft.dividePathElementsIntoQuadTrees( bboxUL );
		}		
		if (URight!=null) {
			BoundingBox bboxUR = new BoundingBox( divX, bbox.getMaxX(), divY, bbox.getMaxY() );
			URight.dividePathElementsIntoQuadTrees( bboxUR );
		}
		if (LLeft!=null) {
			BoundingBox bboxLL = new BoundingBox( bbox.getMinX(), divX, bbox.getMinY(), divY );
			LLeft.dividePathElementsIntoQuadTrees( bboxLL );
		}
		if (LRight!=null) {
			BoundingBox bboxLR = new BoundingBox( divX, bbox.getMaxX(), bbox.getMinY(), divY );
			LRight.dividePathElementsIntoQuadTrees( bboxLR );
		}
	}  // END of dividePathElementsIntoQuadTrees()
	
	
	/* SREF */
	public void divideSrefElementsIntoQuadTrees( BoundingBox bbox ) 
	{		
		int divX = bbox.getMidX();  // divider line
		int divY = bbox.getMidY();  // divider line
		
		if ( elements == null ) {
			return;
		}
		if ( elements.getSrefList() == null ) {
			return;
		}
		if ( elements.getSrefList().getNumber() <= MAX_QUAD_TREE_ELEMENTS ) {  // # of polygons (17)
			return;  /* do not divide into subtrees if less than the number */											  
		} 
		if ( depth > MAX_QUAD_TREE_DEPTH ) {	// the quad tree depth, normally less than 5~6 
			return;  // do not divide into subtrees if greater than the number 
		}
		
		if ( DEBUG_SHOW_QUAD_TREE_DEPTH ) {
			System.out.println("depth: " + depth);
		}
		
		DSsrefList tempSREFlist = new DSsrefList();  // temporary SREF list 
		
		for ( DSsrefNode srefNode = elements.getSrefList().getHead();
		      srefNode != null;
		      srefNode = srefNode.getNext() ) 
		{
			int sref_minX = srefNode.getMinX();  // element's minX
    		int sref_maxX = srefNode.getMaxX();  // element's maxX
    		int sref_minY = srefNode.getMinY();  // element's minY
    		int sref_maxY = srefNode.getMaxY();  // element's maxY
    		
    		/* ULeft */
    		if ( (divX >= sref_maxX) && (divY <= sref_minY) ) {
    			DSsrefNode sref_new = new DSsrefNode(srefNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUL( sref_new, depth+1 );
    		}
    		/* URight */
    		else if ( (divX <= sref_minX) && (divY <= sref_minY) ) {
    			DSsrefNode sref_new = new DSsrefNode(srefNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addUR( sref_new, depth+1 );
    		}        		
    		/* LLeft */
    		else if ( (divX >= sref_maxX) && (divY >= sref_maxY) ) {
    			DSsrefNode sref_new = new DSsrefNode(srefNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			addLL( sref_new, depth+1 );
    		}
    		/* LRight */
    		else if ( (divX <= sref_minX) && (divY >= sref_maxY) ) {
				DSsrefNode sref_new = new DSsrefNode(srefNode);  /* create a new DSboundaryNode */  /* may not need to create new */
				addLR( sref_new, depth+1 );
			}
    		else {
    			DSsrefNode sref_new = new DSsrefNode(srefNode);  /* create a new DSboundaryNode */  /* may not need to create new */
    			tempSREFlist.insert( sref_new );
    		}
		}
		
		elements.setSrefList( tempSREFlist );
		
		if (ULeft!=null) {
			BoundingBox bboxUL = new BoundingBox( bbox.getMinX(), divX, divY, bbox.getMaxY() );
			ULeft.divideSrefElementsIntoQuadTrees( bboxUL );
		}		
		if (URight!=null) {
			BoundingBox bboxUR = new BoundingBox( divX, bbox.getMaxX(), divY, bbox.getMaxY() );
			URight.divideSrefElementsIntoQuadTrees( bboxUR );
		}
		if (LLeft!=null) {
			BoundingBox bboxLL = new BoundingBox( bbox.getMinX(), divX, bbox.getMinY(), divY );
			LLeft.divideSrefElementsIntoQuadTrees( bboxLL );
		}
		if (LRight!=null) {
			BoundingBox bboxLR = new BoundingBox( divX, bbox.getMaxX(), bbox.getMinY(), divY );
			LRight.divideSrefElementsIntoQuadTrees( bboxLR );
		}
	}  // END of divideBoundaryElementsIntoQuadTrees()
	
	
	
	
}
