/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class Ruler {
	
	private static boolean isExist;
	private static int x1;		// start
	private static int y1;		// start
	private static int x2;		// end
	private static int y2;		// end
	
	public static void create() {
		isExist = true;
		x1 = 0;
		y1 = 0;
		x2 = 0;
		y2 = 0;
		//MainClass.consoleText.append("Ruler mode ON.\n");
		MainClass.appendConsoleText("Ruler mode ON.\n");
	}
	
	public static void remove() {
		isExist = false;
		x1 = 0;
		y1 = 0;
		x2 = 0;
		y2 = 0;
		//MainClass.consoleText.append("Ruler mode OFF.\n");
		MainClass.appendConsoleText("Ruler mode OFF.\n");
	}
	
	public static boolean isExist() {
		return( isExist );
	}
		
	public static void setStartPoint( int startX, int startY ) {
		x1 = startX;
		y1 = startY;
		x2 = startX;  // prevent from drawing if End-Point if not set
		y2 = startY;  // prevent from drawing if End-Point if not set
	}
	
	public static void setEndPoint( int endX, int endY ) {
		x2 = endX;
		y2 = endY;
	}
	
	public static int getX1() {
		return( x1 );
	}
	
	public static int getY1() {
		return( y1 );
	}
	
	public static int getX2() {
		return( x2 );
	}
	
	public static int getY2() {
		return( y2 );
	}

}
