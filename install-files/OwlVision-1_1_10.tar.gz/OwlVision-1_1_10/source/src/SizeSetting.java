/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/9
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SizeSetting {
	
	private static double minX, OminX;
	private static double maxX, OmaxX;
	private static double minY, OminY;
	private static double maxY, OmaxY;
	private static double imageWidth;
	private static double imageHeight;
	private static double scale;
	
	private static double userUnit;
	private static double physUnit;
	
	public static void setMinX( int value ) {
		minX = OminX = value;
	}
	
	public static void setMaxX( int value ) {
		maxX = OmaxX = value;
	}
	
	public static void setMinY( int value ) {
		minY = OminY = value;
	}
	
	public static void setMaxY( int value ) {
		maxY = OmaxY = value;
	}
	
	public static void initialize() {		
		minX = minX - Math.abs(maxX-minX)*0.02;
		maxX = maxX + Math.abs(maxX-minX)*0.02;
		minY = minY - Math.abs(maxY-minY)*0.02;
		maxY = maxY + Math.abs(maxY-minY)*0.02;
	}
	
	public static void setImageScale(int width, int height) 
	{
		imageWidth  = width;
		imageHeight = height;
		
		double scaleW = (maxX-minX)/imageWidth;
		double scaleH = (maxY-minY)/imageHeight;
		scale = scaleW > scaleH ? scaleW : scaleH;
	}
	
	/* transform GDSII coordinates to image coordinates */
	/* for writing to the image file */
	public static double trans_X(double X_coord) {
		double temp = (X_coord - OminX) / scale;
		temp = temp + (imageWidth-(OmaxX-OminX)/scale)/2;  // put into the center of the image
		return(temp);
	}
	
	/* transform GDSII coordinates to image coordinates */
	/* for writing to the image file */
	public static double trans_Y(double Y_coord) {
		double temp = (Y_coord - OminY) / scale;
		temp = imageHeight - temp - (imageHeight-(OmaxY-OminY)/scale)/2;
		return(temp);
	} 
	
	/* Translate Window coordinates to GDSII coordinates */
	/* for displaying GDSII coordinates */
	public static int trans_GDSII_X(int window_X_coordinate) {
		double window_X_coord = window_X_coordinate;
		window_X_coord -= DrawLayout.getImagePositionX();  // HScrollBar
		
		double imageXcoord = scale*(window_X_coord - (imageWidth - (OmaxX-OminX)/scale)/2) + OminX;
		return((int)imageXcoord);
	}
	
	/* Translate Window coordinates to GDSII coordinates */
	/* for displaying GDSII coordinates */
	public static int trans_GDSII_Y(int window_Y_coordinate) {
		double window_Y_coord = window_Y_coordinate;
		window_Y_coord -= DrawLayout.getImagePositionY();  // VScrollBar
		
		double imageYcoord = scale*(  (-1)*window_Y_coord + imageHeight - (imageHeight - (OmaxY-OminY)/scale)/2  ) + OminY;
		return((int)imageYcoord);
	}
	
	/* Translate GDSII coordinates to Window coordinates */
	public static double transGDS2Window_X_double(double X_coord) {
		double temp = (X_coord - OminX) / scale;
		temp = temp + (imageWidth-(OmaxX-OminX)/scale)/2;  // put into the center of the image
		temp += DrawLayout.getImagePositionX();  // HScrollBar
		return( temp );
	}
	
	public static int transGDS2Window_X_int(double X_coord) {
		return( (int)transGDS2Window_X_double(X_coord) );
	}
	
	/* Translate GDSII coordinates to Window coordinates */
	public static double transGDS2Window_Y_double(double Y_coord) {
		double temp = (Y_coord - OminY) / scale;
		temp = imageHeight - temp - (imageHeight-(OmaxY-OminY)/scale)/2;
		temp += DrawLayout.getImagePositionY();  // VScrollBar
		return( temp );
	}
	
	public static int transGDS2Window_Y_int(double Y_coord) {
		return( (int)transGDS2Window_Y_double(Y_coord) );
	}
	
	
	public static double scale(double distance) {
		return(distance/scale);
	}	
	
		
	public static int getOMinX() {
		return( (int)OminX );
	}
	
	public static int getOMaxX() {
		return( (int)OmaxX );
	}
	
	public static int getOMinY() {
		return( (int)OminY );
	}
	
	public static int getOMaxY() {
		return( (int)OmaxY );
	}
	
	/* the ratio of "GDSII size" over "off-screen image size" 
	 * 
	 */
	public static double getScale() {
		return( scale );
	}
	
	public static void setUserUnit(double value) {
		userUnit = value;
	}
	
	public static double getUserUnit() {
		return( userUnit );
	}
	
	public static void setPhysUnit(double value) {
		physUnit = value;
	}
	
	public static double getPhysUnit() {
		return( physUnit );
	}
	
	public static double trans_X( double coordX, boolean isOnScreen )
	{
		if ( isOnScreen == true ) {
			/* Draw on the screen */
			return( SizeSetting.trans_X(coordX) );
		}
		else {
			/* Draw on JPG/GIF files */
			return( SizeSetting2.trans_X(coordX) );
		}
	}
	
	public static double trans_Y( double coordY, boolean isOnScreen )
	{
		if ( isOnScreen == true ) {
			/* Draw on the screen */
			return( SizeSetting.trans_Y(coordY) );
		}
		else {
			/* Draw on JPG/GIF files */
			return( SizeSetting2.trans_Y(coordY) );
		}
	}
	
	
}  // end of the class "draw_polygons"
