/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/9
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/* for JPG and GIF */
public class SizeSetting2 {
	private static double minX, OminX;
	private static double maxX, OmaxX;
	private static double minY, OminY;
	private static double maxY, OmaxY;
	private static double imageWidth;
	private static double imageHeight;
	private static double scale;
	
	public static void setMinX( int value ) {
		minX = OminX = value;
	}
	
	public static void setMaxX( int value ) {
		maxX = OmaxX = value;
	}
	
	public static void setMinY( int value ) {
		minY = OminY = value;
	}
	
	public static void setMaxY( int value ) {
		maxY = OmaxY = value;
	}
	
	public static void initialize() {
		
		minX = minX - Math.abs(maxX-minX)*0.02;
		maxX = maxX + Math.abs(maxX-minX)*0.02;
		minY = minY - Math.abs(maxY-minY)*0.02;
		maxY = maxY + Math.abs(maxY-minY)*0.02;
		
	}
	
	public static void setImageSize(int width, int height) {
		imageWidth  = width;
		imageHeight = height;
		
		double scaleW = (maxX-minX)/imageWidth;
		double scaleH = (maxY-minY)/imageHeight;
		scale = scaleW > scaleH ? scaleW : scaleH;
	}
	
	/* transform GDSII coordinates to window coordinates */
	public static double trans_X(double X_coord) {
		double temp = (X_coord - OminX) / scale;
		temp = temp + (imageWidth-(OmaxX-OminX)/scale)/2;  // put into the center of the image
		return(temp);
	}
	
	/* transform GDSII coordinates to window coordinates */
	public static double trans_Y(double Y_coord) {
		double temp = (Y_coord - OminY) / scale;
		temp = imageHeight - temp - (imageHeight-(OmaxY-OminY)/scale)/2;
		//temp = imageHeight - temp;
		return(temp);
	} 
	
	/* WRONG - need scrollbar info. */
	public static int trans_GDSII_X(int window_X_coordinate) {
		double window_X_coord = window_X_coordinate;
		double X_coord = scale*(  window_X_coord - (imageWidth - (maxX-minX)/scale)/2  ) + minX;
		return((int)X_coord);
	}
	
	/* WRONG - need scrollbar info. */
	public static int trans_GDSII_Y(int window_Y_coordinate) {
		double window_Y_coord = window_Y_coordinate;
		double Y_coord = scale*(  (-1)*window_Y_coord + imageHeight - (imageHeight - (maxY-minY)/scale)/2  ) + minY;
		return((int)Y_coord);
	}
	
	
	public static double scale(double distance) {
		return(distance/scale);
	}	
	
	
	public static int getOMinX() {
		return( (int)OminX );
	}
	
	public static int getOMaxX() {
		return( (int)OmaxX );
	}
	
	public static int getOMinY() {
		return( (int)OminY );
	}
	
	public static int getOMaxY() {
		return( (int)OmaxY );
	}
	
	
		
	
}  // end of the class "draw_polygons"
