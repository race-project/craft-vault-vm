/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/4/10
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
//import javax.swing.border.*;
//import javax.swing.event.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author I-Lun Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ToolBar extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//public JTextPane pane;
	public static double ZoomFactor;
	public JMenuBar menuBar;
	public JToolBar toolBar;
	private static JComboBox cellsComboBox;
	
	private static int depthValue = 9999;	// initial value
	
	
	public ToolBar() 
	{
		DemoAction showAll = new DemoAction("Show All",
				"Show All", 's');	// fit screen
		DemoAction zoomIn = new DemoAction("Zoom In",
				"Zoom In", 'i');
		DemoAction zoomOut = new DemoAction("Zoom Out",
				"Zoom Out", 'o');
		DemoAction zoomArea = new DemoAction("Zoom Area",
				"Zoom Area", 'a');
		
		/* ==== Cell ==== */
		
		JLabel labelCell = new JLabel("     Cell: ");
		cellsComboBox = new JComboBox();
		
		cellsComboBox.addActionListener( new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				JComboBox cb = (JComboBox)e.getSource();
				String itemName = (String)cb.getSelectedItem();
				MainClass.chooseCell( itemName );
			}			
		});
		
		/* ==== Depth ==== */
		
		JLabel label2 = new JLabel("     Depth: ");
		
		String [] options = new String [] {"All", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
		SpinnerListModel splModel = new SpinnerListModel( options );
		JSpinner viewDepth = new JSpinner( splModel );
		//viewDepth.setEnabled( false );
		
		
		splModel.addChangeListener( new ChangeListener() 
		{
			public void stateChanged( ChangeEvent e )
			{
				//int depthValue = 9999;
				String depthValueStr = "" + ((SpinnerListModel) e.getSource()).getValue();
				
				if ( depthValueStr.compareTo("All") == 0 ) {
					depthValue = 9999;
				}
				else {
					depthValue = Integer.parseInt( depthValueStr );
				}
				
				System.out.println( "" + depthValue );
				
				DrawLayout.isRedrawImage( true );
				PanelCenter.g2D.repaint();
			}
		} );
		
		
		toolBar = new JToolBar("Toolbar");
		toolBar.add(showAll);
		toolBar.add(zoomIn);
		toolBar.add(zoomOut);
		toolBar.add(zoomArea);
		toolBar.add(labelCell);
		toolBar.add( cellsComboBox );
		toolBar.add(label2);
		toolBar.add( viewDepth );
		
		ZoomFactor = 1;		// initial value
	}
	
	
	class DemoAction extends AbstractAction {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public DemoAction(String text, String description, char accelerator) {
			super(text);
			putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(accelerator,
					Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
			putValue(SHORT_DESCRIPTION, description);
			
		}
		
		// Button Pressed
		public void actionPerformed(ActionEvent e) {
			//System.out.println("Toolbar button" + getValue(NAME));
			
			if (getValue(NAME).equals("Show All")) {
				ZoomFactor = 1;
				PanelHBar.set_to_default_position();
				PanelVBar.set_to_default_position();
				DrawLayout.isZoomFactorChanged(true);
				DrawLayout.renewImageSize();
				PanelCenter.g2D.repaint();
				MainClass.appendConsoleText("Show All.\n");
				
			} else if (getValue(NAME).equals("Zoom In")) {
				
				ZoomFactor *= 1.05;
				DrawLayout.isZoomFactorChanged(true);
				DrawLayout.renewImageSize();
				//System.out.println("Window width and height: " + DrawLayout.getWindowWidth() + ", " + DrawLayout.getWindowHeight() );
				//System.out.println("GDSII center: " + DrawLayout.getCenterGDSIIpointX() + ", " + DrawLayout.getCenterGDSIIpointY() );
				
				//int wPosX = SizeSetting.transGDS2Window_X_int( DrawLayout.getCenterGDSIIpointX() );
				//int wPosY = SizeSetting.transGDS2Window_Y_int( DrawLayout.getCenterGDSIIpointY() );
				//System.out.println("wPos: " + wPosX + ", " + wPosY );
				
				//int cPosX = DrawLayout.getWindowWidth()/2;
				//int cPosY = DrawLayout.getWindowHeight()/2;
				//System.out.println("cPos: " + cPosX + ", " + cPosY );
				//int gPosX = SizeSetting.trans_GDSII_X( cPosX );
				//int gPosY = SizeSetting.trans_GDSII_Y( cPosY );
				//System.out.println("GDSII: " + DrawLayout.getCenterGDSIIpointX() + ", " + DrawLayout.getCenterGDSIIpointY() );
				//System.out.println("gPos: " + gPosX + ", " + gPosY );
				
				//int resX = (int) (SizeSetting.trans_X(gPosX) - SizeSetting.trans_X(DrawLayout.getCenterGDSIIpointX()) );
				//int resY = (int) (SizeSetting.trans_Y(gPosY) - SizeSetting.trans_Y(DrawLayout.getCenterGDSIIpointY()) );
				//System.out.println("resX: " + resX + ", resY: " + resY );
				
				//DrawLayout.setImagePositionX( resX );
				//DrawLayout.setImagePositionY( resY );
				
				PanelCenter.g2D.repaint();
				MainClass.appendConsoleText("Zoom In.\n");
				
			} else if (getValue(NAME).equals("Zoom Out")) {				
				ZoomFactor *= 0.95; 
				DrawLayout.isZoomFactorChanged(true);
				DrawLayout.renewImageSize();
				PanelCenter.g2D.repaint();
				MainClass.appendConsoleText("Zoom Out.\n");
				
			} else if (getValue(NAME).equals("Zoom Area")) {				
				MainClass.appendConsoleText("Zoom Area: This is not implemented yet.\n");
			}

		}	// actionPerformed
	}	// DemoAction
	
	public static void clearComboBox() {
		cellsComboBox.removeAllItems();
	}
	
	public static void addToComboBox( String item ) {
		cellsComboBox.addItem( item );
	}
	
	public static void setComboBoxSelectedItem( String item ) {
		cellsComboBox.setSelectedItem( item );
	}
	
	public static int getDepthValue() 
	{
		return( depthValue );
	}
	
	
}
