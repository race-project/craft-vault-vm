/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


/*
 * Created on 2005/8/27
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */


import java.io.*;
import javax.swing.*;

/**
 * @author Tseng
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TranslateFunction {
	/* for GDSII to ASCII */
	private static JTextField tfG2AFromFile;
	private static JTextField tfG2AToFile;
	private static File fileFromG2A = null;
	private static File fileToG2A = null;
	/* for ASCII to GDSII */
	private static JTextField tfA2GFromFile;
	private static JTextField tfA2GToFile;
	private static File fileFromA2G = null;
	private static File fileToA2G = null;
	
	/* GDSII to ASCII */
	
	public static void setG2AFromTextField(JTextField tf) {
		tfG2AFromFile = tf;
	}	
	public static void setG2AToTextField(JTextField tf) {
		tfG2AToFile = tf;
	}
	
	public static void setG2AFromFile(File f) {
		fileFromG2A = f;
	}
	public static void setG2AToFile(File f) {
		fileToG2A = f;
	}
	
	public static void getG2AFromFileName() 
	{	
		tfG2AFromFile.setText( fileFromG2A.getAbsolutePath() );
		tfG2AToFile.setText( "" + fileFromG2A.getAbsolutePath() + ".txt" );
	}
	
	public static void getG2AToFileName() 
	{	
		tfG2AToFile.setText( fileToG2A.getAbsolutePath() );
	}
	
	/* ASCII to GDSII */
	
	public static void setA2GFromTextField(JTextField tf) {
		tfA2GFromFile = tf;
	}	
	public static void setA2GToTextField(JTextField tf) {
		tfA2GToFile = tf;
	}
	
	public static void setA2GFromFile(File f) {
		fileFromA2G = f;
	}
	public static void setA2GToFile(File f) {
		fileToA2G = f;
	}
	
	public static void getA2GFromFileName() {
		
		tfA2GFromFile.setText( fileFromA2G.getAbsolutePath() );
		tfA2GToFile.setText( "" + fileFromA2G.getAbsolutePath() + ".gds" );
	}
	public static void getA2GToFileName() {
		
		tfA2GToFile.setText( fileToA2G.getAbsolutePath() );
	}

}
