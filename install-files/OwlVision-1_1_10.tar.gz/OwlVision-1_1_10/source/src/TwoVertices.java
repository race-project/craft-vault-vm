/* 
 *  Copyright (C) 2005-2007  I-Lun Tseng
 * 
 *  This file is part of OwlVision.
 *
 *  OwlVision is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  OwlVision is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with OwlVision; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */


public class TwoVertices {
	
	private int 	x1;
	private int 	y1;
	private int 	x2;
	private int 	y2;
	
	
	public TwoVertices( int x_1, int y_1, int x_2, int y_2 ) 
	{
		x1 = x_1;
		y1 = y_1;
		x2 = x_2;
		y2 = y_2;
	}
	
	
	public int getX1() {
		return( x1 );
	}
	
	
	public int getY1() {
		return( y1 );
	}
	
	
	public int getX2() {
		return( x2 );
	}
	
	
	public int getY2() {
		return( y2 );
	}

}
