help([[
ISI Open-Source Example Flow
]])
whatis("Open-Source Example Flow")
whatis("Version: 1.0")

setenv("LD_LIBRARY_PATH", "/usr/local/lib:$LD_LIBRARY_PATH")
