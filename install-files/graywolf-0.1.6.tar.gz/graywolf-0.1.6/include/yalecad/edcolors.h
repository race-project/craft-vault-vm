#ifndef INC_EDCOLORS_H
#define INC_EDCOLORS_H

void TWtoggleColors();

#endif
