#ifndef INC_RAND_H
#define INC_RAND_H

INT Yacm_random();

#endif /*INC_RAND_H*/

