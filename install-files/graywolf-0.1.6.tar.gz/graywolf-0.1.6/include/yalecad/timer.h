#ifndef INC_TIMER_H
#define INC_TIMER_H

void Ytimer_elapsed( INT *time_elapsed );

void Ytimer_start();

#endif /*INC_TIMER_H */
