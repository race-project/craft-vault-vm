#define DATE "@(#) Yale compilation date:Mon May 25 20:57:18 EDT 1992"
