static TWDIALOGBOX row_dialogS[19] = {
    1,5,8," ACCEPT ",2,6,0,
    1,25,8," CANCEL ",2,3,0,
    2,15,8,"Row Edit",0,3,0,
    4,5,6,"Left          :",0,4,0,
    5,5,6,"Bottom        :",0,4,0,
    6,5,6,"Right         :",0,4,0,
    7,5,6,"Top           :",0,4,0,
    8,5,21,"Class         :",0,4,0,
    8,25,8," ",1,4,0,
    9,5,19,"Mirror rows   :",3,4,11,
    9,25,3,"YES",2,6,1,
    9,31,2,"NO",2,3,1,
    11,1,35,"To change case fields put pointer",0,4,0,
    12,1,35,"in window and click.  To change",0,4,0,
    13,1,35,"input fields put pointer in window",0,4,0,
    14,1,35,"and back up over current contents",0,4,0,
    15,1,35,"using the delete key.  After modifying",0,4,0,
    16,1,35,"the field, hit the return key.",0,4,0,
    0,0,0,0,0,0,0
} ;

