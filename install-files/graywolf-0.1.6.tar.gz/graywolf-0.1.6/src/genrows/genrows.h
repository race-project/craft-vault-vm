#ifndef __GENROWS_GENROWS_H__
#define __GENROWS_GENROWS_H__

void calculate_numrows(void);
void recalculate(BOOL freepts);
void remakerows(void);
void set_core(INT left, INT right, INT bottom, INT top );

#endif // __GENROWS_GENROWS_H__
