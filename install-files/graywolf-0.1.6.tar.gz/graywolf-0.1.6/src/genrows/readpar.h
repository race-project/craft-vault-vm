#ifndef __GENROWS_READPAR_H__
#define __GENROWS_READPAR_H__

void readpar(void);

#endif // __GENROWS_READPAR_H__
