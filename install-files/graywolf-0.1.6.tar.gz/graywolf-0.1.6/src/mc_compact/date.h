#define DATE "@(#) Yale compilation date:Mon May 25 21:07:13 EDT 1992"
