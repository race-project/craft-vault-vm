#define DATE "@(#) Yale compilation date:Mon May 25 21:09:40 EDT 1992"
