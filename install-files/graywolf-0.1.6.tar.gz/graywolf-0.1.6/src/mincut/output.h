#ifndef __MINCUT_OUTPUT_H__
#define __MINCUT_OUTPUT_H__

void read_par(void);

#endif // __MINCUT_OUTPUT_H__
