#define DATE "@(#) Yale compilation date:Mon May 25 21:11:10 EDT 1992"
