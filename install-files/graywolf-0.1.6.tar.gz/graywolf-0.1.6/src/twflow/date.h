#define DATE "@(#) Yale compilation date:Mon May 25 21:15:08 EDT 1992"
