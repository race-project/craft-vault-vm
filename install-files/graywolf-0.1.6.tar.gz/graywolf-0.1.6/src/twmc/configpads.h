#ifndef INC_TSMC_CONFIGPADS_H
#define INC_TSMC_CONFIGPADS_H

void calc_constraints( PADBOXPTR pad, INT side, DOUBLE *lb, DOUBLE *ub, BOOL *spacing_restricted, INT *lowpos, INT *uppos );

#endif /* INC_TSMC_CONFIGPADS_H */

