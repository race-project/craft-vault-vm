#define DATE "@(#) Yale compilation date:Mon May 25 21:18:34 EDT 1992"
