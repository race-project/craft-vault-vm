#ifndef INC_FINDSIDE_H
#define INC_FINDSIDE_H

#include <main.h>
#include <custom.h>


void loadside( PSIDEBOX *pSideArray, INT side , DOUBLE factor );
void load_soft_pins( CELLBOXPTR ptr, PSIDEBOX *pSideArray );

#endif /* INC_FINDSIDE_H */

