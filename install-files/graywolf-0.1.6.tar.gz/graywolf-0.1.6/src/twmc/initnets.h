#ifndef __TWMC_INITNETS_H__
#define __TWMC_INITNETS_H__

void end_path(INT lower_bound, INT upper_bound, INT priority);
void add_path(BOOL pathFlag, char* net);

#endif // __TWMC_INITNETS_H__

