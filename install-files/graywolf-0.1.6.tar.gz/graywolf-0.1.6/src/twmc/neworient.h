#ifndef INC_NEWORIENT_H
#define INC_NEWORIENT_H

#include <main.h>
#include <custom.h>

INT check_valid_orient( CELLBOXPTR cptr );

#endif

