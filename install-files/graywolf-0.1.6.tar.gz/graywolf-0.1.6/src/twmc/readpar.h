#ifndef __TWMC_READPAR_H__
#define __TWMC_READPAR_H__

void readpar(void);

#endif // __TWMC_READPAR_H__

