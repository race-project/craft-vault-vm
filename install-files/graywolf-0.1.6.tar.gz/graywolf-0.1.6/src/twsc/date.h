#define DATE "@(#) Yale compilation date:Mon May 25 21:19:07 EDT 1992"
