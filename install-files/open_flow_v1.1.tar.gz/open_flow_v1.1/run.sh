export WORK_HOME=/home/username/open_flow_v1.1

export router_tool=qrouter
export migrate_tool=magic_db
export drc_tool=magic_drc
export lvs_tool=netgen_lvs
export gds_tool=magic_gds
export display_tool=klayout

# Synthesis
qflow -p ${WORK_HOME} synthesize -T gscl45nm sync_mult

# Placement
qflow -p ${WORK_HOME} place -T gscl45nm sync_mult

# Router
qflow -p ${WORK_HOME} route -T gscl45nm sync_mult

# Migrate, DRC, and LVS
qflow -p ${WORK_HOME} migrate -T gscl45nm sync_mult
# disabled # qflow -p ${WORK_HOME} drc -T gscl45nm sync_mult # do not enable
# disabled # qflow -p ${WORK_HOME} lvs -T gscl45nm sync_mult # do not enable

# GDS Generation
qflow -p ${WORK_HOME} gdsii -T gscl45nm sync_mult
