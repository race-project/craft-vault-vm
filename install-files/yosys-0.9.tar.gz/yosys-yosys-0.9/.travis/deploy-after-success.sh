#! /bin/bash

set -x
set -e

# FIXME: Upload the build results somewhere...
